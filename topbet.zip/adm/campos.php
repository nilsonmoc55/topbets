<?php
require_once '../includes/conexao.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = $_POST["nome"] ?? '';
    $rotulo = $_POST["rotulo"] ?? '';
    $tipo = $_POST["tipo"] ?? 'text';
    $obrigatorio = isset($_POST["obrigatorio"]) ? 1 : 0;
    $ordem = $_POST["ordem"] ?? 0;
    $opcoes = $_POST["opcoes"] ?? [];

    $opcoes_json = in_array($tipo, ['checkbox', 'radio', 'select']) ? json_encode(array_filter($opcoes)) : null;

    $stmt = $conn->prepare("INSERT INTO formulario_campos (nome_campo, rotulo, tipo, obrigatorio, ordem, opcoes, ativo) VALUES (?, ?, ?, ?, ?, ?, 1)");
    $stmt->bind_param("sssiss", $nome, $rotulo, $tipo, $obrigatorio, $ordem, $opcoes_json);
    $stmt->execute();

    header("Location: campos.php?sucesso=1");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gerenciar Campos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
      function toggleOpcoesField() {
          const tipo = document.getElementById("tipo").value;
          const opcoesDiv = document.getElementById("opcoes-group");
          if (["checkbox", "radio", "select"].includes(tipo)) {
              opcoesDiv.classList.remove("d-none");
          } else {
              opcoesDiv.classList.add("d-none");
          }
      }

      function adicionarOpcao() {
          const container = document.getElementById("opcoes-container");
          const input = document.createElement("input");
          input.type = "text";
          input.name = "opcoes[]";
          input.classList.add("form-control", "mt-1");
          input.placeholder = "Opção";
          container.appendChild(input);
      }
    </script>
</head>
<body class="p-4">
<div class="container">
    <h2>Adicionar Campo ao Formulário</h2>

    <form method="POST" class="bg-white p-4 rounded shadow-sm">
        <div class="mb-3">
            <label class="form-label">Nome do Campo (interno)</label>
            <input type="text" name="nome" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Rótulo Exibido</label>
            <input type="text" name="rotulo" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Tipo do Campo</label>
            <select name="tipo" id="tipo" class="form-select" onchange="toggleOpcoesField()">
                <option value="text">Texto</option>
                <option value="textarea">Área de Texto</option>
                <option value="number">Número</option>
                <option value="email">Email</option>
                <option value="checkbox">Checkbox</option>
                <option value="radio">Radio</option>
                <option value="select">Select</option>
                <option value="estrelas">Avaliação (Estrelas)</option>
            </select>
        </div>

        <div id="opcoes-group" class="mb-3 d-none">
            <label class="form-label">Opções</label>
            <div id="opcoes-container">
                <input type="text" name="opcoes[]" class="form-control" placeholder="Opção 1">
            </div>
            <button type="button" class="btn btn-secondary btn-sm mt-2" onclick="adicionarOpcao()">+ Adicionar Opção</button>
        </div>

        <div class="mb-3">
            <label class="form-label">Ordem</label>
            <input type="number" name="ordem" class="form-control" value="0">
        </div>

        <div class="mb-3 form-check">
            <input type="checkbox" name="obrigatorio" class="form-check-input" id="obrigatorio">
            <label class="form-check-label" for="obrigatorio">Campo obrigatório</label>
        </div>

        <button type="submit" class="btn btn-success">Salvar Campo</button>
    </form>
</div>
</body>
</html>
