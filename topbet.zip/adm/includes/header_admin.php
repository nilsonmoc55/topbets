<?php
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_nivel'] != 3) {
    header('Location: ../login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Administrativo - TopBets</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    :root {
        --sidebar-width: 250px;
        --header-height: 60px;
        --sidebar-bg: #212529 !important;  /* Preto escuro */
        --sidebar-text: #ffffff !important; /* Texto branco */
        --sidebar-active: #343a40 !important; /* Cinza escuro para item ativo */
        --sidebar-hover: #2c3034 !important; /* Cinza mais escuro para hover */
    }
    
    /* Reset de estilos do Bootstrap que podem estar interferindo */
    .sidebar {
        background-color: var(--sidebar-bg) !important;
    }
    
    .sidebar .nav-link {
        color: var(--sidebar-text) !important;
        padding: 0.75rem 1.5rem !important;
        margin: 0.25rem 0 !important;
        border-left: 3px solid transparent !important;
        transition: all 0.3s !important;
    }
    
    .sidebar .nav-link:hover {
        background-color: var(--sidebar-hover) !important;
        color: var(--sidebar-text) !important;
    }
    
    .sidebar .nav-link.active {
        background-color: var(--sidebar-active) !important;
        border-left: 3px solid var(--sidebar-text) !important;
        color: var(--sidebar-text) !important;
    }
    
    .sidebar .nav-link i {
        color: var(--sidebar-text) !important;
    }
    
    /* Estrutura principal (mantenha o mesmo) */
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f8f9fc;
    }
    
    .topbar {
        height: var(--header-height);
        box-shadow: 0 0.15rem 1.75rem 0 rgba(0, 0, 0, 0.1);
        background: white;
        position: fixed;
        top: 0;
        right: 0;
        left: var(--sidebar-width);
        z-index: 100;
    }
    
    .sidebar {
        width: var(--sidebar-width);
        height: 100vh;
        position: fixed;
        left: 0;
        top: 0;
        transition: all 0.3s;
        z-index: 1000;
        padding-top: var(--header-height);
    }
    
    .main-content {
        margin-left: var(--sidebar-width);
        margin-top: var(--header-height);
        padding: 20px;
        width: calc(100% - var(--sidebar-width));
        min-height: calc(100vh - var(--header-height));
    }
    
    @media (max-width: 768px) {
        .sidebar {
            left: -250px;
        }
        
        .sidebar.active {
            left: 0;
        }
        
        .topbar, .main-content {
            left: 0;
            width: 100%;
        }
        
        .main-content.active {
            margin-left: 250px;
            width: calc(100% - 250px);
        }
    }
</style>
</head>
<body>
    <!-- Topbar (apenas a barra superior) -->
    <nav class="topbar navbar navbar-expand navbar-light">
        <div class="container-fluid">
            <button id="sidebarToggle" class="btn btn-link d-md-none">
                <i class="fas fa-bars"></i>
            </button>
            
            <ul class="navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                        <img class="rounded-circle" src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['usuario_nome']) ?>&background=random&color=fff" width="40">
                        <span class="ms-2 d-none d-lg-inline"><?= htmlspecialchars($_SESSION['usuario_nome']) ?></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end">
                        <a class="dropdown-item" href="perfil.php">
                            <i class="fas fa-user fa-sm fa-fw mr-2"></i> Perfil
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="../logout.php">
                            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2"></i> Sair
                        </a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
    
   <!-- Sidebar (menu lateral) -->
<div class="sidebar">
    <div class="sidebar-inner">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>" href="index.php">
                    <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'usuarios.php' ? 'active' : '' ?>" href="usuarios.php">
                    <i class="fas fa-users me-2"></i> Usuários
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'bets.php' ? 'active' : '' ?>" href="bets.php">
                    <i class="fas fa-chess-queen me-2"></i> Casas de Aposta
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'avaliacoes.php' ? 'active' : '' ?>" href="avaliacoes.php">
                    <i class="fas fa-star me-2"></i> Avaliações
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'anuncios.php' ? 'active' : '' ?>" href="anuncios.php">
                    <i class="fas fa-ad me-2"></i> Anúncios
                </a>
            </li>
        </ul>
    </div>
</div>
    <!-- Main Content -->
    <div class="main-content">