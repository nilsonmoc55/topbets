<?php
// includes/sidebar.php
// Verifica se o usuário está logado como administrador
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_nivel'] != 3) {
    header('Location: ../login.php');
    exit();
}
?>

<div class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse" id="sidebarMenu" style="color: white;">
    <div class="position-sticky pt-3">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : '' ?>" href="index.php">
                    <i class="fas fa-tachometer-alt me-2"></i>
                    Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'usuarios.php' ? 'active' : '' ?>" href="usuarios.php">
                    <i class="fas fa-users me-2"></i>
                    Usuários
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'bets.php' ? 'active' : '' ?>" href="bets.php">
                    <i class="fas fa-chess-queen me-2"></i>
                    Casas de Aposta
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'avaliacoes.php' ? 'active' : '' ?>" href="avaliacoes.php">
                    <i class="fas fa-star me-2"></i>
                    Avaliações
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'anuncios.php' ? 'active' : '' ?>" href="anuncios.php">
                    <i class="fas fa-ad me-2"></i>
                    Anúncios
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'configuracoes.php' ? 'active' : '' ?>" href="configuracoes.php">
                    <i class="fas fa-cog me-2"></i>
                    Configurações
                </a>
            </li>
        </ul>
        
        <hr class="border-light">
        
        <div class="px-3 py-2">
            <div class="d-flex align-items-center">
                <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['usuario_nome']) ?>&background=random&color=fff" 
                     class="rounded-circle me-2" width="40" height="40">
                <div>
                    <strong><?= htmlspecialchars($_SESSION['usuario_nome']) ?></strong>
                    <div class="small text-muted">Administrador</div>
                </div>
            </div>
            <a href="../logout.php" class="btn btn-sm btn-outline-light mt-3 w-100">
                <i class="fas fa-sign-out-alt me-1"></i> Sair
            </a>
        </div>
    </div>
</div>