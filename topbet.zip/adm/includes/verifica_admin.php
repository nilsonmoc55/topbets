<?php
// includes/verifica_admin.php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit();
}

// Verifica se é admin (nivel_acesso = 3)
if ($_SESSION['usuario_nivel'] != 3) {
    header('Location: ../index.php');
    exit();
}

// Você pode adicionar mais verificações de segurança aqui