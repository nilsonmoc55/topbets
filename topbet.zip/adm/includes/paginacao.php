<!-- Paginação -->
<nav aria-label="Navegação de páginas">
    <ul class="pagination justify-content-center">
        <?php if ($pagina_atual > 1): ?>
            <li class="page-item">
                <a class="page-link" href="usuarios.php?pagina=<?= $pagina_atual - 1 ?>" aria-label="Anterior">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
        <?php endif; ?>
        
        <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
            <li class="page-item <?= $i == $pagina_atual ? 'active' : '' ?>">
                <a class="page-link" href="usuarios.php?pagina=<?= $i ?>"><?= $i ?></a>
            </li>
        <?php endfor; ?>
        
        <?php if ($pagina_atual < $total_paginas): ?>
            <li class="page-item">
                <a class="page-link" href="usuarios.php?pagina=<?= $pagina_atual + 1 ?>" aria-label="Próximo">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        <?php endif; ?>
    </ul>
</nav>