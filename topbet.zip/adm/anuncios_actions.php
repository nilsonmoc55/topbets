<?php
require_once __DIR__ . '/includes/verifica_admin.php';
require_once __DIR__ . '/../includes/conexao.php';

$action = filter_input(INPUT_GET, 'action');
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($action === 'delete' && $id) {
    try {
        // Busca o anúncio para ver se tem imagem para remover
        $stmt = $conn->prepare("SELECT imagem FROM anuncios WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $anuncio = $result->fetch_assoc();
        
        // Remove a imagem se existir e não for a default
        if ($anuncio['imagem'] && $anuncio['imagem'] !== 'img/logos/default.png') {
            @unlink(__DIR__ . '/../' . $anuncio['imagem']);
        }
        
        // Deleta o anúncio
        $stmt = $conn->prepare("DELETE FROM anuncios WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        
        $_SESSION['msg'] = [
            'tipo' => 'success',
            'texto' => 'Anúncio deletado com sucesso!'
        ];
    } catch (Exception $e) {
        $_SESSION['msg'] = [
            'tipo' => 'danger',
            'texto' => 'Erro ao deletar anúncio: ' . $e->getMessage()
        ];
    }
}

header('Location: anuncios.php');
exit();