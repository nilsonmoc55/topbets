<?php
require_once __DIR__ . '/includes/verifica_admin.php';
require_once __DIR__ . '/../includes/conexao.php';

$nivel_usuario_logado = $_SESSION['usuario_nivel'];

// Processa o formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
    $nivel_acesso = ($nivel_usuario_logado == 3) ? 
        filter_input(INPUT_POST, 'nivel_acesso', FILTER_VALIDATE_INT) : 1;
    $ativo = isset($_POST['ativo']) ? 1 : 0;

    try {
        $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, nivel_acesso, ativo) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssii", $nome, $email, $senha, $nivel_acesso, $ativo);
        $stmt->execute();
        
        $_SESSION['msg'] = 'Usuário cadastrado com sucesso!';
        header('Location: usuarios.php');
        exit();
    } catch (mysqli_sql_exception $e) {
        $erro = 'Erro ao cadastrar usuário: ' . $e->getMessage();
    }
}

include __DIR__ . '/includes/header_admin.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Adicionar Novo Usuário</h1>
    </div>

    <?php if (isset($erro)): ?>
        <div class="alert alert-danger"><?= $erro ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label for="nome" class="form-label">Nome Completo</label>
            <input type="text" class="form-control" id="nome" name="nome" required>
        </div>
        
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        
        <div class="mb-3">
            <label for="senha" class="form-label">Senha</label>
            <input type="password" class="form-control" id="senha" name="senha" required>
        </div>
        
        <?php if ($nivel_usuario_logado == 3): ?>
            <div class="mb-3">
                <label for="nivel_acesso" class="form-label">Nível de Acesso</label>
                <select class="form-select" id="nivel_acesso" name="nivel_acesso">
                    <option value="1">Usuário</option>
                    <option value="2">Moderador</option>
                    <option value="3">Administrador</option>
                </select>
            </div>
        <?php endif; ?>
        
        <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="ativo" name="ativo" checked>
            <label class="form-check-label" for="ativo">Ativo</label>
        </div>
        
        <button type="submit" class="btn btn-primary">Cadastrar</button>
        <a href="usuarios.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

<?php include __DIR__ . '/includes/footer_admin.php'; ?>