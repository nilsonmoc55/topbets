<?php
require_once __DIR__ . '/includes/verifica_admin.php';
require_once __DIR__ . '/../includes/conexao.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$bet = $conn->query("SELECT * FROM bets WHERE id = $id")->fetch_assoc();

if (!$bet) {
    $_SESSION['erro'] = 'Casa de aposta não encontrada!';
    header('Location: bets.php');
    exit();
}

// Processa o formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
    $url = filter_input(INPUT_POST, 'url', FILTER_SANITIZE_URL);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $contato = filter_input(INPUT_POST, 'contato', FILTER_SANITIZE_STRING);
    $descricao = filter_input(INPUT_POST, 'descricao', FILTER_SANITIZE_STRING);
    $ativo = isset($_POST['ativo']) ? 1 : 0;

    // Mantém a logo atual por padrão
    $logo = $bet['logo'];
    
    // Processa upload da nova logo se foi enviada
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $extensao = pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION);
        $nome_arquivo = 'bet-' . uniqid() . '.' . $extensao;
        $diretorio = '../img/logos/';
        
        if (move_uploaded_file($_FILES['logo']['tmp_name'], $diretorio . $nome_arquivo)) {
            // Remove a logo antiga se não for a default
            if ($logo !== 'img/logos/default.png' && file_exists('../' . $logo)) {
                unlink('../' . $logo);
            }
            $logo = 'img/logos/' . $nome_arquivo;
        }
    }

    try {
        $stmt = $conn->prepare("UPDATE bets SET 
            nome = ?, 
            url = ?, 
            email = ?, 
            logo = ?, 
            descricao = ?, 
            ativo = ?,
            contato = ?
            WHERE id = ?");
        $stmt->bind_param("sssssisi", $nome, $url, $email, $logo, $descricao, $ativo, $contato, $id);
        $stmt->execute();
        
        $_SESSION['msg'] = 'Casa de aposta atualizada com sucesso!';
        header('Location: bets.php');
        exit();
    } catch (mysqli_sql_exception $e) {
        $erro = 'Erro ao atualizar casa de aposta: ' . $e->getMessage();
    }
}

include __DIR__ . '/includes/header_admin.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Editar Casa de Aposta</h1>
    </div>

    <?php if (isset($erro)): ?>
        <div class="alert alert-danger"><?= $erro ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="nome" class="form-label">Nome*</label>
                    <input type="text" class="form-control" id="nome" name="nome" value="<?= htmlspecialchars($bet['nome']) ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="url" class="form-label">URL*</label>
                    <input type="url" class="form-control" id="url" name="url" value="<?= htmlspecialchars($bet['url']) ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="email" class="form-label">Email*</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($bet['email']) ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="contato" class="form-label">Contato</label>
                    <input type="text" class="form-control" id="contato" name="contato" value="<?= htmlspecialchars($bet['contato'] ?? '') ?>">
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="logo" class="form-label">Logo</label>
                    <input type="file" class="form-control" id="logo" name="logo" accept="image/*">
                    <small class="text-muted">Deixe em branco para manter a atual</small>
                    <?php if ($bet['logo']): ?>
                        <div class="mt-2">
                            <img src="../<?= htmlspecialchars($bet['logo']) ?>" alt="Logo atual" style="max-height: 100px;">
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="mb-3">
                    <label for="descricao" class="form-label">Descrição</label>
                    <textarea class="form-control" id="descricao" name="descricao" rows="3"><?= htmlspecialchars($bet['descricao'] ?? '') ?></textarea>
                </div>
                
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="ativo" name="ativo" <?= $bet['ativo'] ? 'checked' : '' ?>>
                    <label class="form-check-label" for="ativo">Ativo</label>
                </div>
            </div>
        </div>
        
        <button type="submit" class="btn btn-primary">Salvar</button>
        <a href="bets.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

<?php include __DIR__ . '/includes/footer_admin.php'; ?>