<?php
require_once __DIR__ . '/../includes/conexao.php';

$nome_campo  = $_POST['nome_campo'] ?? '';
$rotulo      = $_POST['rotulo'] ?? '';
$tipo        = $_POST['tipo'] ?? 'text';
$ordem       = (int)($_POST['ordem'] ?? 0);
$obrigatorio = isset($_POST['obrigatorio']) ? 1 : 0;
$ativo       = isset($_POST['ativo']) ? 1 : 0;
$opcoes_raw  = trim($_POST['opcoes'] ?? '');

// Converte opções para JSON, se aplicável
$opcoes_json = '';
if (in_array($tipo, ['select', 'checkbox', 'radio']) && !empty($opcoes_raw)) {
    $opcoes_array = array_map('trim', explode(',', $opcoes_raw));
    $opcoes_json = json_encode($opcoes_array, JSON_UNESCAPED_UNICODE);
}

$stmt = $conn->prepare("INSERT INTO formulario_campos (nome_campo, rotulo, tipo, opcoes, obrigatorio, ordem, ativo)
                        VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssiii", $nome_campo, $rotulo, $tipo, $opcoes_json, $obrigatorio, $ordem, $ativo);
$stmt->execute();

header('Location: campos.php');
exit;
