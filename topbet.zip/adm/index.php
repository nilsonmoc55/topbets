<?php
require_once __DIR__ . '/includes/verifica_admin.php';
require_once __DIR__ . '/../includes/conexao.php';

// Busca estatísticas para o dashboard
$stats = [
    'usuarios' => $conn->query("SELECT COUNT(*) as total FROM usuarios")->fetch_assoc()['total'],
    'usuarios_ativos' => $conn->query("SELECT COUNT(*) as total FROM usuarios WHERE ativo = 1")->fetch_assoc()['total'],
    'bets' => $conn->query("SELECT COUNT(*) as total FROM bets WHERE ativo = 1")->fetch_assoc()['total'],
    'avaliacoes' => $conn->query("SELECT COUNT(*) as total FROM avaliacoes")->fetch_assoc()['total'],
    'avaliacoes_pendentes' => $conn->query("SELECT COUNT(*) as total FROM avaliacoes WHERE status = 'pendente'")->fetch_assoc()['total'],
    'anuncios_ativos' => $conn->query("SELECT COUNT(*) as total FROM anuncios WHERE ativo = 1")->fetch_assoc()['total']
];

// Últimos usuários cadastrados
$ultimosUsuarios = $conn->query("
    SELECT id, nome, email, nivel_acesso, ativo, data_cadastro 
    FROM usuarios 
    ORDER BY data_cadastro DESC 
    LIMIT 5
");

// Últimas avaliações
$ultimasAvaliacoes = $conn->query("
    SELECT a.id, a.nota, a.data_avaliacao, b.nome as bet_nome, u.nome as usuario_nome
    FROM avaliacoes a
    LEFT JOIN bets b ON a.bet_id = b.id
    LEFT JOIN usuarios u ON a.usuario_id = u.id
    ORDER BY a.data_avaliacao DESC
    LIMIT 5
");
?>

<?php include __DIR__ . '/includes/header_admin.php'; ?>

<!-- Dashboard Content -->
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Dashboard</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <button type="button" class="btn btn-sm btn-outline-secondary">Exportar</button>
            <button type="button" class="btn btn-sm btn-outline-secondary">Imprimir</button>
        </div>
        <button type="button" class="btn btn-sm btn-primary">
            <i class="fas fa-sync-alt me-1"></i> Atualizar
        </button>
    </div>
</div>

<!-- Cards de Estatísticas -->
<div class="row mb-4">
    <div class="col-md-6 col-lg-3 mb-4">
        <div class="card text-white bg-primary h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Total Usuários</h6>
                        <h2 class="mb-0"><?= $stats['usuarios'] ?></h2>
                    </div>
                    <i class="fas fa-users fa-3x opacity-50"></i>
                </div>
            </div>
            <div class="card-footer bg-transparent border-top-0">
                <a href="usuarios.php" class="text-white small">Ver todos <i class="fas fa-arrow-right ms-1"></i></a>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 col-lg-3 mb-4">
        <div class="card text-white bg-success h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Casas de Aposta</h6>
                        <h2 class="mb-0"><?= $stats['bets'] ?></h2>
                    </div>
                    <i class="fas fa-chess-queen fa-3x opacity-50"></i>
                </div>
            </div>
            <div class="card-footer bg-transparent border-top-0">
                <a href="bets.php" class="text-white small">Gerenciar <i class="fas fa-arrow-right ms-1"></i></a>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 col-lg-3 mb-4">
        <div class="card text-white bg-warning h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Avaliações</h6>
                        <h2 class="mb-0"><?= $stats['avaliacoes'] ?></h2>
                    </div>
                    <i class="fas fa-star fa-3x opacity-50"></i>
                </div>
            </div>
            <div class="card-footer bg-transparent border-top-0">
                <a href="avaliacoes.php" class="text-white small">Ver todas <i class="fas fa-arrow-right ms-1"></i></a>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 col-lg-3 mb-4">
        <div class="card text-white bg-danger h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="card-title">Pendentes</h6>
                        <h2 class="mb-0"><?= $stats['avaliacoes_pendentes'] ?></h2>
                    </div>
                    <i class="fas fa-clock fa-3x opacity-50"></i>
                </div>
            </div>
            <div class="card-footer bg-transparent border-top-0">
                <a href="avaliacoes.php?filtro=pendente" class="text-white small">Moderar <i class="fas fa-arrow-right ms-1"></i></a>
            </div>
        </div>
    </div>
</div>

<!-- Últimas Atividades -->
<div class="row">
    <!-- Últimos Usuários -->
    <div class="col-lg-6 mb-4">
        <div class="card shadow h-100">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Últimos Usuários</h6>
                <a href="usuarios.php" class="btn btn-sm btn-primary">Ver Todos</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Email</th>
                                <th>Cadastro</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($usuario = $ultimosUsuarios->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($usuario['nome']) ?></td>
                                <td><?= htmlspecialchars($usuario['email']) ?></td>
                                <td><?= date('d/m/Y', strtotime($usuario['data_cadastro'])) ?></td>
                                <td>
                                    <span class="badge bg-<?= $usuario['ativo'] ? 'success' : 'secondary' ?>">
                                        <?= $usuario['ativo'] ? 'Ativo' : 'Inativo' ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Últimas Avaliações -->
    <div class="col-lg-6 mb-4">
        <div class="card shadow h-100">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Últimas Avaliações</h6>
                <a href="avaliacoes.php" class="btn btn-sm btn-primary">Ver Todas</a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Casa</th>
                                <th>Nota</th>
                                <th>Usuário</th>
                                <th>Data</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($avaliacao = $ultimasAvaliacoes->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($avaliacao['bet_nome']) ?></td>
                                <td>
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <i class="fas fa-star <?= $i <= $avaliacao['nota'] ? 'text-warning' : 'text-secondary' ?>"></i>
                                    <?php endfor; ?>
                                </td>
                                <td><?= htmlspecialchars($avaliacao['usuario_nome'] ?? 'Anônimo') ?></td>
                                <td><?= date('d/m/Y H:i', strtotime($avaliacao['data_avaliacao'])) ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
// Inclui o footer do admin
include __DIR__ . '/includes/footer_admin.php'; 
?>