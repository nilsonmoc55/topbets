<?php
require_once __DIR__ . '/includes/verifica_admin.php';
require_once __DIR__ . '/../includes/conexao.php';

// Configuração da paginação
$resultados_por_pagina = 20;
$pagina_atual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$offset = ($pagina_atual - 1) * $resultados_por_pagina;

// Processa ações via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao'])) {
    header('Content-Type: application/json');
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $response = ['success' => false, 'message' => 'Ação inválida'];
    
    try {
        switch ($_POST['acao']) {
            case 'ativar':
                $conn->query("UPDATE bets SET ativo = 1 WHERE id = $id");
                $response = ['success' => true, 'message' => 'Casa de aposta ativada com sucesso!'];
                break;
                
            case 'desativar':
                $conn->query("UPDATE bets SET ativo = 0 WHERE id = $id");
                $response = ['success' => true, 'message' => 'Casa de aposta desativada com sucesso!'];
                break;
                
            case 'excluir':
                // Remove as avaliações relacionadas primeiro
                $conn->query("DELETE FROM avaliacoes WHERE bet_id = $id");
                $conn->query("DELETE FROM bets WHERE id = $id");
                $response = ['success' => true, 'message' => 'Casa de aposta excluída com sucesso!'];
                break;
                
            case 'detalhes':
                $bet = $conn->query("SELECT * FROM bets WHERE id = $id")->fetch_assoc();
                if ($bet) {
                    ob_start();
                    ?>
                    <div class="modal-body">
                        <div class="text-center mb-3">
                            <img src="<?= htmlspecialchars($bet['logo']) ?>" alt="Logo" class="img-fluid rounded" style="max-height: 100px;">
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">ID:</div>
                            <div class="col-md-8"><?= $bet['id'] ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">Nome:</div>
                            <div class="col-md-8"><?= htmlspecialchars($bet['nome']) ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">URL:</div>
                            <div class="col-md-8">
                                <a href="<?= htmlspecialchars($bet['url']) ?>" target="_blank"><?= htmlspecialchars($bet['url']) ?></a>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">Email:</div>
                            <div class="col-md-8"><?= htmlspecialchars($bet['email']) ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">Contato:</div>
                            <div class="col-md-8"><?= htmlspecialchars($bet['contato'] ?? 'Não informado') ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">Status:</div>
                            <div class="col-md-8">
                                <span class="badge bg-<?= $bet['ativo'] ? 'success' : 'secondary' ?>">
                                    <?= $bet['ativo'] ? 'Ativo' : 'Inativo' ?>
                                </span>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">Cadastrado em:</div>
                            <div class="col-md-8"><?= date('d/m/Y H:i', strtotime($bet['data_cadastro'])) ?></div>
                        </div>
                        <?php if ($bet['descricao']): ?>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">Descrição:</div>
                            <div class="col-md-8"><?= htmlspecialchars($bet['descricao']) ?></div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <a href="editar-bet.php?id=<?= $bet['id'] ?>" class="btn btn-primary">
                            <i class="fas fa-edit"></i> Editar
                        </a>
                    </div>
                    <?php
                    $response = ['success' => true, 'html' => ob_get_clean()];
                }
                break;
        }
    } catch (mysqli_sql_exception $e) {
        $response = ['success' => false, 'message' => 'Erro no banco de dados: ' . $e->getMessage()];
    }
    
    echo json_encode($response);
    exit();
}

// Busca o total de bets
$total_bets = $conn->query("SELECT COUNT(*) as total FROM bets")->fetch_assoc()['total'];
$total_paginas = ceil($total_bets / $resultados_por_pagina);

// Busca bets com paginação
$bets = $conn->query("
    SELECT b.*, 
           COUNT(a.id) as total_avaliacoes,
           COALESCE(AVG(a.nota), 0) as media_avaliacoes
    FROM bets b
    LEFT JOIN avaliacoes a ON b.id = a.bet_id
    GROUP BY b.id
    ORDER BY b.data_cadastro DESC
    LIMIT $resultados_por_pagina OFFSET $offset
");

include __DIR__ . '/includes/header_admin.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Gerenciar Casas de Aposta</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <a href="adicionar-bet.php" class="btn btn-sm btn-primary">
                <i class="fas fa-plus"></i> Adicionar Casa
            </a>
        </div>
    </div>

    <div id="alert-container"></div>

    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Logo</th>
                    <th>Nome</th>
                    <th>Avaliações</th>
                    <th>Status</th>
                    <th>Cadastro</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($bet = $bets->fetch_assoc()): ?>
                <tr>
                    <td><?= $bet['id'] ?></td>
                    <td>
                        <img src="<?= htmlspecialchars($bet['logo']) ?>" alt="Logo" style="height: 30px; max-width: 100px; object-fit: contain;">
                    </td>
                    <td><?= htmlspecialchars($bet['nome']) ?></td>
                    <td>
                        <div class="d-flex align-items-center">
                            <?php
                            $notaInteira = floor($bet['media_avaliacoes']);
                            for ($i = 1; $i <= 5; $i++): ?>
                                <i class="fas fa-star <?= $i <= $notaInteira ? 'text-warning' : 'text-secondary' ?>"></i>
                            <?php endfor; ?>
                            <small class="ms-1">(<?= $bet['total_avaliacoes'] ?>)</small>
                        </div>
                    </td>
                    <td>
                        <span class="badge bg-<?= $bet['ativo'] ? 'success' : 'secondary' ?>">
                            <?= $bet['ativo'] ? 'Ativo' : 'Inativo' ?>
                        </span>
                    </td>
                    <td><?= date('d/m/Y', strtotime($bet['data_cadastro'])) ?></td>
                    <td>
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-info btn-detalhes" data-id="<?= $bet['id'] ?>" title="Ver detalhes">
                                <i class="fas fa-eye"></i>
                            </button>
                            <a href="editar-bet.php?id=<?= $bet['id'] ?>" class="btn btn-warning" title="Editar">
                                <i class="fas fa-edit"></i>
                            </a>
                            
                            <?php if ($bet['ativo']): ?>
                                <button class="btn btn-secondary btn-altera-status" data-id="<?= $bet['id'] ?>" data-acao="desativar" title="Desativar">
                                    <i class="fas fa-toggle-on"></i>
                                </button>
                            <?php else: ?>
                                <button class="btn btn-success btn-altera-status" data-id="<?= $bet['id'] ?>" data-acao="ativar" title="Ativar">
                                    <i class="fas fa-toggle-off"></i>
                                </button>
                            <?php endif; ?>
                            
                            <button class="btn btn-danger btn-excluir" data-id="<?= $bet['id'] ?>" title="Excluir">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Paginação -->
    <nav aria-label="Navegação de páginas">
        <ul class="pagination justify-content-center">
            <?php if ($pagina_atual > 1): ?>
                <li class="page-item">
                    <a class="page-link" href="bets.php?pagina=<?= $pagina_atual - 1 ?>" aria-label="Anterior">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
            <?php endif; ?>
            
            <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                <li class="page-item <?= $i == $pagina_atual ? 'active' : '' ?>">
                    <a class="page-link" href="bets.php?pagina=<?= $i ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
            
            <?php if ($pagina_atual < $total_paginas): ?>
                <li class="page-item">
                    <a class="page-link" href="bets.php?pagina=<?= $pagina_atual + 1 ?>" aria-label="Próximo">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
</div>

<!-- Modal para Detalhes -->
<div class="modal fade" id="detalhesModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Detalhes da Casa de Aposta</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div id="detalhesModalBody" class="modal-body">
                <!-- Conteúdo carregado via AJAX -->
            </div>
        </div>
    </div>
</div>

<!-- Modal de Confirmação -->
<div class="modal fade" id="confirmModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmModalTitle">Confirmar Ação</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="confirmModalBody">
                Tem certeza que deseja realizar esta ação?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" id="confirmAction">Confirmar</button>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer_admin.php'; ?>

<script>
$(document).ready(function() {
    // Variáveis para controle da ação
    let currentAction = '';
    let currentId = 0;
    
    // Mostrar detalhes da bet
    $('.btn-detalhes').click(function() {
        const id = $(this).data('id');
        $.post('bets.php', { acao: 'detalhes', id: id }, function(response) {
            if (response.success) {
                $('#detalhesModalBody').html(response.html);
                $('#detalhesModal').modal('show');
            } else {
                showAlert('danger', response.message);
            }
        }, 'json');
    });
    
    // Configura ação de ativar/desativar
    $('.btn-altera-status').click(function() {
        currentAction = $(this).data('acao');
        currentId = $(this).data('id');
        
        const actionText = currentAction === 'ativar' ? 'ativar' : 'desativar';
        $('#confirmModalTitle').text(`Confirmar ${actionText} casa de aposta`);
        $('#confirmModalBody').text(`Tem certeza que deseja ${actionText} esta casa de aposta?`);
        $('#confirmModal').modal('show');
    });
    
    // Configura ação de excluir
    $('.btn-excluir').click(function() {
        currentAction = 'excluir';
        currentId = $(this).data('id');
        
        $('#confirmModalTitle').text('Confirmar exclusão');
        $('#confirmModalBody').text('Tem certeza que deseja excluir esta casa de aposta? Todas as avaliações relacionadas também serão removidas!');
        $('#confirmModal').modal('show');
    });
    
    // Confirma a ação
    $('#confirmAction').click(function() {
        $('#confirmModal').modal('hide');
        
        $.post('bets.php', { 
            acao: currentAction, 
            id: currentId 
        }, function(response) {
            if (response.success) {
                showAlert('success', response.message);
                setTimeout(() => window.location.reload(), 1500);
            } else {
                showAlert('danger', response.message);
            }
        }, 'json');
    });
    
    // Função para mostrar alertas
    function showAlert(type, message) {
        const alert = $(`
            <div class="alert alert-${type} alert-dismissible fade show">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `);
        $('#alert-container').html(alert);
    }
});
</script>