<?php
require_once __DIR__ . '/includes/verifica_admin.php';
require_once __DIR__ . '/../includes/conexao.php';

// Tipos de anúncios disponíveis
$tipos_anuncio = [
    'propio' => 'Banner Próprio',
    'adsense' => 'Google AdSense',
    'adsterra' => 'AdsTerra',
    'mediavine' => 'Mediavine',
    'adthrive' => 'AdThrive',
    'ezoic' => 'Ezoic',
    'outro' => 'Outro'
];

// Posições disponíveis para exibição
$posicoes = [
    'topo' => 'Topo da Página (728x90)',
    'rodape' => 'Rodapé (728x90)',
    'sidebar' => 'Sidebar (300x250)',
    'carrossel' => 'Carrossel (1200x400)',
    'entre_posts' => 'Entre Posts (responsive)',
    'conteudo' => 'Dentro do Conteúdo (responsive)'
];

$erro = null;
$dados = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Filtragem dos dados
    $dados = filter_input_array(INPUT_POST, [
        'titulo' => FILTER_SANITIZE_STRING,
        'tipo' => FILTER_SANITIZE_STRING,
        'posicao' => FILTER_SANITIZE_STRING,
        'url' => FILTER_SANITIZE_URL,
        'codigo' => FILTER_UNSAFE_RAW,
        'paginas' => FILTER_SANITIZE_STRING,
        'data_inicio' => FILTER_SANITIZE_STRING,
        'data_fim' => FILTER_SANITIZE_STRING,
        'max_cliques' => FILTER_VALIDATE_INT,
        'max_impressoes' => FILTER_VALIDATE_INT
    ]);
    
    $dados['ativo'] = isset($_POST['ativo']) ? 1 : 0;
    
    // Validações básicas
    if (empty($dados['titulo'])) {
        $erro = 'O título é obrigatório';
    } elseif ($dados['tipo'] === 'propio' && empty($_FILES['imagem']['name'])) {
        $erro = 'Para banner próprio, a imagem é obrigatória';
    } elseif ($dados['tipo'] === 'propio' && empty($dados['url'])) {
        $erro = 'Para banner próprio, a URL de destino é obrigatória';
    } elseif ($dados['tipo'] !== 'propio' && empty($dados['codigo'])) {
        $erro = 'Para anúncios automáticos, o código é obrigatório';
    }

    if (!$erro) {
        // Processar upload de imagem se for banner próprio
        $imagem = null;
        if ($dados['tipo'] === 'propio' && isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
            $extensoes = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $extensao = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));
            
            if (in_array($extensao, $extensoes)) {
                $nome_arquivo = 'banner-' . uniqid() . '.' . $extensao;
                $diretorio = __DIR__ . '/../img/banners/';
                
                if (!is_dir($diretorio)) {
                    mkdir($diretorio, 0755, true);
                }
                
                if (move_uploaded_file($_FILES['imagem']['tmp_name'], $diretorio . $nome_arquivo)) {
                    $imagem = 'img/banners/' . $nome_arquivo;
                } else {
                    $erro = 'Erro ao fazer upload da imagem';
                }
            } else {
                $erro = 'Formato de imagem não suportado. Use JPG, PNG, GIF ou WEBP';
            }
        }
        
        if (!$erro) {
    try {
        // Preparar a declaração SQL
        $stmt = $conn->prepare("INSERT INTO anuncios (
            titulo, tipo, codigo, imagem, url, posicao, paginas, 
            ativo, data_inicio, data_fim, max_cliques, max_impressoes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        // Criar variáveis não-nulas para bind_param
        $data_inicio = !empty($dados['data_inicio']) ? $dados['data_inicio'] : null;
        $data_fim = !empty($dados['data_fim']) ? $dados['data_fim'] : null;
        $max_cliques = !empty($dados['max_cliques']) ? $dados['max_cliques'] : null;
        $max_impressoes = !empty($dados['max_impressoes']) ? $dados['max_impressoes'] : null;
        
        // Corrigido: Converter valores null para strings vazias (se necessário)
        $imagem = $imagem ?? null; // Garante que $imagem seja null se não existir
        
        // Vincular parâmetros (ATENÇÃO à ordem e tipos)
        $stmt->bind_param(
            "sssssssisssi", // Tipos: s=string, i=integer
            $dados['titulo'],
            $dados['tipo'],
            $dados['codigo'],
            $imagem,
            $dados['url'],
            $dados['posicao'],
            $dados['paginas'],
            $dados['ativo'],
            $data_inicio,
            $data_fim,
            $max_cliques,
            $max_impressoes
        );
        
        if ($stmt->execute()) {
            $_SESSION['msg'] = [
                'tipo' => 'success',
                'texto' => 'Anúncio cadastrado com sucesso!'
            ];
            header('Location: anuncios.php');
            exit();
        }
    } catch (mysqli_sql_exception $e) {
        $erro = 'Erro ao cadastrar anúncio: ' . $e->getMessage();
    }
}
    }
}

include __DIR__ . '/includes/header_admin.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Adicionar Novo Anúncio</h1>
        <a href="anuncios.php" class="btn btn-secondary">Voltar</a>
    </div>

    <?php if ($erro): ?>
        <div class="alert alert-danger"><?= $erro ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
        <div class="row">
            <div class="col-md-6">
                <!-- Informações Básicas -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Informações Básicas</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="titulo" class="form-label">Título do Anúncio*</label>
                            <input type="text" class="form-control" id="titulo" name="titulo" required
                                   value="<?= htmlspecialchars($dados['titulo'] ?? '') ?>">
                            <div class="invalid-feedback">Por favor, insira um título.</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="tipo" class="form-label">Tipo de Anúncio*</label>
                            <select class="form-select" id="tipo" name="tipo" required>
                                <?php foreach ($tipos_anuncio as $valor => $texto): ?>
                                    <option value="<?= $valor ?>" <?= ($dados['tipo'] ?? '') === $valor ? 'selected' : '' ?>>
                                        <?= $texto ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="posicao" class="form-label">Posição*</label>
                            <select class="form-select" id="posicao" name="posicao" required>
                                <?php foreach ($posicoes as $valor => $texto): ?>
                                    <option value="<?= $valor ?>" <?= ($dados['posicao'] ?? '') === $valor ? 'selected' : '' ?>>
                                        <?= $texto ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="paginas" class="form-label">Páginas Específicas (opcional)</label>
                            <input type="text" class="form-control" id="paginas" name="paginas"
                                   value="<?= htmlspecialchars($dados['paginas'] ?? '') ?>"
                                   placeholder="IDs separados por vírgula (ex: 1,5,7)">
                            <small class="text-muted">Deixe em branco para exibir em todas as páginas</small>
                        </div>
                        
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="ativo" name="ativo" 
                                   <?= isset($dados['ativo']) && $dados['ativo'] ? 'checked' : 'checked' ?>>
                            <label class="form-check-label" for="ativo">Ativo</label>
                        </div>
                    </div>
                </div>
                
                <!-- Configurações de Banner Próprio -->
                <div class="card mb-4" id="card-banner-propio">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">Configurações de Banner Próprio</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="imagem" class="form-label">Imagem do Banner*</label>
                            <input type="file" class="form-control" id="imagem" name="imagem" accept="image/*">
                            <small class="text-muted">Formatos aceitos: JPG, PNG, GIF, WEBP</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="url" class="form-label">URL de Destino*</label>
                            <input type="url" class="form-control" id="url" name="url"
                                   value="<?= htmlspecialchars($dados['url'] ?? '') ?>"
                                   placeholder="https://www.exemplo.com">
                        </div>
                        
                        <div class="alert alert-warning">
                            <strong>Dimensões recomendadas:</strong><br>
                            <ul>
                                <li>Topo/Rodapé: 728x90 pixels</li>
                                <li>Sidebar: 300x250 pixels</li>
                                <li>Carrossel: 1200x400 pixels</li>
                                <li>Entre Posts: 600x300 pixels</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-6">
                <!-- Configurações de Anúncios Automáticos -->
                <div class="card mb-4" id="card-anuncios-automaticos">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">Configurações de Anúncios Automáticos</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="codigo" class="form-label">Código do Anúncio*</label>
                            <textarea class="form-control" id="codigo" name="codigo" rows="12"
                                      placeholder="Cole aqui o código fornecido pela plataforma de anúncios"><?= 
                                      htmlspecialchars($dados['codigo'] ?? '') ?></textarea>
                        </div>
                        
                        <div class="alert alert-info">
                            <strong>Plataformas suportadas:</strong>
                            <ul>
                                <li><strong>Google AdSense:</strong> Cole o código completo do ad unit</li>
                                <li><strong>AdsTerra:</strong> Insira o código de banner ou popunder</li>
                                <li><strong>Mediavine/AdThrive/Ezoic:</strong> Cole o código de integração</li>
                                <li><strong>Outros:</strong> Insira qualquer código HTML/JavaScript válido</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Configurações Avançadas -->
                <div class="card mb-4">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0">Configurações Avançadas</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="data_inicio" class="form-label">Data de Início</label>
                                <input type="date" class="form-control" id="data_inicio" name="data_inicio"
                                       value="<?= htmlspecialchars($dados['data_inicio'] ?? '') ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="data_fim" class="form-label">Data de Término</label>
                                <input type="date" class="form-control" id="data_fim" name="data_fim"
                                       value="<?= htmlspecialchars($dados['data_fim'] ?? '') ?>">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="max_cliques" class="form-label">Máximo de Cliques</label>
                                <input type="number" class="form-control" id="max_cliques" name="max_cliques"
                                       value="<?= htmlspecialchars($dados['max_cliques'] ?? '') ?>"
                                       min="0" placeholder="Deixe em branco para ilimitado">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="max_impressoes" class="form-label">Máximo de Impressões</label>
                                <input type="number" class="form-control" id="max_impressoes" name="max_impressoes"
                                       value="<?= htmlspecialchars($dados['max_impressoes'] ?? '') ?>"
                                       min="0" placeholder="Deixe em branco para ilimitado">
                            </div>
                        </div>
                        
                        <div class="alert alert-secondary">
                            <strong>Dicas:</strong>
                            <ul>
                                <li>Use datas para campanhas temporárias</li>
                                <li>Limite de cliques/impressões para controle de orçamento</li>
                                <li>Deixe ambos em branco para exibição contínua</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-save"></i> Salvar Anúncio
                    </button>
                    <a href="anuncios.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancelar
                    </a>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Mostrar/ocultar campos conforme o tipo de anúncio
    const tipoAnuncio = document.getElementById('tipo');
    const cardBanner = document.getElementById('card-banner-propio');
    const cardAutomatico = document.getElementById('card-anuncios-automaticos');
    
    function atualizarCampos() {
        if (tipoAnuncio.value === 'propio') {
            cardBanner.style.display = 'block';
            cardAutomatico.style.display = 'none';
            document.getElementById('imagem').required = true;
            document.getElementById('url').required = true;
            document.getElementById('codigo').required = false;
        } else {
            cardBanner.style.display = 'none';
            cardAutomatico.style.display = 'block';
            document.getElementById('imagem').required = false;
            document.getElementById('url').required = false;
            document.getElementById('codigo').required = true;
        }
    }
    
    // Atualizar na mudança e no carregamento
    tipoAnuncio.addEventListener('change', atualizarCampos);
    atualizarCampos();
    
    // Validação do formulário
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });
});
</script>

<?php include __DIR__ . '/includes/footer_admin.php'; ?>