<?php
require_once __DIR__ . '/includes/verifica_admin.php';
require_once __DIR__ . '/../includes/conexao.php';

$nivel_usuario_logado = $_SESSION['usuario_nivel'];
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

// Busca o usuário
$usuario = $conn->query("SELECT * FROM usuarios WHERE id = $id")->fetch_assoc();

// Verifica permissões
if ($nivel_usuario_logado != 3 && $usuario['nivel_acesso'] != 1) {
    $_SESSION['erro'] = 'Você não tem permissão para editar este usuário!';
    header('Location: usuarios.php');
    exit();
}

// Processa o formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $nivel_acesso = ($nivel_usuario_logado == 3) ? 
        filter_input(INPUT_POST, 'nivel_acesso', FILTER_VALIDATE_INT) : $usuario['nivel_acesso'];
    $ativo = isset($_POST['ativo']) ? 1 : 0;
    
    // Atualiza senha apenas se foi informada
    $senha_sql = '';
    if (!empty($_POST['senha'])) {
        $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
        $senha_sql = ", senha = '$senha'";
    }

    try {
        $conn->query("UPDATE usuarios SET 
            nome = '$nome', 
            email = '$email', 
            nivel_acesso = $nivel_acesso, 
            ativo = $ativo
            $senha_sql
            WHERE id = $id");
        
        $_SESSION['msg'] = 'Usuário atualizado com sucesso!';
        header('Location: usuarios.php');
        exit();
    } catch (mysqli_sql_exception $e) {
        $erro = 'Erro ao atualizar usuário: ' . $e->getMessage();
    }
}

include __DIR__ . '/includes/header_admin.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Editar Usuário</h1>
    </div>

    <?php if (isset($erro)): ?>
        <div class="alert alert-danger"><?= $erro ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="mb-3">
            <label for="nome" class="form-label">Nome Completo</label>
            <input type="text" class="form-control" id="nome" name="nome" value="<?= htmlspecialchars($usuario['nome']) ?>" required>
        </div>
        
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($usuario['email']) ?>" required>
        </div>
        
        <div class="mb-3">
            <label for="senha" class="form-label">Nova Senha (deixe em branco para manter a atual)</label>
            <input type="password" class="form-control" id="senha" name="senha">
        </div>
        
        <?php if ($nivel_usuario_logado == 3): ?>
            <div class="mb-3">
                <label for="nivel_acesso" class="form-label">Nível de Acesso</label>
                <select class="form-select" id="nivel_acesso" name="nivel_acesso">
                    <option value="1" <?= $usuario['nivel_acesso'] == 1 ? 'selected' : '' ?>>Usuário</option>
                    <option value="2" <?= $usuario['nivel_acesso'] == 2 ? 'selected' : '' ?>>Moderador</option>
                    <option value="3" <?= $usuario['nivel_acesso'] == 3 ? 'selected' : '' ?>>Administrador</option>
                </select>
            </div>
        <?php endif; ?>
        
        <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="ativo" name="ativo" <?= $usuario['ativo'] ? 'checked' : '' ?>>
            <label class="form-check-label" for="ativo">Ativo</label>
        </div>
        
        <button type="submit" class="btn btn-primary">Salvar</button>
        <a href="usuarios.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

<?php include __DIR__ . '/includes/footer_admin.php'; ?>