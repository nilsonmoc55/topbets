<?php
require_once __DIR__ . '/includes/verifica_admin.php';
require_once __DIR__ . '/../includes/conexao.php';

$tipos = ['adsense' => 'AdSense', 'adsterra' => 'AdsTerra', 'propio' => 'Banner Próprio', 'outro' => 'Outro'];
$posicoes = [
    'topo' => 'Topo da Página', 
    'rodape' => 'Rodapé', 
    'sidebar' => 'Sidebar', 
    'carrossel' => 'Carrossel', 
    'entre_posts' => 'Entre Posts'
];

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$anuncio = null;

if ($id) {
    $stmt = $conn->prepare("SELECT * FROM anuncios WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $anuncio = $result->fetch_assoc();
}

if (!$anuncio) {
    $_SESSION['msg'] = [
        'tipo' => 'danger',
        'texto' => 'Anúncio não encontrado!'
    ];
    header('Location: anuncios.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dados = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
    $dados['ativo'] = isset($_POST['ativo']) ? 1 : 0;
    
    // Processar upload de imagem se for banner próprio
    $imagem = $anuncio['imagem'];
    if ($dados['tipo'] === 'propio' && isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION);
        $nomeArquivo = 'banner-' . uniqid() . '.' . $ext;
        $diretorio = __DIR__ . '/../img/banners/';
        
        if (!is_dir($diretorio)) {
            mkdir($diretorio, 0755, true);
        }
        
        if (move_uploaded_file($_FILES['imagem']['tmp_name'], $diretorio . $nomeArquivo)) {
            // Remove a imagem antiga se não for a default
            if ($imagem && $imagem !== 'img/logos/default.png') {
                @unlink(__DIR__ . '/../' . $imagem);
            }
            $imagem = 'img/banners/' . $nomeArquivo;
        }
    }
    
    try {
        $stmt = $conn->prepare("UPDATE anuncios SET 
            titulo = ?, tipo = ?, codigo = ?, imagem = ?, url = ?, posicao = ?, paginas = ?, 
            ativo = ?, data_inicio = ?, data_fim = ?, max_cliques = ?, max_impressoes = ? 
            WHERE id = ?");
        
        $stmt->bind_param("sssssssisssii", 
            $dados['titulo'],
            $dados['tipo'],
            $dados['codigo'] ?? null,
            $imagem,
            $dados['url'] ?? null,
            $dados['posicao'],
            $dados['paginas'] ?? null,
            $dados['ativo'],
            $dados['data_inicio'] ?: null,
            $dados['data_fim'] ?: null,
            $dados['max_cliques'] ?: null,
            $dados['max_impressoes'] ?: null,
            $id
        );
        
        $stmt->execute();
        
        $_SESSION['msg'] = [
            'tipo' => 'success',
            'texto' => 'Anúncio atualizado com sucesso!'
        ];
        header('Location: anuncios.php');
        exit();
    } catch (Exception $e) {
        $erro = 'Erro ao atualizar anúncio: ' . $e->getMessage();
    }
}

include __DIR__ . '/includes/header_admin.php';
?>

 <form method="POST" enctype="multipart/form-data">
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="titulo" class="form-label">Título*</label>
                    <input type="text" class="form-control" id="titulo" name="titulo" required>
                </div>
                
                <div class="mb-3">
                    <label for="tipo" class="form-label">Tipo de Anúncio*</label>
                    <select class="form-select" id="tipo" name="tipo" required>
                        <?php foreach ($tipos as $valor => $texto): ?>
                            <option value="<?= $valor ?>"><?= $texto ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mb-3" id="campo-codigo">
                    <label for="codigo" class="form-label">Código do Anúncio</label>
                    <textarea class="form-control" id="codigo" name="codigo" rows="5"></textarea>
                    <small class="text-muted">Cole aqui o código do AdSense, AdsTerra, etc.</small>
                </div>
                
                <div class="mb-3 d-none" id="campo-imagem">
                    <label for="imagem" class="form-label">Imagem do Banner*</label>
                    <input type="file" class="form-control" id="imagem" name="imagem" accept="image/*">
                    <small class="text-muted">Tamanho recomendado conforme a posição escolhida</small>
                </div>
                
                <div class="mb-3 d-none" id="campo-url">
                    <label for="url" class="form-label">URL de Destino*</label>
                    <input type="url" class="form-control" id="url" name="url">
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="posicao" class="form-label">Posição*</label>
                    <select class="form-select" id="posicao" name="posicao" required>
                        <?php foreach ($posicoes as $valor => $texto): ?>
                            <option value="<?= $valor ?>"><?= $texto ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label for="paginas" class="form-label">Páginas Específicas (opcional)</label>
                    <input type="text" class="form-control" id="paginas" name="paginas">
                    <small class="text-muted">IDs das páginas separados por vírgula (ex: 1,5,7)</small>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="data_inicio" class="form-label">Data de Início</label>
                            <input type="date" class="form-control" id="data_inicio" name="data_inicio">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="data_fim" class="form-label">Data de Término</label>
                            <input type="date" class="form-control" id="data_fim" name="data_fim">
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="max_cliques" class="form-label">Máx. de Cliques</label>
                            <input type="number" class="form-control" id="max_cliques" name="max_cliques">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="max_impressoes" class="form-label">Máx. de Impressões</label>
                            <input type="number" class="form-control" id="max_impressoes" name="max_impressoes">
                        </div>
                    </div>
                </div>
                
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="ativo" name="ativo" checked>
                    <label class="form-check-label" for="ativo">Ativo</label>
                </div>
            </div>
        </div>
        
        <button type="submit" class="btn btn-primary">Salvar Anúncio</button>
        <a href="anuncios.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>

<script>
document.getElementById('tipo').addEventListener('change', function() {
    const tipo = this.value;
    const campoCodigo = document.getElementById('campo-codigo');
    const campoImagem = document.getElementById('campo-imagem');
    const campoUrl = document.getElementById('campo-url');
    
    // Reset all fields
    campoCodigo.classList.add('d-none');
    campoImagem.classList.add('d-none');
    campoUrl.classList.add('d-none');
    
    if (tipo === 'propio') {
        campoImagem.classList.remove('d-none');
        campoUrl.classList.remove('d-none');
        campoImagem.querySelector('input').required = true;
        campoUrl.querySelector('input').required = true;
    } else if (tipo === 'adsense' || tipo === 'adsterra' || tipo === 'outro') {
        campoCodigo.classList.remove('d-none');
    }
});

// Trigger change event on load
document.getElementById('tipo').dispatchEvent(new Event('change'));
</script>

<?php include __DIR__ . '/includes/footer_admin.php'; ?>