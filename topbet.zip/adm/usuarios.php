<?php
require_once __DIR__ . '/includes/verifica_admin.php';
require_once __DIR__ . '/../includes/conexao.php';

// Verifica nível de acesso do usuário logado
$nivel_usuario_logado = $_SESSION['usuario_nivel'];

// Configuração da paginação
$resultados_por_pagina = 20;
$pagina_atual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$offset = ($pagina_atual - 1) * $resultados_por_pagina;

// Processa ações via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao'])) {
    header('Content-Type: application/json');
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $response = ['success' => false, 'message' => 'Ação inválida'];
    
    try {
        switch ($_POST['acao']) {
            case 'ativar':
                $conn->query("UPDATE usuarios SET ativo = 1 WHERE id = $id");
                $response = ['success' => true, 'message' => 'Usuário ativado com sucesso!'];
                break;
                
            case 'desativar':
                $conn->query("UPDATE usuarios SET ativo = 0 WHERE id = $id");
                $response = ['success' => true, 'message' => 'Usuário desativado com sucesso!'];
                break;
                
            case 'excluir':
                if ($id != $_SESSION['usuario_id']) {
                    // Remove as referências primeiro
                    $conn->query("UPDATE avaliacoes SET usuario_id = NULL WHERE usuario_id = $id");
                    $conn->query("DELETE FROM usuarios WHERE id = $id");
                    $response = ['success' => true, 'message' => 'Usuário excluído com sucesso!'];
                } else {
                    $response = ['success' => false, 'message' => 'Você não pode excluir a si mesmo!'];
                }
                break;
                
            case 'detalhes':
                $usuario = $conn->query("SELECT * FROM usuarios WHERE id = $id")->fetch_assoc();
                if ($usuario) {
                    ob_start();
                    ?>
                    <div class="modal-body">
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">ID:</div>
                            <div class="col-md-8"><?= $usuario['id'] ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">Nome:</div>
                            <div class="col-md-8"><?= htmlspecialchars($usuario['nome']) ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">Email:</div>
                            <div class="col-md-8"><?= htmlspecialchars($usuario['email']) ?></div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">Tipo:</div>
                            <div class="col-md-8">
                                <?php
                                $tipos = [1 => 'Usuário', 2 => 'Moderador', 3 => 'Administrador'];
                                echo $tipos[$usuario['nivel_acesso']] ?? 'Desconhecido';
                                ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">Status:</div>
                            <div class="col-md-8">
                                <span class="badge bg-<?= $usuario['ativo'] ? 'success' : 'secondary' ?>">
                                    <?= $usuario['ativo'] ? 'Ativo' : 'Inativo' ?>
                                </span>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4 fw-bold">Cadastrado em:</div>
                            <div class="col-md-8"><?= date('d/m/Y H:i', strtotime($usuario['data_cadastro'])) ?></div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <?php if ($nivel_usuario_logado == 3 || $usuario['nivel_acesso'] == 1): ?>
                            <a href="editar-usuario.php?id=<?= $usuario['id'] ?>" class="btn btn-primary">
                                <i class="fas fa-edit"></i> Editar
                            </a>
                        <?php endif; ?>
                    </div>
                    <?php
                    $response = ['success' => true, 'html' => ob_get_clean()];
                }
                break;
        }
    } catch (mysqli_sql_exception $e) {
        $response = ['success' => false, 'message' => 'Erro no banco de dados: ' . $e->getMessage()];
    }
    
    echo json_encode($response);
    exit();
}

// Busca o total de usuários
$total_usuarios = $conn->query("SELECT COUNT(*) as total FROM usuarios")->fetch_assoc()['total'];
$total_paginas = ceil($total_usuarios / $resultados_por_pagina);

// Busca usuários com paginação
$usuarios = $conn->query("
    SELECT id, nome, email, nivel_acesso, ativo, data_cadastro 
    FROM usuarios 
    ORDER BY data_cadastro DESC
    LIMIT $resultados_por_pagina OFFSET $offset
");

include __DIR__ . '/includes/header_admin.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Gerenciar Usuários</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <?php if ($nivel_usuario_logado == 3): ?>
                <a href="adicionar-usuario.php" class="btn btn-sm btn-primary">
                    <i class="fas fa-plus"></i> Adicionar Usuário
                </a>
            <?php endif; ?>
        </div>
    </div>

    <div id="alert-container"></div>

    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Tipo</th>
                    <th>Status</th>
                    <th>Cadastro</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($usuario = $usuarios->fetch_assoc()): ?>
                <tr>
                    <td><?= $usuario['id'] ?></td>
                    <td><?= htmlspecialchars($usuario['nome']) ?></td>
                    <td><?= htmlspecialchars($usuario['email']) ?></td>
                    <td>
                        <?php
                        $badgeClass = [
                            1 => 'bg-secondary',
                            2 => 'bg-warning text-dark',
                            3 => 'bg-danger'
                        ];
                        $tipoUsuario = [
                            1 => 'Usuário',
                            2 => 'Moderador',
                            3 => 'Administrador'
                        ];
                        ?>
                        <span class="badge <?= $badgeClass[$usuario['nivel_acesso']] ?>">
                            <?= $tipoUsuario[$usuario['nivel_acesso']] ?>
                        </span>
                    </td>
                    <td>
                        <span class="badge bg-<?= $usuario['ativo'] ? 'success' : 'secondary' ?>">
                            <?= $usuario['ativo'] ? 'Ativo' : 'Inativo' ?>
                        </span>
                    </td>
                    <td><?= date('d/m/Y H:i', strtotime($usuario['data_cadastro'])) ?></td>
                    <td>
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-info btn-detalhes" data-id="<?= $usuario['id'] ?>" title="Ver detalhes">
                                <i class="fas fa-eye"></i>
                            </button>
                            
                            <?php if ($nivel_usuario_logado == 3 || $usuario['nivel_acesso'] == 1): ?>
                                <a href="editar-usuario.php?id=<?= $usuario['id'] ?>" class="btn btn-warning" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </a>
                            <?php endif; ?>
                            
                            <?php if ($usuario['ativo']): ?>
                                <button class="btn btn-secondary btn-altera-status" data-id="<?= $usuario['id'] ?>" data-acao="desativar" title="Desativar">
                                    <i class="fas fa-toggle-on"></i>
                                </button>
                            <?php else: ?>
                                <button class="btn btn-success btn-altera-status" data-id="<?= $usuario['id'] ?>" data-acao="ativar" title="Ativar">
                                    <i class="fas fa-toggle-off"></i>
                                </button>
                            <?php endif; ?>
                            
                            <button class="btn btn-danger btn-excluir" data-id="<?= $usuario['id'] ?>" title="Excluir" <?= $usuario['id'] == $_SESSION['usuario_id'] ? 'disabled' : '' ?>>
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Paginação e Modais permanecem iguais -->
    <?php include __DIR__ . '/includes/paginacao.php'; ?>
    <?php include __DIR__ . '/includes/modais_usuarios.php'; ?>
</div>

<?php include __DIR__ . '/includes/footer_admin.php'; ?>