<?php
require_once __DIR__ . '/includes/verifica_admin.php';
require_once __DIR__ . '/../includes/conexao.php';

// Processa o formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
    $url = filter_input(INPUT_POST, 'url', FILTER_SANITIZE_URL);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $contato = filter_input(INPUT_POST, 'contato', FILTER_SANITIZE_STRING);
    $descricao = filter_input(INPUT_POST, 'descricao', FILTER_SANITIZE_STRING);
    $ativo = isset($_POST['ativo']) ? 1 : 0;

    // Validação dos campos obrigatórios
    if (empty($nome) || empty($url) || empty($email)) {
        $erro = 'Por favor, preencha todos os campos obrigatórios marcados com *';
    } else {
        // Processa upload da logo
        $logo = 'img/logos/default.png';
        if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
            $extensoesPermitidas = ['jpg', 'jpeg', 'png', 'gif'];
            $extensao = strtolower(pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION));
            
            // Verifica se a extensão é permitida
            if (in_array($extensao, $extensoesPermitidas)) {
                $nome_arquivo = 'bet-' . uniqid() . '.' . $extensao;
                $diretorio = __DIR__ . '/../img/logos/';
                
                // Cria o diretório se não existir
                if (!is_dir($diretorio)) {
                    mkdir($diretorio, 0755, true);
                }
                
                // Move o arquivo para o diretório
                if (move_uploaded_file($_FILES['logo']['tmp_name'], $diretorio . $nome_arquivo)) {
                    $logo = 'img/logos/' . $nome_arquivo;
                } else {
                    $erro = 'Erro ao fazer upload da imagem.';
                }
            } else {
                $erro = 'Formato de imagem não suportado. Use JPG, PNG ou GIF.';
            }
        }

        if (!isset($erro)) {
            try {
                $stmt = $conn->prepare("INSERT INTO bets (nome, url, email, logo, descricao, ativo, contato) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("sssssis", $nome, $url, $email, $logo, $descricao, $ativo, $contato);
                $stmt->execute();
                
                $_SESSION['msg'] = [
                    'tipo' => 'success',
                    'texto' => 'Casa de aposta cadastrada com sucesso!'
                ];
                header('Location: bets.php');
                exit();
            } catch (mysqli_sql_exception $e) {
                $erro = 'Erro ao cadastrar casa de aposta: ' . $e->getMessage();
            }
        }
    }
}

include __DIR__ . '/includes/header_admin.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Adicionar Nova Casa de Aposta</h1>
        <a href="bets.php" class="btn btn-secondary">Voltar</a>
    </div>

    <?php if (isset($erro)): ?>
        <div class="alert alert-danger"><?= $erro ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="nome" class="form-label">Nome*</label>
                    <input type="text" class="form-control" id="nome" name="nome" required
                           value="<?= isset($_POST['nome']) ? htmlspecialchars($_POST['nome']) : '' ?>">
                </div>
                
                <div class="mb-3">
                    <label for="url" class="form-label">URL*</label>
                    <input type="url" class="form-control" id="url" name="url" required
                           value="<?= isset($_POST['url']) ? htmlspecialchars($_POST['url']) : '' ?>">
                </div>
                
                <div class="mb-3">
                    <label for="email" class="form-label">Email*</label>
                    <input type="email" class="form-control" id="email" name="email" required
                           value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
                </div>
                
                <div class="mb-3">
                    <label for="contato" class="form-label">Contato</label>
                    <input type="text" class="form-control" id="contato" name="contato"
                           value="<?= isset($_POST['contato']) ? htmlspecialchars($_POST['contato']) : '' ?>">
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="mb-3">
                    <label for="logo" class="form-label">Logo</label>
                    <input type="file" class="form-control" id="logo" name="logo" accept="image/*">
                    <small class="text-muted">Formatos aceitos: JPG, PNG, GIF. Tamanho recomendado: 300x150 pixels</small>
                    <?php if (isset($logo) && $logo !== 'img/logos/default.png'): ?>
                        <div class="mt-2">
                            <img src="../<?= $logo ?>" alt="Pré-visualização" style="max-height: 100px;">
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="mb-3">
                    <label for="descricao" class="form-label">Descrição</label>
                    <textarea class="form-control" id="descricao" name="descricao" rows="3"><?= isset($_POST['descricao']) ? htmlspecialchars($_POST['descricao']) : '' ?></textarea>
                </div>
                
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="ativo" name="ativo" value="1" <?= isset($_POST['ativo']) ? 'checked' : '' ?>>
                    <label class="form-check-label" for="ativo">Ativo</label>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                <button type="submit" class="btn btn-primary">Salvar</button>
                <a href="bets.php" class="btn btn-secondary">Cancelar</a>
            </div>
        </div>
    </form>
</div>

<?php include __DIR__ . '/includes/footer_admin.php'; ?>