<?php
require_once __DIR__ . '/../includes/verifica_admin.php';
require_once __DIR__ . '/../includes/conexao.php';

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['adicionar_campo'])) {
        // Adicionar novo campo
        $dados = filter_input_array(INPUT_POST, [
            'nome_campo' => FILTER_SANITIZE_STRING,
            'rotulo' => FILTER_SANITIZE_STRING,
            'tipo' => FILTER_SANITIZE_STRING,
            'opcoes' => FILTER_SANITIZE_STRING,
            'obrigatorio' => FILTER_VALIDATE_BOOLEAN
        ]);
        
        $opcoes_json = null;
        if (in_array($dados['tipo'], ['select', 'checkbox', 'radio'])) {
            $opcoes = explode("\n", trim($dados['opcoes']));
            $opcoes_json = json_encode(array_map('trim', $opcoes));
        }
        
        $stmt = $conn->prepare("INSERT INTO formulario_campos 
                              (nome_campo, rotulo, tipo, opcoes, obrigatorio) 
                              VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssi", 
            $dados['nome_campo'],
            $dados['rotulo'],
            $dados['tipo'],
            $opcoes_json,
            $dados['obrigatorio']
        );
        $stmt->execute();
    }
    
    // Atualizar ordem ou status
    if (isset($_POST['atualizar_ordem'])) {
        foreach ($_POST['ordem'] as $id => $ordem) {
            $ativo = isset($_POST['ativo'][$id]) ? 1 : 0;
            $conn->query("UPDATE formulario_campos SET ordem = $ordem, ativo = $ativo WHERE id = $id");
        }
    }
}

// Obter campos existentes
$campos = $conn->query("SELECT * FROM formulario_campos ORDER BY ordem ASC");
?>

<div class="container-fluid">
    <h2>Gerenciar Campos do Formulário</h2>
    
    <!-- Formulário para adicionar novo campo -->
    <div class="card mb-4">
        <div class="card-header">Adicionar Novo Campo</div>
        <div class="card-body">
            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">Nome Técnico*</label>
                        <input type="text" name="nome_campo" class="form-control" 
                               placeholder="sem_espacos" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Rótulo*</label>
                        <input type="text" name="rotulo" class="form-control" 
                               placeholder="Texto visível" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Tipo*</label>
                        <select name="tipo" class="form-select" id="tipoCampo" required>
                            <option value="text">Texto</option>
                            <option value="number">Número</option>
                            <option value="email">E-mail</option>
                            <option value="textarea">Área de Texto</option>
                            <option value="select">Seleção</option>
                            <option value="checkbox">Checkbox</option>
                            <option value="radio">Radio</option>
                        </select>
                    </div>
                    <div class="col-md-4" id="opcoesContainer" style="display:none;">
                        <label class="form-label">Opções (uma por linha)</label>
                        <textarea name="opcoes" class="form-control" rows="3"></textarea>
                    </div>
                </div>
                <div class="mt-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="obrigatorio" id="obrigatorio">
                        <label class="form-check-label" for="obrigatorio">Campo obrigatório</label>
                    </div>
                </div>
                <button type="submit" name="adicionar_campo" class="btn btn-primary mt-3">
                    Adicionar Campo
                </button>
            </form>
        </div>
    </div>
    
    <!-- Lista de campos existentes -->
    <div class="card">
        <div class="card-header">Campos do Formulário</div>
        <div class="card-body">
            <form method="POST">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th width="50">Ordem</th>
                            <th>Rótulo</th>
                            <th>Tipo</th>
                            <th>Obrigatório</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($campo = $campos->fetch_assoc()): ?>
                        <tr>
                            <td>
                                <input type="number" name="ordem[<?= $campo['id'] ?>]" 
                                       value="<?= $campo['ordem'] ?>" class="form-control">
                            </td>
                            <td><?= htmlspecialchars($campo['rotulo']) ?></td>
                            <td><?= $campo['tipo'] ?></td>
                            <td><?= $campo['obrigatorio'] ? 'Sim' : 'Não' ?></td>
                            <td>
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" 
                                           name="ativo[<?= $campo['id'] ?>]" 
                                           <?= $campo['ativo'] ? 'checked' : '' ?>>
                                </div>
                            </td>
                            <td>
                                <a href="editar-campo.php?id=<?= $campo['id'] ?>" 
                                   class="btn btn-sm btn-warning">Editar</a>
                                <a href="excluir-campo.php?id=<?= $campo['id'] ?>" 
                                   class="btn btn-sm btn-danger" 
                                   onclick="return confirm('Tem certeza?')">Excluir</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                <button type="submit" name="atualizar_ordem" class="btn btn-success">
                    Salvar Ordem e Status
                </button>
            </form>
        </div>
    </div>
</div>

<script>
// Mostrar/ocultar campo de opções conforme o tipo selecionado
document.getElementById('tipoCampo').addEventListener('change', function() {
    const tiposComOpcoes = ['select', 'checkbox', 'radio'];
    const opcoesContainer = document.getElementById('opcoesContainer');
    
    if (tiposComOpcoes.includes(this.value)) {
        opcoesContainer.style.display = 'block';
    } else {
        opcoesContainer.style.display = 'none';
    }
});
</script>