<?php
require_once __DIR__ . '/includes/verifica_admin.php';
require_once __DIR__ . '/../includes/conexao.php';

// Configurações de paginação
$resultados_por_pagina = 10;
$pagina_atual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$offset = ($pagina_atual - 1) * $resultados_por_pagina;

// Processar ações de ativar/desativar/excluir
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao'])) {
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    
    try {
        switch ($_POST['acao']) {
            case 'ativar':
                $conn->query("UPDATE anuncios SET ativo = 1 WHERE id = $id");
                $_SESSION['msg'] = ['tipo' => 'success', 'texto' => 'Anúncio ativado com sucesso!'];
                break;
                
            case 'desativar':
                $conn->query("UPDATE anuncios SET ativo = 0 WHERE id = $id");
                $_SESSION['msg'] = ['tipo' => 'success', 'texto' => 'Anúncio desativado com sucesso!'];
                break;
                
            case 'excluir':
                // Remove a imagem associada se existir
                $anuncio = $conn->query("SELECT imagem FROM anuncios WHERE id = $id")->fetch_assoc();
                if ($anuncio['imagem'] && file_exists("../".$anuncio['imagem'])) {
                    unlink("../".$anuncio['imagem']);
                }
                
                $conn->query("DELETE FROM anuncios WHERE id = $id");
                $_SESSION['msg'] = ['tipo' => 'success', 'texto' => 'Anúncio excluído com sucesso!'];
                break;
        }
        
        header('Location: anuncios.php');
        exit();
    } catch (mysqli_sql_exception $e) {
        $erro = 'Erro: ' . $e->getMessage();
    }
}

// Filtros e ordenação
$filtro = isset($_GET['filtro']) ? $_GET['filtro'] : 'todos';
$ordenacao = isset($_GET['ordenar']) ? $_GET['ordenar'] : 'recentes';

$where = '';
switch ($filtro) {
    case 'ativos':
        $where = "WHERE ativo = 1";
        break;
    case 'inativos':
        $where = "WHERE ativo = 0";
        break;
    case 'carrossel':
        $where = "WHERE posicao = 'carrossel'";
        break;
    case 'entre_posts':
        $where = "WHERE posicao = 'entre_posts'";
        break;
    default:
        $where = "";
}

$order = '';
switch ($ordenacao) {
    case 'antigos':
        $order = "ORDER BY criado_em ASC";
        break;
    case 'cliques':
        $order = "ORDER BY cliques DESC";
        break;
    case 'impressoes':
        $order = "ORDER BY impressoes DESC";
        break;
    default:
        $order = "ORDER BY criado_em DESC";
}

// Buscar anúncios com paginação
$total_anuncios = $conn->query("SELECT COUNT(*) as total FROM anuncios $where")->fetch_assoc()['total'];
$total_paginas = ceil($total_anuncios / $resultados_por_pagina);

$anuncios = $conn->query("
    SELECT * FROM anuncios 
    $where
    $order
    LIMIT $resultados_por_pagina OFFSET $offset
");

$msg = $_SESSION['msg'] ?? null;
unset($_SESSION['msg']);

include __DIR__ . '/includes/header_admin.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Gerenciar Anúncios</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
            <a href="anuncios_adicionar.php" class="btn btn-primary me-2">
                <i class="fas fa-plus"></i> Adicionar Anúncio
            </a>
        </div>
    </div>

    <?php if ($msg): ?>
        <div class="alert alert-<?= $msg['tipo'] ?> alert-dismissible fade show">
            <?= $msg['texto'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($erro)): ?>
        <div class="alert alert-danger">
            <?= $erro ?>
        </div>
    <?php endif; ?>

    <!-- Filtros e ordenação -->
    <div class="row mb-3">
        <div class="col-md-6">
            <div class="btn-group">
                <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fas fa-filter"></i> Filtrar: <?= ucfirst(str_replace('_', ' ', $filtro)) ?>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="?filtro=todos">Todos</a></li>
                    <li><a class="dropdown-item" href="?filtro=ativos">Ativos</a></li>
                    <li><a class="dropdown-item" href="?filtro=inativos">Inativos</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="?filtro=carrossel">Carrossel</a></li>
                    <li><a class="dropdown-item" href="?filtro=entre_posts">Entre Posts</a></li>
                </ul>
            </div>
            
            <div class="btn-group ms-2">
                <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="fas fa-sort"></i> Ordenar: <?= ucfirst($ordenacao) ?>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="?<?= http_build_query(array_merge($_GET, ['ordenar' => 'recentes'])) ?>">Mais recentes</a></li>
                    <li><a class="dropdown-item" href="?<?= http_build_query(array_merge($_GET, ['ordenar' => 'antigos'])) ?>">Mais antigos</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="?<?= http_build_query(array_merge($_GET, ['ordenar' => 'cliques'])) ?>">Mais cliques</a></li>
                    <li><a class="dropdown-item" href="?<?= http_build_query(array_merge($_GET, ['ordenar' => 'impressoes'])) ?>">Mais impressões</a></li>
                </ul>
            </div>
        </div>
        <div class="col-md-6 text-end">
            <span class="text-muted">Total: <?= $total_anuncios ?> anúncios</span>
        </div>
    </div>

    <!-- Tabela de anúncios -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Lista de Anúncios</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Título</th>
                            <th>Tipo</th>
                            <th>Posição</th>
                            <th>Status</th>
                            <th>Cliques</th>
                            <th>Impressões</th>
                            <th>Criado em</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($anuncio = $anuncios->fetch_assoc()): ?>
                        <tr>
                            <td><?= $anuncio['id'] ?></td>
                            <td><?= htmlspecialchars($anuncio['titulo']) ?></td>
                            <td>
                                <span class="badge bg-<?= 
                                    $anuncio['tipo'] === 'propio' ? 'info' : 
                                    ($anuncio['tipo'] === 'adsense' ? 'danger' : 'warning')
                                ?>">
                                    <?= ucfirst($anuncio['tipo']) ?>
                                </span>
                            </td>
                            <td><?= ucfirst(str_replace('_', ' ', $anuncio['posicao'])) ?></td>
                            <td>
                                <span class="badge bg-<?= $anuncio['ativo'] ? 'success' : 'secondary' ?>">
                                    <?= $anuncio['ativo'] ? 'Ativo' : 'Inativo' ?>
                                </span>
                            </td>
                            <td><?= $anuncio['cliques'] ?></td>
                            <td><?= $anuncio['impressoes'] ?></td>
                            <td><?= date('d/m/Y H:i', strtotime($anuncio['criado_em'])) ?></td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <a href="anuncios_visualizar.php?id=<?= $anuncio['id'] ?>" class="btn btn-info" title="Visualizar">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="anuncios_editar.php?id=<?= $anuncio['id'] ?>" class="btn btn-warning" title="Editar">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="id" value="<?= $anuncio['id'] ?>">
                                        <?php if ($anuncio['ativo']): ?>
                                            <button type="submit" name="acao" value="desativar" class="btn btn-secondary" title="Desativar">
                                                <i class="fas fa-toggle-on"></i>
                                            </button>
                                        <?php else: ?>
                                            <button type="submit" name="acao" value="ativar" class="btn btn-success" title="Ativar">
                                                <i class="fas fa-toggle-off"></i>
                                            </button>
                                        <?php endif; ?>
                                        <button type="button" class="btn btn-danger" title="Excluir" 
                                                onclick="if(confirm('Tem certeza que deseja excluir este anúncio?')) { 
                                                    this.form.action = 'anuncios.php'; 
                                                    this.form.submit(); 
                                                }" name="acao" value="excluir">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <!-- Paginação -->
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <?php if ($pagina_atual > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['pagina' => $pagina_atual - 1])) ?>" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                        <li class="page-item <?= $i == $pagina_atual ? 'active' : '' ?>">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['pagina' => $i])) ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    
                    <?php if ($pagina_atual < $total_paginas): ?>
                        <li class="page-item">
                            <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['pagina' => $pagina_atual + 1])) ?>" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</div>

<?php include __DIR__ . '/includes/footer_admin.php'; ?>