<?php
// config.php
define('ROOT_PATH', __DIR__);
define('INCLUDES_PATH', ROOT_PATH . '/includes');
define('PAGES_PATH', ROOT_PATH . '/pages');
define('IMG_PATH', ROOT_PATH . '/img');
?>