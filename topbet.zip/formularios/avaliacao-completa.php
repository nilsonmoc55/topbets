<?php
// Verifica se usuário está logado
$usuarioLogado = isset($_SESSION['usuario_id']);
?>

<div class="modal-body">
    <!-- Mensagens de erro/sucesso -->
    <div id="avaliacaoAlert" class="alert d-none"></div>
    
    <!-- Seção: Identificação -->
    <div class="form-section mb-4 p-3 border rounded" id="identificacaoSection">
        <h5><i class="fas fa-user me-2"></i> Sua Identificação</h5>
        <div id="identificacaoLogado" <?= !$usuarioLogado ? 'style="display:none;"' : '' ?>>
            <div class="d-flex align-items-center">
                <i class="fas fa-user-circle me-3" style="font-size: 2rem;"></i>
                <div>
                    <strong><?= $usuarioLogado ? htmlspecialchars($_SESSION['usuario_nome']) : '' ?></strong>
                    <div class="text-muted small"><?= $usuarioLogado ? htmlspecialchars($_SESSION['usuario_email']) : '' ?></div>
                </div>
            </div>
        </div>
        <div id="identificacaoAnonimo" style="display:none;">
            <div class="d-flex align-items-center">
                <i class="fas fa-user-secret me-3" style="font-size: 2rem;"></i>
                <div>
                    <strong>Avaliando como Anônimo</strong>
                    <div class="text-muted small">Sua avaliação será pública como anônimo</div>
                </div>
            </div>
        </div>
        <div id="identificacaoCampos" <?= $usuarioLogado ? 'style="display:none;"' : '' ?>>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="nomeAvaliador" class="form-label">Seu Nome (opcional)</label>
                    <input type="text" class="form-control" id="nomeAvaliador" name="nome_avaliador" placeholder="Seu nome ou apelido">
                </div>
                <div class="col-md-6 mb-3">
                    <label for="emailAvaliador" class="form-label">Seu Email (opcional)</label>
                    <input type="email" class="form-control" id="emailAvaliador" name="email_avaliador" placeholder="Seu email">
                </div>
            </div>
            <div class="alert alert-info py-2">
                <small>Sua avaliação será publicada como anônimo se não preencher os campos acima.</small>
            </div>
        </div>
    </div>

    <!-- Seção: Avaliação Geral -->
    <div class="form-section mb-4 p-3 border rounded">
        <h5><i class="fas fa-star me-2"></i> Avaliação Geral</h5>
        
        <div class="mb-3">
            <label class="form-label">Nota geral do site:</label>
            <div class="stars mb-2" id="ratingStars">
                <i class="far fa-star" data-rating="1"></i>
                <i class="far fa-star" data-rating="2"></i>
                <i class="far fa-star" data-rating="3"></i>
                <i class="far fa-star" data-rating="4"></i>
                <i class="far fa-star" data-rating="5"></i>
                <input type="hidden" name="nota" id="inputRating" value="0" required>
            </div>
            <small class="text-muted">Clique nas estrelas para avaliar (1-5)</small>
        </div>
        
        <div class="mb-3">
            <label for="comentarioGeral" class="form-label">Comentário geral sobre sua experiência:</label>
            <textarea class="form-control" id="comentarioGeral" name="comentario_geral" rows="3" required placeholder="Conte como foi sua experiência com este site"></textarea>
        </div>
    </div>

    <!-- Seção: Bônus -->
    <div class="form-section mb-4 p-3 border rounded">
        <h5><i class="fas fa-gift me-2"></i> Bônus e Promoções</h5>
        
        <div class="mb-3">
            <label class="form-label">Você recebeu algum bônus ao se cadastrar?</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="tem_bonus" id="temBonusSim" value="1" data-toggle="bonus">
                <label class="form-check-label" for="temBonusSim">Sim</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="tem_bonus" id="temBonusNao" value="0" checked data-toggle="bonus">
                <label class="form-check-label" for="temBonusNao">Não</label>
            </div>
        </div>
        
        <div id="bonusFields" style="display: none;">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="valorBonus" class="form-label">Valor do bônus recebido (R$):</label>
                    <input type="number" class="form-control" id="valorBonus" name="bonus" min="0" step="0.01" placeholder="Ex: 50.00">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Você conseguiu utilizar o bônus?</label>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="usou_bonus" id="usouBonusSim" value="1">
                        <label class="form-check-label" for="usouBonusSim">Sim, consegui usar</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="usou_bonus" id="usouBonusNao" value="0">
                        <label class="form-check-label" for="usouBonusNao">Não consegui usar</label>
                    </div>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="comentarioBonus" class="form-label">Comentário sobre o bônus:</label>
                <textarea class="form-control" id="comentarioBonus" name="bonus_comentario" rows="2" placeholder="Conte como foi a experiência com o bônus"></textarea>
            </div>
        </div>
        
        <div class="mb-3">
            <label class="form-label">O site oferece boas promoções?</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="tem_promocoes" id="temPromocoesSim" value="1">
                <label class="form-check-label" for="temPromocoesSim">Sim, várias promoções</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="tem_promocoes" id="temPromocoesNao" value="0" checked>
                <label class="form-check-label" for="temPromocoesNao">Não, poucas ou nenhuma</label>
            </div>
        </div>
    </div>

    <!-- Seção: Depósitos e Saques -->
    <div class="form-section mb-4 p-3 border rounded">
        <h5><i class="fas fa-money-bill-wave me-2"></i> Depósitos e Saques</h5>
        
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Como foi a experiência com depósitos?</label>
                <select class="form-select" name="deposito_nota">
                    <option value="5">Excelente - Rápido e sem problemas</option>
                    <option value="4">Bom - Algumas pequenas dificuldades</option>
                    <option value="3">Regular - Demorado ou com taxas</option>
                    <option value="2">Ruim - Muitos problemas</option>
                    <option value="1">Péssimo - Não consegui depositar</option>
                </select>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Como foi a experiência com saques?</label>
                <select class="form-select" name="saque_nota">
                    <option value="5">Excelente - Rápido e sem problemas</option>
                    <option value="4">Bom - Algumas pequenas dificuldades</option>
                    <option value="3">Regular - Demorado ou com taxas</option>
                    <option value="2">Ruim - Muitos problemas</option>
                    <option value="1">Péssimo - Não consegui sacar</option>
                </select>
            </div>
        </div>
        
        <div class="mb-3">
            <label for="comentarioSaque" class="form-label">Comentário sobre saques:</label>
            <textarea class="form-control" id="comentarioSaque" name="saque_comentario" rows="2" placeholder="Conte como foi sua experiência ao sacar"></textarea>
        </div>
    </div>

    <!-- Seção: Suporte e Usabilidade -->
    <div class="form-section mb-4 p-3 border rounded">
        <h5><i class="fas fa-headset me-2"></i> Suporte e Usabilidade</h5>
        
        <div class="mb-3">
            <label class="form-label">Como você avalia o suporte ao cliente?</label>
            <select class="form-select" name="suporte_nota">
                <option value="5">Excelente - Resposta rápida e eficiente</option>
                <option value="4">Bom - Resolveu meu problema</option>
                <option value="3">Regular - Demorou mas resolveu</option>
                <option value="2">Ruim - Não resolveu meu problema</option>
                <option value="1">Péssimo - Não consegui contato</option>
            </select>
        </div>
        
        <div class="mb-3">
           