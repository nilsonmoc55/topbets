# /formularios/identificacao-avaliador.php
<div class="form-section mb-4 p-3 border rounded" id="identificacaoSection">
    <h5><i class="fas fa-user me-2"></i> Sua Identificação</h5>
    <div id="identificacaoLogado" <?= !$usuarioLogado ? 'style="display:none;"' : '' ?>>
        <div class="d-flex align-items-center">
            <i class="fas fa-user-circle me-3" style="font-size: 2rem;"></i>
            <div>
                <strong><?= $usuarioLogado ? htmlspecialchars($_SESSION['usuario_nome']) : '' ?></strong>
                <div class="text-muted small"><?= $usuarioLogado ? htmlspecialchars($_SESSION['usuario_email']) : '' ?></div>
            </div>
        </div>
    </div>
    <div id="identificacaoAnonimo" style="display:none;">
        <!-- ... conteúdo anterior ... -->
    </div>
</div>

# /formularios/avaliacao-geral.php
<div class="form-section mb-4 p-3 border rounded">
    <h5><i class="fas fa-star me-2"></i> Avaliação Geral</h5>
    <!-- ... conteúdo do formulário ... -->
</div>

# /formularios/bonus-promocoes.php
<div class="form-section mb-4 p-3 border rounded">
    <h5><i class="fas fa-gift me-2"></i> Bônus e Promoções</h5>
    <!-- ... conteúdo do formulário ... -->
</div>