<?php
function getReacaoUsuario($conn, $avaliacao_id, $usuario_id) {
    if (!$usuario_id) return null;
    
    $sql = "SELECT tipo FROM reacoes WHERE avaliacao_id = ? AND usuario_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $avaliacao_id, $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0 ? $result->fetch_assoc()['tipo'] : null;
}

function getComentarios($conn, $avaliacao_id) {
    $sql = "
        SELECT 
            c.*,
            u.nome as nome_usuario,
            COUNT(rc.id) as total_curtidas
        FROM comentarios_avaliacoes c
        JOIN usuarios u ON c.usuario_id = u.id
        LEFT JOIN reacoes_comentarios rc ON c.id = rc.comentario_id
        WHERE c.avaliacao_id = ?
        GROUP BY c.id
        ORDER BY c.data_criacao DESC
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $avaliacao_id);
    $stmt->execute();
    return $stmt->get_result();
}
?>