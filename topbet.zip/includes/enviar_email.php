<?php
function enviarEmailBoasVindas($email, $nome) {
    $assunto = "Bem-vindo ao TopBets!";
    
    $mensagem = "
    <html>
    <head>
        <title>Bem-vindo ao TopBets</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background-color: #007bff; color: white; padding: 10px; text-align: center; }
            .content { padding: 20px; }
            .footer { margin-top: 20px; font-size: 12px; color: #666; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h2>TopBets</h2>
            </div>
            <div class='content'>
                <h3>Olá, $nome!</h3>
                <p>Seu cadastro no TopBets foi realizado com sucesso!</p>
                <p>Agora você pode:</p>
                <ul>
                    <li>Avaliar suas casas de apostas favoritas</li>
                    <li>Ver as melhores recomendações</li>
                    <li>Participar da comunidade</li>
                </ul>
                <p>Acesse agora: <a href='https://seusite.com'>https://seusite.com</a></p>
            </div>
            <div class='footer'>
                <p>Este é um e-mail automático, por favor não responda.</p>
                <p>© ".date('Y')." TopBets. Todos os direitos reservados.</p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= "From: TopBets <no-reply@seusite.com>\r\n";
    $headers .= "Reply-To: contato@seusite.com\r\n";
    
    return mail($email, $assunto, $mensagem, $headers);
}
?>