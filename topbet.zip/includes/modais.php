<?php
// includes/modais.php
require_once __DIR__ . '/conexao.php';
?>

<!-- Modal 1: Lista de Bets -->
<div class="modal fade" id="modalListaBets" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">
                    <i class="fas fa-star me-2"></i> Escolha uma Casa de Apostas
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <div class="input-group mb-3">
                    <input type="text" id="buscaBets" class="form-control" placeholder="Buscar...">
                    <button class="btn btn-outline-secondary" id="btnLimparBusca">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="row" id="listaBets">
                    <?php
                    $sql = "SELECT id, nome, logo FROM bets WHERE ativo = 1 ORDER BY nome";
                    $result = $conn->query($sql);
                    while ($bet = $result->fetch_assoc()):
                    ?>
                        <div class="col-md-4 mb-3 bet-card" 
                             data-bet-id="<?= $bet['id'] ?>" 
                             data-bet-name="<?= htmlspecialchars($bet['nome']) ?>"
                             data-bet-search="<?= strtolower($bet['nome']) ?>">
                            <div class="card h-100">
                                <img src="<?= $bet['logo'] ?>" class="card-img-top p-2" style="height: 80px; object-fit: contain;">
                                <div class="card-body text-center">
                                    <h6 class="card-title"><?= $bet['nome'] ?></h6>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal 2: Verificação de Login -->
<div class="modal fade" id="modalVerificaLogin" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body" id="conteudoVerificaLogin">
                <!-- Aqui será carregado verifica_sessao_avaliacao.php -->
            </div>
        </div>
    </div>
</div>

<!-- Modal 3: Formulário de Avaliação -->
<div class="modal fade" id="modalFormAvaliacao" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="tituloAvaliacao">Avaliar Casa</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <form id="formAvaliacao">
                    <input type="hidden" name="bet_id" id="betIdAvaliacao">
                    <input type="hidden" name="anonimo" id="avaliacaoAnonima" value="0">
                    
                    <div class="mb-3">
                        <label class="form-label">Nota:</label>
                        <div class="rating-stars">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <i class="far fa-star" data-value="<?= $i ?>"></i>
                            <?php endfor; ?>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="comentario" class="form-label">Comentário:</label>
                        <textarea class="form-control" name="comentario" rows="3"></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary w-100">Enviar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Filtro de busca em tempo real
document.getElementById('buscaBets').addEventListener('input', function() {
    const termo = this.value.toLowerCase();
    document.querySelectorAll('#listaBets .bet-card').forEach(card => {
        const nomeBet = card.getAttribute('data-bet-search');
        card.style.display = nomeBet.includes(termo) ? 'block' : 'none';
    });
});

// Limpar busca
document.getElementById('btnLimparBusca').addEventListener('click', function() {
    document.getElementById('buscaBets').value = '';
    document.querySelectorAll('#listaBets .bet-card').forEach(card => {
        card.style.display = 'block';
    });
});

// Ao clicar em uma bet: carrega verifica_sessao_avaliacao.php
document.querySelectorAll('.bet-card').forEach(card => {
    card.addEventListener('click', function() {
        const betId = this.getAttribute('data-bet-id');
        const betNome = this.getAttribute('data-bet-name');
        
        fetch(`pages/verifica_sessao_avaliacao.php?bet_id=${betId}&bet_nome=${encodeURIComponent(betNome)}`)
            .then(response => response.text())
            .then(html => {
                document.getElementById('conteudoVerificaLogin').innerHTML = html;
                bootstrap.Modal.getInstance(document.getElementById('modalListaBets')).hide();
                new bootstrap.Modal(document.getElementById('modalVerificaLogin')).show();
            });
    });
});

// Eventos para os botões em verifica_sessao_avaliacao.php
window.addEventListener('avaliarComoUsuario', function(e) {
    document.getElementById('betIdAvaliacao').value = e.detail.betId;
    document.getElementById('avaliacaoAnonima').value = '0';
    document.getElementById('tituloAvaliacao').textContent = `Avaliar ${e.detail.betNome}`;
    bootstrap.Modal.getInstance(document.getElementById('modalVerificaLogin')).hide();
    new bootstrap.Modal(document.getElementById('modalFormAvaliacao')).show();
});

window.addEventListener('avaliarComoAnonimo', function(e) {
    document.getElementById('betIdAvaliacao').value = e.detail.betId;
    document.getElementById('avaliacaoAnonima').value = '1';
    document.getElementById('tituloAvaliacao').textContent = `Avaliar ${e.detail.betNome} (Anônimo)`;
    bootstrap.Modal.getInstance(document.getElementById('modalVerificaLogin')).hide();
    new bootstrap.Modal(document.getElementById('modalFormAvaliacao')).show();
});
</script>