<?php
require_once __DIR__ . '/conexao.php';

header('Content-Type: application/json');

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

echo json_encode([
    'token' => $_SESSION['csrf_token'],
    'timestamp' => time()
]);
exit;
?>