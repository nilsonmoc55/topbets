<?php
$categorias = $conn->query("SELECT * FROM categorias WHERE ativo = 1 ORDER BY nome");
?>
<div class="modal fade" id="modalSelecionarCategoria" tabindex="-1" aria-labelledby="selecionarCategoriaLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="selecionarCategoriaLabel">Selecione a Categoria</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row row-cols-2 row-cols-md-3 g-4">
                    <?php while($cat = $categorias->fetch_assoc()): ?>
                    <div class="col">
                        <div class="card h-100 border-0 shadow-sm categoria-card" 
                             onclick="selecionarCategoria(<?= $cat['id'] ?>, '<?= htmlspecialchars($cat['nome']) ?>')">
                            <div class="card-body text-center py-4">
                                <?php if(!empty($cat['icone'])): ?>
                                <i class="<?= htmlspecialchars($cat['icone']) ?> fa-3x mb-3 text-primary"></i>
                                <?php endif; ?>
                                <h5 class="card-title"><?= htmlspecialchars($cat['nome']) ?></h5>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" onclick="abrirProximoModal('#modalSelecionarCategoria', '#modalAvaliacaoInicial')">
                    <i class="fas fa-arrow-left me-2"></i> Voltar
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function selecionarCategoria(id, nome) {
    // Carrega o modal de seleção de casa com a categoria selecionada
    $.ajax({
        url: 'includes/modais/modal-selecionar-casa.php',
        type: 'GET',
        data: { categoria_id: id, categoria_nome: nome },
        success: function(response) {
            $('#modalSelecionarCasaContainer').html(response);
            abrirProximoModal('#modalSelecionarCategoria', '#modalSelecionarCasa');
        }
    });
}
</script>