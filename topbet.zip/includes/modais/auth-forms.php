<?php
// Parâmetros que podem ser passados ao incluir este arquivo
$embedded = $embedded ?? false; // Se está sendo incluído em outro modal
$bet_id = $bet_id ?? '';
$bet_nome = $bet_nome ?? '';
$target = $target ?? 'avaliacao'; // 'avaliacao' ou 'geral'
?>

<div class="auth-forms-container">
    <!-- Abas Login/Cadastro -->
    <ul class="nav nav-tabs mb-4" id="authTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="login-tab" data-bs-toggle="tab" data-bs-target="#login-tab-pane" type="button" role="tab">
                <i class="fas fa-sign-in-alt me-1"></i> Login
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="cadastro-tab" data-bs-toggle="tab" data-bs-target="#cadastro-tab-pane" type="button" role="tab">
                <i class="fas fa-user-plus me-1"></i> Cadastre-se
            </button>
        </li>
    </ul>

    <div class="tab-content" id="authTabsContent">
        <!-- Tab Login -->
        <div class="tab-pane fade show active" id="login-tab-pane" role="tabpanel">
            <form class="auth-form" id="formLogin<?= $target === 'avaliacao' ? 'Embedded' : '' ?>" 
                  action="processa_login.php" method="POST">
                <input type="hidden" name="target" value="<?= $target ?>">
                <input type="hidden" name="bet_id" value="<?= $bet_id ?>">
                <input type="hidden" name="bet_nome" value="<?= htmlspecialchars($bet_nome) ?>">
                
                <div class="mb-3">
                    <label class="form-label">E-mail</label>
                    <input type="email" class="form-control <?= isset($errosLogin['email']) ? 'is-invalid' : '' ?>" 
                           name="email" value="<?= htmlspecialchars($emailLogin ?? '') ?>" required>
                    <?php if(isset($errosLogin['email'])): ?>
                        <div class="invalid-feedback"><?= $errosLogin['email'] ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Senha</label>
                    <input type="password" class="form-control <?= isset($errosLogin['senha']) ? 'is-invalid' : '' ?>" 
                           name="senha" required>
                    <?php if(isset($errosLogin['senha'])): ?>
                        <div class="invalid-feedback"><?= $errosLogin['senha'] ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="lembrar<?= $target === 'avaliacao' ? 'Embedded' : '' ?>" name="lembrar">
                    <label class="form-check-label" for="lembrar<?= $target === 'avaliacao' ? 'Embedded' : '' ?>">Lembrar de mim</label>
                </div>
                
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#recuperarModal" data-bs-dismiss="modal">
                        Esqueceu a senha?
                    </a>
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-sign-in-alt me-1"></i> Entrar
                    </button>
                </div>
            </form>
        </div>
        
        <!-- Tab Cadastro -->
        <div class="tab-pane fade" id="cadastro-tab-pane" role="tabpanel">
            <form class="auth-form" id="formCadastro<?= $target === 'avaliacao' ? 'Embedded' : '' ?>" 
                  action="processa_cadastro.php" method="POST">
                <input type="hidden" name="target" value="<?= $target ?>">
                <input type="hidden" name="bet_id" value="<?= $bet_id ?>">
                <input type="hidden" name="bet_nome" value="<?= htmlspecialchars($bet_nome) ?>">
                
                <div class="mb-3">
                    <label class="form-label">Nome Completo</label>
                    <input type="text" class="form-control <?= isset($errosCadastro['nome']) ? 'is-invalid' : '' ?>" 
                           name="nome" value="<?= htmlspecialchars($nomeCadastro ?? '') ?>" required>
                    <?php if(isset($errosCadastro['nome'])): ?>
                        <div class="invalid-feedback"><?= $errosCadastro['nome'] ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">E-mail</label>
                    <input type="email" class="form-control <?= isset($errosCadastro['email']) ? 'is-invalid' : '' ?>" 
                           name="email" id="emailCadastro<?= $target === 'avaliacao' ? 'Embedded' : '' ?>" 
                           value="<?= htmlspecialchars($emailCadastro ?? '') ?>" required>
                    <div id="emailStatus<?= $target === 'avaliacao' ? 'Embedded' : '' ?>" class="mt-1"></div>
                    <div id="emailRecuperar<?= $target === 'avaliacao' ? 'Embedded' : '' ?>" class="mt-2 d-none">
                        <a href="#" class="text-decoration-none" id="linkRecuperarSenha<?= $target === 'avaliacao' ? 'Embedded' : '' ?>" 
                           data-bs-toggle="modal" data-bs-target="#recuperarModal">
                            <i class="fas fa-key me-1"></i> Esqueceu a senha? Clique para recuperar
                        </a>
                    </div>
                    <?php if(isset($errosCadastro['email'])): ?>
                        <div class="invalid-feedback"><?= $errosCadastro['email'] ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Senha (mínimo 6 caracteres)</label>
                    <input type="password" class="form-control <?= isset($errosCadastro['senha']) ? 'is-invalid' : '' ?>" 
                           name="senha" minlength="6" required>
                    <?php if(isset($errosCadastro['senha'])): ?>
                        <div class="invalid-feedback"><?= $errosCadastro['senha'] ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Confirmar Senha</label>
                    <input type="password" class="form-control <?= isset($errosCadastro['confirmar_senha']) ? 'is-invalid' : '' ?>" 
                           name="confirmar_senha" minlength="6" required>
                    <?php if(isset($errosCadastro['confirmar_senha'])): ?>
                        <div class="invalid-feedback"><?= $errosCadastro['confirmar_senha'] ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="form-check mb-3">
                    <input class="form-check-input <?= isset($errosCadastro['termos']) ? 'is-invalid' : '' ?>" 
                           type="checkbox" id="termos<?= $target === 'avaliacao' ? 'Embedded' : '' ?>" name="termos" required>
                    <label class="form-check-label" for="termos<?= $target === 'avaliacao' ? 'Embedded' : '' ?>">
                        Concordo com os <a href="#" data-bs-toggle="modal" data-bs-target="#termosModal">Termos de Uso</a>
                    </label>
                    <?php if(isset($errosCadastro['termos'])): ?>
                        <div class="invalid-feedback"><?= $errosCadastro['termos'] ?></div>
                    <?php endif; ?>
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-success" id="btnCadastrar<?= $target === 'avaliacao' ? 'Embedded' : '' ?>" <?= isset($errosCadastro) ? '' : 'disabled' ?>>
                        <i class="fas fa-user-plus me-1"></i> Cadastrar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>