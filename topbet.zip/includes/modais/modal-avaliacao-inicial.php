<div class="modal fade" id="modalAvaliacaoInicial" tabindex="-1" aria-labelledby="avaliacaoInicialLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="avaliacaoInicialLabel">Avaliar Casa de Aposta</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center py-4">
                <i class="fas fa-star fa-4x text-warning mb-3"></i>
                <h4 class="mb-3">Sua opinião é importante!</h4>
                <p class="text-muted">Ajude outros usuários escolhendo as melhores casas de aposta.</p>
                <p class="text-muted">O processo leva menos de 2 minutos.</p>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-secondary px-4" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary px-4" onclick="abrirProximoModal('#modalAvaliacaoInicial', '#modalSelecionarCategoria')">
                    Começar <i class="fas fa-arrow-right ms-2"></i>
                </button>
            </div>
        </div>
    </div>
</div>