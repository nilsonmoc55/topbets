<div class="modal fade" id="modalListaBets" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Selecione a Casa de Aposta</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="input-group mb-3">
                    <input type="text" id="filtroBets" class="form-control" placeholder="Filtrar por nome...">
                    <button class="btn btn-outline-secondary" type="button" id="btnFiltrar">
                        <i class="fas fa-filter"></i>
                    </button>
                </div>
                
                <div class="row row-cols-1 row-cols-md-2 g-4" id="containerBets">
                    <?php
                    $sql = "SELECT id, nome, logo FROM bets WHERE ativo = 1 ORDER BY nome ASC";
                    $result = $conn->query($sql);
                    
                    while($bet = $result->fetch_assoc()):
                        $logo = $bet['logo'] ? "img/logos/{$bet['logo']}" : "img/logos/padrao.png";
                    ?>
                    <div class="col bet-item" data-id="<?= $bet['id'] ?>" data-nome="<?= htmlspecialchars($bet['nome']) ?>">
                        <div class="card h-100">
                            <div class="row g-0 h-100">
                                <div class="col-md-4 d-flex align-items-center p-2">
                                    <img src="<?= $logo ?>" class="img-fluid rounded-start" alt="<?= $bet['nome'] ?>">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body d-flex flex-column h-100">
                                        <h5 class="card-title"><?= $bet['nome'] ?></h5>
                                        <button class="btn btn-primary mt-auto align-self-start btn-selecionar">
                                            Selecionar
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
    </div>
</div>