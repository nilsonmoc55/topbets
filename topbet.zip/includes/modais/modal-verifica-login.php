<div class="modal fade" id="modalVerificaLogin" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Avaliar <span id="betNameTitle"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <?php if(isset($_SESSION['usuario_id'])): ?>
                    <p>Como deseja continuar?</p>
                    <div class="d-grid gap-2">
                        <a href="#" id="btnAvaliarLogado" class="btn btn-primary">
                            <i class="fas fa-user me-2"></i>Avaliar como <?= $_SESSION['usuario_nome'] ?>
                        </a>
                        <a href="#" id="btnAvaliarAnonimo" class="btn btn-outline-secondary">
                            <i class="fas fa-user-secret me-2"></i>Avaliar anonimamente
                        </a>
                    </div>
                <?php else: ?>
                    <p>Para avaliar, faça login ou avalie anonimamente:</p>
                    <div class="d-grid gap-2">
                        <a href="login.php?redirect=avaliar" class="btn btn-primary">
                            <i class="fas fa-sign-in-alt me-2"></i>Fazer Login
                        </a>
                        <a href="#" id="btnAvaliarAnonimo" class="btn btn-outline-secondary">
                            <i class="fas fa-user-secret me-2"></i>Avaliar Anonimamente
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>