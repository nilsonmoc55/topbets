<?php
session_start();
if (!isset($_SESSION['bet_avaliacao'])) {
    die('Nenhuma casa selecionada!');
}

$bet = $_SESSION['bet_avaliacao'];
$usuarioLogado = isset($_SESSION['usuario_id']);
?>

<div class="modal fade" id="verificaLoginModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Avaliar: <?= htmlspecialchars($bet['nome']) ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <div class="modal-body text-center">
                <?php if($usuarioLogado): ?>
                    <!-- Usuário LOGADO -->
                    <div class="mb-4">
                        <i class="fas fa-user-circle fa-4x text-primary"></i>
                        <h5 class="mt-3">Olá, <?= htmlspecialchars($_SESSION['usuario_nome']) ?>!</h5>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <a href="avaliar.php?bet_id=<?= $bet['id'] ?>" class="btn btn-primary">
                            <i class="fas fa-star me-2"></i>Avaliar como <?= htmlspecialchars($_SESSION['usuario_nome']) ?>
                        </a>
                        <a href="avaliar.php?bet_id=<?= $bet['id'] ?>&anonimo=1" class="btn btn-outline-primary">
                            <i class="fas fa-user-secret me-2"></i>Avaliar Anonimamente
                        </a>
                    </div>
                <?php else: ?>
                    <!-- Usuário NÃO LOGADO -->
                    <div class="mb-4">
                        <i class="fas fa-exclamation-triangle fa-4x text-warning"></i>
                        <h5 class="mt-3">Login Necessário</h5>
                        <p>Para registrar sua avaliação</p>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#loginModal" data-bs-dismiss="modal">
                            <i class="fas fa-sign-in-alt me-2"></i>Fazer Login
                        </button>
                        <a href="avaliar.php?bet_id=<?= $bet['id'] ?>&anonimo=1" class="btn btn-outline-primary">
                            <i class="fas fa-user-secret me-2"></i>Avaliar Anonimamente
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>