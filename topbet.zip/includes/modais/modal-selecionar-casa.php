<?php
$categoria_id = intval($_GET['categoria_id']);
$categoria_nome = $_GET['categoria_nome'];

$bets = $conn->query("
    SELECT b.* FROM bets b
    JOIN bet_categorias bc ON b.id = bc.bet_id
    WHERE bc.categoria_id = $categoria_id AND b.ativo = 1
    ORDER BY b.nome
");
?>
<div class="modal fade" id="modalSelecionarCasa" tabindex="-1" aria-labelledby="selecionarCasaLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="selecionarCasaLabel">Selecione a Casa de Aposta</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h6 class="mb-4">Categoria: <strong><?= htmlspecialchars($categoria_nome) ?></strong></h6>
                
                <div class="row row-cols-1 row-cols-md-2 g-4">
                    <?php while($bet = $bets->fetch_assoc()): ?>
                    <div class="col">
                        <div class="card h-100 bet-card" onclick="selecionarCasa(<?= $bet['id'] ?>, <?= $categoria_id ?>)">
                            <div class="card-body d-flex align-items-center">
                                <?php if(!empty($bet['logo'])): ?>
                                <img src="uploads/logos/<?= htmlspecialchars($bet['logo']) ?>" class="rounded me-3" style="width: 60px; height: 60px; object-fit: contain;" alt="<?= htmlspecialchars($bet['nome']) ?>">
                                <?php endif; ?>
                                <div>
                                    <h5 class="mb-1"><?= htmlspecialchars($bet['nome']) ?></h5>
                                    <small class="text-muted">Clique para avaliar</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" onclick="abrirProximoModal('#modalSelecionarCasa', '#modalSelecionarCategoria')">
                    <i class="fas fa-arrow-left me-2"></i> Voltar
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function selecionarCasa(bet_id, categoria_id) {
    // Carrega o formulário de avaliação
    $.ajax({
        url: 'includes/modais/modal-form-avaliacao.php',
        type: 'GET',
        data: { 
            bet_id: bet_id,
            categoria_id: categoria_id
        },
        success: function(response) {
            $('#modalFormAvaliacaoContainer').html(response);
            abrirProximoModal('#modalSelecionarCasa', '#modalFormAvaliacao');
        }
    });
}
</script>