<div class="modal fade" id="modalCadastro" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Criar Conta</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="formCadastro" method="POST" action="includes/cadastrar.php">
                    <div class="mb-3">
                        <label for="cadNome" class="form-label">Nome Completo</label>
                        <input type="text" class="form-control" id="cadNome" name="nome" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="cadEmail" class="form-label">Email</label>
                        <input type="email" class="form-control" id="cadEmail" name="email" required>
                        <div id="emailErro" class="invalid-feedback">Email já cadastrado</div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="cadSenha" class="form-label">Senha</label>
                        <input type="password" class="form-control" id="cadSenha" name="senha" minlength="6" required>
                        <small class="text-muted">Mínimo 6 caracteres</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="cadConfirmaSenha" class="form-label">Confirmar Senha</label>
                        <input type="password" class="form-control" id="cadConfirmaSenha" required>
                        <div id="senhaErro" class="invalid-feedback">As senhas não coincidem</div>
                    </div>
                    
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="termos" required>
                        <label class="form-check-label" for="termos">Aceito os Termos de Uso</label>
                    </div>
                    
                    <div id="cadastroSucesso" class="alert alert-success d-none">
                        Cadastro realizado com sucesso! Você já pode fazer login.
                    </div>
                    
                    <div id="cadastroErro" class="alert alert-danger d-none">
                        Ocorreu um erro ao cadastrar. Tente novamente mais tarde.
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Cadastrar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>