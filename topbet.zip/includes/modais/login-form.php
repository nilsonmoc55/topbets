<?php
$embedded = $_GET['embedded'] ?? false;
$bet_id = $_GET['bet_id'] ?? '';
$bet_nome = $_GET['bet_nome'] ?? '';
?>

<div class="auth-container">
    <!-- Abas Login/Cadastro -->
    <ul class="nav nav-tabs mb-4" id="authTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="login-tab" data-bs-toggle="tab" data-bs-target="#login-tab-pane" type="button" role="tab">
                <i class="fas fa-sign-in-alt me-1"></i> Login
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="cadastro-tab" data-bs-toggle="tab" data-bs-target="#cadastro-tab-pane" type="button" role="tab">
                <i class="fas fa-user-plus me-1"></i> Cadastre-se
            </button>
        </li>
    </ul>

    <div class="tab-content" id="authTabsContent">
        <!-- Tab Login -->
        <div class="tab-pane fade show active" id="login-tab-pane" role="tabpanel">
            <form class="auth-form" id="formLoginEmbedded" action="processa_login.php" method="POST">
                <input type="hidden" name="bet_id" value="<?= $bet_id ?>">
                <input type="hidden" name="bet_nome" value="<?= htmlspecialchars($bet_nome) ?>">
                <input type="hidden" name="embedded" value="1">
                
                <div class="mb-3">
                    <label class="form-label">E-mail</label>
                    <input type="email" class="form-control" name="email" required>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Senha</label>
                    <input type="password" class="form-control" name="senha" required>
                </div>
                
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="lembrarLoginEmbedded">
                        <label class="form-check-label" for="lembrarLoginEmbedded">Lembrar-me</label>
                    </div>
                    <a href="#!" class="small">Esqueceu a senha?</a>
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-sign-in-alt me-1"></i> Entrar
                    </button>
                </div>
            </form>
        </div>
        
        <!-- Tab Cadastro -->
        <div class="tab-pane fade" id="cadastro-tab-pane" role="tabpanel">
            <form class="auth-form" id="formCadastroEmbedded" action="processa_cadastro.php" method="POST">
                <input type="hidden" name="bet_id" value="<?= $bet_id ?>">
                <input type="hidden" name="bet_nome" value="<?= htmlspecialchars($bet_nome) ?>">
                <input type="hidden" name="embedded" value="1">
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nome</label>
                        <input type="text" class="form-control" name="nome" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">E-mail</label>
                        <input type="email" class="form-control" name="email" id="emailCadastroEmbedded" required>
                        <div id="emailStatusEmbedded" class="mt-1"></div>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Senha</label>
                        111
                        <input type="password" class="form-control" name="senha" minlength="6" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Confirme a Senha</label>
                        <input type="password" class="form-control" name="confirmar_senha" minlength="6" required>
                    </div>
                </div>
                
                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" id="termosEmbedded" required>
                    <label class="form-check-label" for="termosEmbedded">
                        Aceito os <a href="#!" data-bs-toggle="modal" data-bs-target="#modalTermos">Termos de Uso</a>
                    </label>
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-success" id="btnCadastrarEmbedded">
                        <i class="fas fa-user-plus me-1"></i> Cadastrar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php if (!$embedded): ?>
<script>
$(document).ready(function() {
    // Configura os eventos apenas se não estiver embutido
    configurarAuthEvents();
});
</script>
<?php endif; ?>