document.addEventListener('DOMContentLoaded', function() {
    // Modal Inicial - Seleção de Categoria
    const modalInicial = new bootstrap.Modal(document.getElementById('modalAvaliarInicial'));
    const btnProximo = document.getElementById('btnProximoCategoria');
    
    // Ativa o botão próximo quando selecionar categoria
    document.querySelectorAll('input[name="categoria"]').forEach(radio => {
        radio.addEventListener('change', function() {
            btnProximo.disabled = false;
        });
    });
    
    // Ao clicar em próximo, fecha o modal inicial e abre o de seleção de bet
    btnProximo.addEventListener('click', function() {
        const categoriaSelecionada = document.querySelector('input[name="categoria"]:checked').value;
        modalInicial.hide();
        
        // Aqui você pode carregar as bets para a categoria selecionada
        carregarBetsPorCategoria(categoriaSelecionada).then(() => {
            const modalSelecionarBet = new bootstrap.Modal(document.getElementById('modalSelecionarBet'));
            modalSelecionarBet.show();
        });
    });
    
    // Função para carregar as bets (exemplo)
    async function carregarBetsPorCategoria(categoria) {
        // Implemente a lógica para carregar as bets desta categoria
        // Pode ser via AJAX como mostrado anteriormente
    }
});