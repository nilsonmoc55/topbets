<div class="modal fade" id="modalConfirmacaoAvaliacao" tabindex="-1" aria-labelledby="confirmacaoAvaliacaoLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title" id="confirmacaoAvaliacaoLabel">Avaliação Enviada!</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center py-5">
                <i class="fas fa-check-circle fa-5x text-success mb-4"></i>
                <h4 class="mb-3">Obrigado por sua avaliação!</h4>
                <p class="text-muted">Sua opinião ajuda a melhorar nossa comunidade.</p>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-success px-4" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>