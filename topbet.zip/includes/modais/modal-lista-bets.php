<?php
include '../conexao.php';

// Busca com filtro se existir
$termo = isset($_GET['termo']) ? trim($_GET['termo']) : '';
$where = (!empty($termo)) ? "WHERE ativo = 1 AND nome LIKE '%".$conn->real_escape_string($termo)."%'" : "WHERE ativo = 1";

$sql = "SELECT id, nome, logo FROM bets $where ORDER BY nome ASC";
$result = $conn->query($sql);

if (!$result) {
    die("Erro na consulta: " . $conn->error);
}
?>

<div class="modal-avaliacao">
    <div class="modal-header">
        <h5 class="modal-title">Selecione uma Casa de Aposta</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
        <!-- Barra de busca -->
        <div class="mb-4">
            <div class="input-group">
                <input type="text" id="buscaBet" class="form-control" placeholder="Pesquisar casa de aposta..." 
                       value="<?= htmlspecialchars($termo) ?>">
                <button class="btn btn-primary" id="btnBuscar">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>

        <!-- Lista em 2 colunas -->
        <div class="row" id="listaBets">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($bet = $result->fetch_assoc()): ?>
                    <div class="col-md-6 mb-3">
                        <div class="bet-card d-flex align-items-center p-3" 
                             data-bet-id="<?= $bet['id'] ?>" 
                             data-bet-nome="<?= htmlspecialchars($bet['nome']) ?>">
                            <img src="img/logos/<?= $bet['logo'] ?>" 
                                 alt="<?= htmlspecialchars($bet['nome']) ?>" 
                                 class="img-fluid rounded me-3" 
                                 style="width: 50px; height: 50px; object-fit: contain;">
                            <h6 class="mb-0"><?= htmlspecialchars($bet['nome']) ?></h6>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 text-center py-4">
                    <i class="fas fa-exclamation-circle fa-3x text-muted mb-3"></i>
                    <p class="text-muted">Nenhuma casa de aposta encontrada</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>