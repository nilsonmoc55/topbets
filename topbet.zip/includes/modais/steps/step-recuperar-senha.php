<?php
session_start();
include __DIR__ . '/../../conexao.php';

$bet_id = $_POST['bet_id'] ?? '';
$bet_nome = $_POST['bet_nome'] ?? '';
$erros = $_SESSION['recuperar_errors'] ?? [];
unset($_SESSION['recuperar_errors']);
?>

<div class="modal-step active">
    <div class="modal-header bg-warning text-dark">
        <h5 class="modal-title">
            <i class="fas fa-key me-2"></i> Recuperar Senha
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    
    <div class="modal-body">
        <form id="formRecuperarSenha">
            <input type="hidden" name="bet_id" value="<?= $bet_id ?>">
            <input type="hidden" name="bet_nome" value="<?= htmlspecialchars($bet_nome) ?>">
            
            <div class="mb-3">
                <label class="form-label">E-mail cadastrado</label>
                <input type="email" class="form-control <?= !empty($erros['email']) ? 'is-invalid' : '' ?>" 
                       name="email" value="<?= htmlspecialchars($erros['email_value'] ?? '') ?>" required>
                <?php if(!empty($erros['email'])): ?>
                    <div class="invalid-feedback"><?= $erros['email'] ?></div>
                <?php endif; ?>
            </div>
            
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i> Enviaremos um link para redefinir sua senha.
            </div>
            
            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-warning py-2">
                    <i class="fas fa-paper-plane me-2"></i> Enviar Link
                </button>
                
                <button type="button" class="btn btn-outline-secondary" 
                        onclick="carregarStep('login', { bet_id: '<?= $bet_id ?>', bet_nome: '<?= htmlspecialchars($bet_nome) ?>' })">
                    <i class="fas fa-arrow-left me-2"></i> Voltar para Login
                </button>
            </div>
        </form>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#formRecuperarSenha').submit(function(e) {
        e.preventDefault();
        var form = $(this);
        var submitBtn = form.find('button[type="submit"]');
        var originalText = submitBtn.html();
        
        submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i> Enviando...');
        
        $.ajax({
            url: 'includes/recuperar-senha.php',
            type: 'POST',
            data: form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert('Link enviado! Verifique seu e-mail.');
                    carregarStep('login', {
                        bet_id: response.bet_id,
                        bet_nome: response.bet_nome
                    });
                } else {
                    submitBtn.prop('disabled', false).html(originalText);
                    
                    $('.is-invalid').removeClass('is-invalid');
                    $('.invalid-feedback').remove();
                    
                    if (response.errors.email) {
                        $('input[name="email"]').addClass('is-invalid')
                            .after('<div class="invalid-feedback">' + response.errors.email + '</div>');
                    }
                }
            },
            error: function() {
                submitBtn.prop('disabled', false).html(originalText);
                alert('Erro ao comunicar com o servidor.');
            }
        });
    });
});
</script>