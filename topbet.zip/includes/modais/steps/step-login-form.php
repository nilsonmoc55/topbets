<?php
session_start();
require_once '../../conexao.php';

$betId = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$betNome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);

if (!$betId || !$betNome) {
    die('Dados inválidos.');
}
?>

<div class="modal-header">
    <h5 class="modal-title">Avaliar <?= htmlspecialchars($betNome) ?></h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

<div class="modal-body">
    <div class="row">
        <div class="col-md-6">
            <h4 class="mb-4">Login</h4>
            
            <div id="loginError" class="alert alert-danger d-none mb-3">
                <i class="fas fa-exclamation-circle me-2"></i>
                <span id="errorMessage"></span>
                <div class="mt-2">
                    <a href="#" id="linkRecuperarSenha" class="alert-link">
                        <i class="fas fa-key me-1"></i> Recuperar senha
                    </a>
                </div>
            </div>
            
            <form id="formLogin">
                <input type="hidden" name="bet_id" value="<?= $betId ?>">
                <input type="hidden" name="bet_nome" value="<?= htmlspecialchars($betNome) ?>">
                
                <div class="mb-3">
                    <label for="loginEmail" class="form-label">E-mail</label>
                    <input type="email" class="form-control" id="loginEmail" name="email" required>
                </div>
                
                <div class="mb-3">
                    <label for="loginSenha" class="form-label">Senha</label>
                    <input type="password" class="form-control" id="loginSenha" name="senha" required>
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-sign-in-alt me-2"></i> Entrar
                    </button>
                </div>
            </form>
        </div>
        
        <div class="col-md-6 border-start ps-md-4">
            <h4 class="mb-4">Cadastrar</h4>
            <p class="mb-4">Ainda não tem conta? Cadastre-se agora.</p>
            
            <div class="d-grid gap-2">
                <button type="button" class="btn btn-outline-primary btn-lg" id="btnCadastrar">
                    <i class="fas fa-user-plus me-2"></i> Criar Conta
                </button>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Configuração do modal
    const modalAvaliacao = new bootstrap.Modal(document.getElementById('modalAvaliacao'));
    const modalRecuperar = new bootstrap.Modal(document.getElementById('modalRecuperarSenha'));

    // Link para recuperar senha
    $('#linkRecuperarSenha').click(function(e) {
        e.preventDefault();
        modalAvaliacao.hide();
        modalRecuperar.show();
    });

    // Formulário de login
    $('#formLogin').on('submit', function(e) {
        e.preventDefault();
        
        // Reset estados
        $('#loginError').addClass('d-none');
        $('#loginEmail').removeClass('is-invalid');
        $('#loginSenha').removeClass('is-invalid');
        
        // Validação básica
        let valid = true;
        if ($('#loginEmail').val() === '') {
            $('#loginEmail').addClass('is-invalid');
            valid = false;
        }
        if ($('#loginSenha').val() === '') {
            $('#loginSenha').addClass('is-invalid');
            valid = false;
        }
        if (!valid) return;

        // Envia o login
        $.ajax({
            url: 'includes/login.php',
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Atualiza a página ou carrega o próximo passo
                    window.location.reload();
                } else {
                    $('#errorMessage').text(response.message || 'E-mail ou senha incorretos');
                    $('#loginError').removeClass('d-none');
                }
            },
            error: function() {
                $('#errorMessage').text('Erro ao conectar com o servidor');
                $('#loginError').removeClass('d-none');
            }
        });
    });
});
</script>