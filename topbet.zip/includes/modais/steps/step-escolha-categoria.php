<?php
$bet_id = $_POST['bet_id'];
$bet_nome = $_POST['bet_nome'];
?>

<div class="modal-header">
    <h5 class="modal-title">Avaliar <?= htmlspecialchars($bet_nome) ?></h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body text-center">
    <h4 class="mb-4">O que deseja avaliar em <?= htmlspecialchars($bet_nome) ?>?</h4>
    
    <form id="formAvaliacao">
        <input type="hidden" name="bet_id" value="<?= $bet_id ?>">
        <input type="hidden" name="bet_nome" value="<?= htmlspecialchars($bet_nome) ?>">
        
        <div class="row">
            <div class="col-md-4 mb-3">
                <div class="card categoria-card-avaliacao h-100" data-categoria="cassino">
                    <div class="card-body">
                        <i class="fas fa-dice fa-3x mb-3"></i>
                        <h5>Cassino</h5>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card categoria-card-avaliacao h-100" data-categoria="cassino-vivo">
                    <div class="card-body">
                        <i class="fas fa-video fa-3x mb-3"></i>
                        <h5>Cassino ao Vivo</h5>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card categoria-card-avaliacao h-100" data-categoria="slots">
                    <div class="card-body">
                        <i class="fas fa-sliders-h fa-3x mb-3"></i>
                        <h5>Slots</h5>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card categoria-card-avaliacao h-100" data-categoria="poker">
                    <div class="card-body">
                        <i class="fas fa-spade fa-3x mb-3"></i>
                        <h5>Poker</h5>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4 mb-3">
                <div class="card categoria-card-avaliacao h-100" data-categoria="esportes">
                    <div class="card-body">
                        <i class="fas fa-football-ball fa-3x mb-3"></i>
                        <h5>Apostas Esportivas</h5>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>