<?php
// Início do arquivo
require_once __DIR__ . '/../../conexao.php';

// Verificação de sessão e CSRF Token
if (session_status() === PHP_SESSION_NONE) session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    try {
        // Verificação robusta do CSRF Token
        if (empty($_POST['csrf_token']) || empty($_SESSION['csrf_token']) || 
            !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
            throw new Exception("Token de segurança inválido", 403);
        }

        // Validação dos campos obrigatórios
        $requiredFields = ['nome', 'email', 'senha', 'bet_id', 'bet_nome'];
        $missingFields = array_diff($requiredFields, array_keys($_POST));
        
        if (!empty($missingFields)) {
            throw new Exception("Campos obrigatórios faltando: " . implode(', ', $missingFields), 400);
        }

        // Processamento dos dados
        $nome = $conn->real_escape_string(trim($_POST['nome']));
        $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
        $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT, ['cost' => 12]);
        $bet_id = (int)$_POST['bet_id'];
        $bet_nome = $conn->real_escape_string(trim($_POST['bet_nome']));

        // Validações adicionais
        if (strlen($nome) < 3) throw new Exception("Nome muito curto (mínimo 3 caracteres)", 400);
        if (!$email) throw new Exception("Email inválido", 400);
        if (strlen($_POST['senha']) < 8) throw new Exception("Senha deve ter pelo menos 8 caracteres", 400);

        // Verifica se email já existe
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows > 0) {
            throw new Exception("Este email já está cadastrado", 409);
        }

        // Inserção segura usando prepared statements
        $stmt = $conn->prepare("INSERT INTO usuarios 
            (nome, email, senha, nivel_acesso, ativo, data_cadastro) 
            VALUES (?, ?, ?, 1, 1, NOW())");
        
        $stmt->bind_param("sss", $nome, $email, $senha);
        
        if (!$stmt->execute()) {
            throw new Exception("Erro ao cadastrar usuário: " . $stmt->error, 500);
        }

        $user_id = $stmt->insert_id;

        // Atualiza a sessão
        $_SESSION['usuario_id'] = $user_id;
        $_SESSION['usuario_nome'] = $nome;
        $_SESSION['usuario_email'] = $email;
        $_SESSION['usuario_nivel'] = 1;

        // Resposta de sucesso
        echo json_encode([
            'success' => true,
            'message' => 'Cadastro realizado com sucesso!',
            'user_id' => $user_id,
            'redirect' => 'formulario-avaliacao.php?bet_id='.$bet_id.'&bet_nome='.urlencode($bet_nome)
        ]);

    } catch (Exception $e) {
        http_response_code($e->getCode() ?: 500);
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage(),
            'error_code' => $e->getCode()
        ]);
    }
    exit;
}

// Gera novo token CSRF se não existir
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro - TopBets</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        .password-strength {
            height: 5px;
            margin-top: 5px;
            background-color: #e9ecef;
            border-radius: 3px;
            overflow: hidden;
        }
        .password-strength-bar {
            height: 100%;
            width: 0;
            transition: width 0.3s;
        }
        .password-requirements {
            font-size: 0.8rem;
            color: #6c757d;
        }
        .requirement {
            margin-bottom: 3px;
        }
        .requirement.met {
            color: #28a745;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0"><i class="fas fa-user-plus me-2"></i>Criar sua conta</h4>
                    </div>
                    <div class="card-body">
                        <form id="formCadastroPrincipal" novalidate>
                            <input type="hidden" name="bet_id" value="<?= htmlspecialchars($_GET['bet_id'] ?? '', ENT_QUOTES) ?>">
                            <input type="hidden" name="bet_nome" value="<?= htmlspecialchars($_GET['bet_nome'] ?? '', ENT_QUOTES) ?>">
                            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?? '' ?>">
                            
                            <div class="mb-3">
                                <label for="nome" class="form-label">Nome Completo</label>
                                <input type="text" class="form-control" id="nome" name="nome" required minlength="3">
                                <div class="invalid-feedback">Por favor, insira um nome válido (mínimo 3 caracteres)</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label">E-mail</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                                <div class="email-feedback email-exists mt-1">
                                    <small class="text-danger"><i class="fas fa-exclamation-circle me-1"></i> Este email já está cadastrado. <a href="recuperar-senha.php?email=" id="linkRecuperar">Recuperar senha?</a></small>
                                </div>
                                <div class="invalid-feedback">Por favor, insira um email válido</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="senha" class="form-label">Senha</label>
                                <input type="password" class="form-control" id="senha" name="senha" required minlength="8">
                                <div class="password-strength mt-2">
                                    <div class="password-strength-bar" id="passwordStrengthBar"></div>
                                </div>
                                <div class="password-requirements mt-2">
                                    <div class="requirement" id="reqLength"><i class="fas fa-circle me-1"></i> Mínimo 8 caracteres</div>
                                    <div class="requirement" id="reqUpper"><i class="fas fa-circle me-1"></i> Pelo menos 1 letra maiúscula</div>
                                    <div class="requirement" id="reqNumber"><i class="fas fa-circle me-1"></i> Pelo menos 1 número</div>
                                </div>
                                <div class="invalid-feedback">A senha não atende aos requisitos</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="confirmar_senha" class="form-label">Confirmar Senha</label>
                                <input type="password" class="form-control" id="confirmar_senha" required>
                                <div class="invalid-feedback">As senhas não coincidem</div>
                            </div>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="termos" required>
                                <label class="form-check-label" for="termos">Li e aceito os <a href="termos.php" target="_blank">Termos de Uso</a> e <a href="privacidade.php" target="_blank">Política de Privacidade</a></label>
                                <div class="invalid-feedback">Você deve aceitar os termos</div>
                            </div>
                            
                            <button type="submit" class="btn btn-primary w-100 py-2" id="btnCadastrar">
                                <i class="fas fa-user-plus me-2"></i> Criar Conta
                            </button>
                            
                            <div class="text-center mt-3">
                                <small>Já tem uma conta? <a href="login.php">Faça login</a></small>
                            </div>
                        </form>
                        
                        <div class="alert alert-success mt-3 d-none" id="successAlert">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-check-circle fa-2x me-3"></i>
                                <div>
                                    <h5 class="alert-heading mb-1">Cadastro concluído!</h5>
                                    <p class="mb-0">Redirecionando para continuar sua avaliação...</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/zxcvbn@4.4.2/dist/zxcvbn.js"></script>
    
<script>
$(document).ready(function() {
    const app = {
        currentBet: { id: null, nome: null },
        csrfToken: '<?= $_SESSION['csrf_token'] ?? '' ?>',

        init: function() {
            this.bindEvents();
            this.checkCSRFToken();
        },

        checkCSRFToken: function() {
            if (!this.csrfToken) {
                console.error('CSRF Token não encontrado');
                this.refreshCSRFToken();
            }
        },

        refreshCSRFToken: function() {
            // Implementar lógica para gerar novo token se necessário
            console.log('Atualizando CSRF Token...');
        },

        bindEvents: function() {
            $('#btnIniciarAvaliacao').click((e) => {
                e.preventDefault();
                this.loadStep('lista-bets');
            });

            $(document)
                .on('click', '.bet-card-avaliacao', (e) => this.handleBetSelection(e))
                .on('click', '#btnCadastrar', (e) => this.handleRegisterClick(e));
        },

        handleBetSelection: function(e) {
            e.preventDefault();
            const card = $(e.currentTarget);
            this.currentBet = {
                id: card.data('bet-id'),
                nome: card.data('bet-nome')
            };
            this.loadStep('escolha-login');
        },

        handleRegisterClick: function(e) {
            e.preventDefault();
            this.loadCadastroForm();
        },

        loadCadastroForm: function() {
            // Garante valores padrão
            const betData = {
                id: this.currentBet.id || 0,
                nome: this.currentBet.nome || 'Casa de Apostas'
            };

            this.showLoader();

            $.ajax({
                url: 'includes/modais/steps/step-cadastro-form.php',
                type: 'GET', // Alterado para GET para carregamento inicial
                data: {
                    bet_id: betData.id,
                    bet_nome: betData.nome,
                    csrf_token: this.csrfToken,
                    is_ajax: true
                },
                dataType: 'html',
                success: (response) => this.handleCadastroFormResponse(response),
                error: (xhr) => this.handleCadastroFormError(xhr)
            });
        },

        showLoader: function() {
            $('#modalAvaliacaoContent').html(`
                <div class="text-center p-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Carregando...</span>
                    </div>
                    <p class="mt-2">Preparando formulário de cadastro...</p>
                </div>
            `);
            $('#modalAvaliacao').modal('show');
        },

        handleCadastroFormResponse: function(response) {
            if (response.includes('Warning') || response.includes('Error')) {
                console.error('Erro no servidor:', response);
                this.showError('Erro ao carregar formulário');
                return;
            }

            $('#modalAvaliacaoContent').html(response);
            this.initFormValidation();
        },

        initFormValidation: function() {
            $('#formCadastro').on('submit', (e) => this.handleFormSubmit(e));
            
            // Validação em tempo real
            $('#cadastroNome').on('blur', () => this.validateName());
            $('#cadastroEmail').on('blur', () => this.validateEmail());
            $('#cadastroSenha').on('input', () => {
                this.validatePassword();
                this.updatePasswordStrength();
            });
        },

        validateName: function() {
            const $field = $('#cadastroNome');
            const isValid = $field.val().trim().length >= 3;
            $field.toggleClass('is-invalid', !isValid);
            return isValid;
        },

        validateEmail: function() {
            const $field = $('#cadastroEmail');
            const email = $field.val().trim();
            const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
            $field.toggleClass('is-invalid', !isValid);
            return isValid;
        },

        validatePassword: function() {
            const $field = $('#cadastroSenha');
            const password = $field.val();
            const isValid = password.length >= 8;
            $field.toggleClass('is-invalid', !isValid);
            return isValid;
        },

        updatePasswordStrength: function() {
            const password = $('#cadastroSenha').val();
            const strength = Math.min(4, Math.max(1, password.length / 2));
            
            $('#passwordStrength')
                .removeClass()
                .addClass(['bg-danger', 'bg-warning', 'bg-info', 'bg-success'][strength - 1])
                .css('width', (strength * 25) + '%');
        },

        handleFormSubmit: function(e) {
            e.preventDefault();
            
            if (this.validateForm()) {
                this.submitForm();
            }
        },

        validateForm: function() {
            let isValid = true;
            
            if (!this.validateName()) isValid = false;
            if (!this.validateEmail()) isValid = false;
            if (!this.validatePassword()) isValid = false;
            if ($('#cadastroSenha').val() !== $('#cadastroConfirmarSenha').val()) {
                $('#cadastroConfirmarSenha').addClass('is-invalid');
                isValid = false;
            }
            if (!$('#termosCheck').is(':checked')) {
                $('#termosCheck').addClass('is-invalid');
                isValid = false;
            }

            if (!isValid) {
                this.showError('Por favor, corrija os campos destacados');
                return false;
            }
            
            return true;
        },

        submitForm: function() {
            const $btn = $('#btnSubmitCadastro');
            $btn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i> Cadastrando...');

            const formData = {
                nome: $('#cadastroNome').val().trim(),
                email: $('#cadastroEmail').val().trim(),
                senha: $('#cadastroSenha').val(),
                bet_id: this.currentBet.id || 0,
                bet_nome: this.currentBet.nome || '',
                csrf_token: this.csrfToken
            };

            $.ajax({
                url: 'includes/modais/steps/step-cadastro-form.php',
                type: 'POST',
                data: formData,
                dataType: 'json',
                success: (response) => this.handleSubmitResponse(response),
                error: (xhr) => this.handleSubmitError(xhr),
                complete: () => {
                    $btn.prop('disabled', false).html('<i class="fas fa-user-plus me-2"></i> Cadastrar');
                }
            });
        },

        handleSubmitResponse: function(response) {
            if (response.success) {
                this.showSuccess(response.message);
                setTimeout(() => {
                    if (response.redirect) {
                        window.location.href = response.redirect;
                    } else {
                        $('#modalAvaliacao').modal('hide');
                    }
                }, 2000);
            } else {
                this.showError(response.message);
                if (response.field) {
                    $(`#${response.field}`).addClass('is-invalid');
                }
            }
        },

        handleCadastroFormError: function(xhr) {
            let errorMsg = 'Erro ao carregar formulário';
            if (xhr.status === 400) {
                errorMsg = 'Requisição inválida. Verifique os parâmetros.';
            } else if (xhr.status === 403) {
                errorMsg = 'Token de segurança inválido. Recarregue a página.';
                this.refreshCSRFToken();
            }
            
            this.showError(errorMsg);
            console.error('Erro no AJAX:', xhr.responseText);
        },

        handleSubmitError: function(xhr) {
            let errorMsg = 'Erro no servidor';
            if (xhr.responseJSON && xhr.responseJSON.message) {
                errorMsg = xhr.responseJSON.message;
            }
            this.showError(errorMsg);
        },

        showError: function(message) {
            Swal.fire({
                icon: 'error',
                title: 'Erro',
                text: message,
                confirmButtonText: 'OK'
            });
        },

        showSuccess: function(message) {
            Swal.fire({
                icon: 'success',
                title: 'Sucesso!',
                text: message,
                timer: 2000,
                showConfirmButton: false
            });
        }
    };

    app.init();
});
</script>
</body>
</html>