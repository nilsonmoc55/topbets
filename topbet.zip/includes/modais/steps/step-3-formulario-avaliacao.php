<?php
$categoria = $_POST['categoria'];
$bet_id = $_POST['bet_id'];
$bet_nome = $_POST['bet_nome'];

// Perguntas específicas por categoria
$perguntas = [
    'cassino' => [
        'Variedade de jogos',
        'Qualidade dos gráficos',
        'Bônus de boas-vindas'
    ],
    'esportes' => [
        'Variedade de esportes',
        'Odds competitivas',
        'Opções de apostas ao vivo'
    ]
    // Adicione outras categorias...
];
?>

<div class="modal-header">
    <h5 class="modal-title">Avaliar <?= htmlspecialchars($bet_nome) ?> - <?= ucfirst($categoria) ?></h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

<form id="formAvaliacao">
    <input type="hidden" name="bet_id" value="<?= $bet_id ?>">
    <input type="hidden" name="categoria" value="<?= $categoria ?>">
    
    <div class="modal-body">
        <?php foreach($perguntas[$categoria] as $pergunta): ?>
        <div class="mb-4">
            <h6><?= $pergunta ?></h6>
            <div class="rating">
                <?php for($i = 1; $i <= 5; $i++): ?>
                <input type="radio" id="<?= slug($pergunta) ?>-<?= $i ?>" name="avaliacao[<?= slug($pergunta) ?>]" value="<?= $i ?>">
                <label for="<?= slug($pergunta) ?>-<?= $i ?>"><i class="far fa-star"></i></label>
                <?php endfor; ?>
            </div>
        </div>
        <?php endforeach; ?>
        
        <div class="mb-4">
            <label class="form-label">Avaliação Geral</label>
            <div class="rating">
                <?php for($i = 1; $i <= 5; $i++): ?>
                <input type="radio" id="geral-<?= $i ?>" name="avaliacao[geral]" value="<?= $i ?>" required>
                <label for="geral-<?= $i ?>"><i class="far fa-star"></i></label>
                <?php endfor; ?>
            </div>
        </div>
        
        <div class="mb-3">
            <label class="form-label">Teve algum problema que deseja relatar? (Opcional)</label>
            <textarea class="form-control" name="problema" rows="3"></textarea>
        </div>
    </div>
    
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="submit" class="btn btn-primary">Enviar Avaliação</button>
    </div>
</form>

<script>
$(document).ready(function() {
    $('#formAvaliacao').submit(function(e) {
        e.preventDefault();
        
        $.ajax({
            url: 'processa-avaliacao.php',
            type: 'POST',
            data: $(this).serialize(),
            success: function() {
                $.ajax({
                    url: 'includes/modais/steps/step-4-confirmacao.php',
                    type: 'POST',
                    data: {
                        bet_id: <?= $bet_id ?>,
                        bet_nome: '<?= $bet_nome ?>'
                    },
                    success: function(response) {
                        $('#modalAvaliacaoContent').html(response);
                    }
                });
            }
        });
    });
});
</script>