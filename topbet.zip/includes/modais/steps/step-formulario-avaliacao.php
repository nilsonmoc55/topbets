<?php
include '../../conexao.php';

$categoria = $_POST['categoria'];
$bet_id = $_POST['bet_id'];
$bet_nome = $_POST['bet_nome'];

// Perguntas para cada categoria
$perguntas = [
    'cassino' => [
        'Variedade de jogos', 
        'Qualidade dos gráficos', 
        'Bônus de boas-vindas'
    ],
    'cassino-vivo' => [
        'Qualidade dos dealers',
        'Variedade de mesas',
        'Interatividade'
    ],
    'slots' => [
        'Variedade de máquinas',
        'Prêmios e jackpots',
        'Performance dos jogos'
    ],
    'poker' => [
        'Variedade de torneios',
        'Nível dos jogadores',
        'Software da mesa'
    ],
    'esportes' => [
        'Variedade de esportes', 
        'Odds competitivas', 
        'Opções de apostas ao vivo'
    ]
];

if (!isset($perguntas[$categoria])) {
    die('<div class="alert alert-danger">Categoria inválida</div>');
}
?>

<div class="modal-header">
    <h5 class="modal-title">Avaliar <?= htmlspecialchars($bet_nome) ?> - <?= ucfirst(str_replace('-', ' ', $categoria)) ?></h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

<form id="formAvaliacao">
    <input type="hidden" name="bet_id" value="<?= $bet_id ?>">
    <input type="hidden" name="categoria" value="<?= $categoria ?>">
    
    <div class="modal-body">
        <?php foreach($perguntas[$categoria] as $index => $pergunta): ?>
        <div class="mb-4">
            <label class="form-label"><?= $pergunta ?></label>
            <div class="rating-group" data-pergunta="<?= $index ?>">
                <?php for($i=5; $i>=1; $i--): ?>
                <input type="radio" id="pergunta-<?= $index ?>-nota-<?= $i ?>" 
                       name="avaliacao[<?= $index ?>]" value="<?= $i ?>">
                <label for="pergunta-<?= $index ?>-nota-<?= $i ?>">
                    <i class="far fa-star"></i>
                </label>
                <?php endfor; ?>
            </div>
        </div>
        <?php endforeach; ?>
        
        <div class="mb-4">
            <label class="form-label">Avaliação Geral</label>
            <div class="rating-group" data-pergunta="geral">
                <?php for($i=5; $i>=1; $i--): ?>
                <input type="radio" id="geral-nota-<?= $i ?>" 
                       name="avaliacao[geral]" value="<?= $i ?>" required>
                <label for="geral-nota-<?= $i ?>">
                    <i class="far fa-star"></i>
                </label>
                <?php endfor; ?>
            </div>
        </div>
        
        <div class="mb-3">
            <label class="form-label">Teve algum problema? (Opcional)</label>
            <textarea class="form-control" name="problema" rows="3"></textarea>
        </div>
    </div>
    
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-voltar">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </button>
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-check me-1"></i> Enviar Avaliação
        </button>
    </div>
</form>

<script>
$(document).ready(function() {
    // Configuração das estrelas
    $('.rating-group input').change(function() {
        const group = $(this).closest('.rating-group');
        const value = $(this).val();
        
        group.find('label').each(function(index) {
            if (index < (5 - value + 1)) {
                $(this).find('i').removeClass('far').addClass('fas text-warning');
            } else {
                $(this).find('i').removeClass('fas text-warning').addClass('far');
            }
        });
    });
    
    // Botão Voltar
    $('.btn-voltar').click(function() {
        const formData = $('#formAvaliacao').serializeArray();
        const dados = {
            bet_id: <?= $bet_id ?>,
            bet_nome: '<?= addslashes($bet_nome) ?>'
        };
        
        // Mantém os dados do formulário ao voltar
        formData.forEach(function(item) {
            if (item.name !== 'bet_id' && item.name !== 'categoria') {
                if (!dados[item.name]) {
                    dados[item.name] = item.value;
                }
            }
        });
        
        carregarStep('escolha-categoria', dados);
    });
    
    // Envio do formulário
   $('#formAvaliacao').off('submit').on('submit', function(e) {
        e.preventDefault();
        
        // Validação
        let valid = true;
        $('.rating-group').each(function() {
            if (!$(this).find('input:checked').length) {
                valid = false;
                $(this).css('border', '1px solid red');
            } else {
                $(this).css('border', 'none');
            }
        });
        
        if (!valid) {
            alert('Por favor, avalie todos os itens');
            return;
        }
        
        // Mostra loading
        $('#modalAvaliacaoContent').html(`
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Enviando...</span>
                </div>
                <p class="mt-2">Salvando sua avaliação...</p>
            </div>
        `);
        
        // Envia os dados via AJAX
        $.ajax({
            url: 'processa-avaliacao.php',
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    // Redireciona para a confirmação com os dados necessários
                    carregarStep('confirmacao', {
                        bet_id: <?= $bet_id ?>,
                        bet_nome: '<?= addslashes($bet_nome) ?>',
                        avaliacao_id: response.avaliacao_id
                    });
                } else {
                    // Mostra mensagem de erro
                    $('#modalAvaliacaoContent').html(`
                        <div class="alert alert-danger">
                            ${response.message || 'Erro ao salvar avaliação'}
                            <div class="text-center mt-2">
                                <button class="btn btn-sm btn-primary" onclick="carregarStep('formulario-avaliacao', <?= json_encode(['bet_id' => $bet_id, 'bet_nome' => $bet_nome, 'categoria' => $categoria]) ?>)">
                                    Tentar Novamente
                                </button>
                            </div>
                        </div>
                    `);
                }
            },
            error: function(xhr, status, error) {
                $('#modalAvaliacaoContent').html(`
                    <div class="alert alert-danger">
                        Erro na comunicação com o servidor: ${error}
                        <div class="text-center mt-2">
                            <button class="btn btn-sm btn-primary" onclick="carregarStep('formulario-avaliacao', <?= json_encode(['bet_id' => $bet_id, 'bet_nome' => $bet_nome, 'categoria' => $categoria]) ?>)">
                                Tentar Novamente
                            </button>
                        </div>
                    </div>
                `);
            }
        });
    });
});
</script>