<?php
session_start();
require_once '../../conexao.php'; // Ajuste o caminho conforme sua estrutura

// Verifica se o usuário está logado
$usuarioLogado = isset($_SESSION['usuario_id']);
$usuarioNome = $_SESSION['usuario_nome'] ?? '';

// Recebe os dados da bet (casa de apostas) do POST
$betId = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$betNome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);

if (!$betId || !$betNome) {
    die('Dados da casa de apostas inválidos.');
}
?>

<div class="modal-header">
    <h5 class="modal-title">Avaliar <?= htmlspecialchars($betNome) ?></h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

<div class="modal-body text-center">
    <?php if ($usuarioLogado): ?>
        <!-- Opções para usuário LOGADO -->
        <div class="mb-4">
            <h5>Olá, <?= htmlspecialchars($usuarioNome) ?>!</h5>
            <p>Como deseja realizar sua avaliação?</p>
        </div>

        <div class="d-grid gap-3">
            <button type="button" class="btn btn-primary btn-lg py-3" id="btnAvaliarComoUsuario">
                <i class="fas fa-user me-2"></i> Avaliar como <?= htmlspecialchars(explode(' ', $usuarioNome)[0]) ?>
            </button>
            
            <button type="button" class="btn btn-outline-secondary btn-lg py-3" id="btnAvaliarAnonimamente">
                <i class="fas fa-user-secret me-2"></i> Avaliar Anonimamente
            </button>
        </div>

    <?php else: ?>
        <!-- Opções para usuário NÃO LOGADO -->
        <div class="mb-4">
            <h5>Avaliar <?= htmlspecialchars($betNome) ?></h5>
            <p>Escolha como deseja continuar:</p>
        </div>

        <div class="d-grid gap-3">
            <button type="button" class="btn btn-outline-secondary btn-lg py-3" id="btnAvaliarAnonimamente">
                <i class="fas fa-user-secret me-2"></i> Avaliar Anonimamente
            </button>
            
            <button type="button" class="btn btn-primary btn-lg py-3" id="btnFazerLogin">
                <i class="fas fa-sign-in-alt me-2"></i> Fazer Login/Cadastrar
            </button>
        </div>
    <?php endif; ?>
</div>

<script>
// Armazena os dados da bet no modal para uso posterior
$('#modalAvaliacao').data('bet', {
    id: <?= $betId ?>,
    nome: '<?= addslashes($betNome) ?>'
});
</script>