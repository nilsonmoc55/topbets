<?php
$bet_id = $_POST['bet_id'];
$bet_nome = $_POST['bet_nome'];
?>

<div class="modal-header">
    <h5 class="modal-title">Avaliação Concluída!</h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body text-center py-4">
    <i class="fas fa-check-circle text-success fa-5x mb-4"></i>
    <h4 class="mb-3">Sua avaliação foi registrada com sucesso!</h4>
    <p class="text-muted">Obrigado por compartilhar sua experiência.</p>
</div>
<div class="modal-footer justify-content-center">
    <button type="button" class="btn btn-outline-primary me-2" onclick="carregarStep('1-lista-bets')">
        <i class="fas fa-plus-circle me-1"></i> Avaliar outra Casa
    </button>
    <button type="button" class="btn btn-primary" onclick="carregarStep('2-escolha-categoria', {bet_id: <?= $bet_id ?>, bet_nome: '<?= $bet_nome ?>'})">
        <i class="fas fa-star me-1"></i> Avaliar outra Categoria
    </button>
</div>

<script>
function carregarStep(step, dados = {}) {
    $.ajax({
        url: 'includes/modais/steps/step-' + step + '.php',
        type: 'POST',
        data: dados,
        success: function(response) {
            $('#modalAvaliacaoContent').html(response);
        }
    });
}
</script>