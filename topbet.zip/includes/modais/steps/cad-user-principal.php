<?php
include '../../conexao.php';
session_start();

// Verifica se está checando e-mail
if (isset($_GET['check_email']) && isset($_GET['email'])) {
    $email = filter_var($_GET['email'], FILTER_SANITIZE_EMAIL);

    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    echo json_encode(['exists' => $result->num_rows > 0]);
    exit;
}

// Processa o cadastro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
    $bet_id = $_POST['bet_id'] ?? '';
    $bet_nome = $_POST['bet_nome'] ?? '';

    // Verifica se e-mail já existe
    $check = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Este email já está cadastrado.']);
        exit;
    }

    // Insere o novo usuário
    $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, nivel_acesso, ativo) VALUES (?, ?, ?, 1, 1)");
    $stmt->bind_param("sss", $nome, $email, $senha);
    if ($stmt->execute()) {
        $_SESSION['usuario_id'] = $stmt->insert_id;
        $_SESSION['usuario_nome'] = $nome;
        $_SESSION['usuario_email'] = $email;
        $_SESSION['usuario_nivel'] = 1;

        echo json_encode([
            'success' => true,
            'message' => 'Cadastro realizado com sucesso!',
            'redirect' => 'formulario-avaliacao.php?bet_id=' . $bet_id . '&bet_nome=' . urlencode($bet_nome)
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Erro ao cadastrar.']);
    }
    exit;
}
?>
