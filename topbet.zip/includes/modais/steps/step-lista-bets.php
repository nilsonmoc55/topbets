<?php
include '../../conexao.php';
$bets = $conn->query("SELECT id, nome, logo FROM bets WHERE ativo = 1 ORDER BY nome");
?>

<div class="modal-header">
    <h5 class="modal-title">Selecione a Casa de Aposta</h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <?php if ($bets->num_rows > 0): ?>
    <div class="row">
        <?php while ($bet = $bets->fetch_assoc()): ?>
        <div class="col-md-6 mb-3">
            <div class="card bet-card-avaliacao h-100 cursor-pointer" 
                 data-bet-id="<?= $bet['id'] ?>"
                 data-bet-nome="<?= htmlspecialchars($bet['nome']) ?>">
                <div class="card-body text-center">
                    <?php if(!empty($bet['logo'])): ?>
                    <img src="uploads/logos/<?= $bet['logo'] ?>" alt="<?= htmlspecialchars($bet['nome']) ?>" class="img-fluid mb-2" style="max-height: 50px;">
                    <?php endif; ?>
                    <h5><?= htmlspecialchars($bet['nome']) ?></h5>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php else: ?>
    <div class="alert alert-warning">Nenhuma casa de apostas dispon�vel no momento.</div>
    <?php endif; ?>
</div>

<style>
    .cursor-pointer { cursor: pointer; }
    .bet-card-avaliacao:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        transition: all 0.3s ease;
    }
</style>