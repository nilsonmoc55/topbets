<?php
include '../../conexao.php';

// Verifica se a conexão foi estabelecida
if (!$conn) {
    die("<div class='alert alert-danger'>Erro na conexão com o banco de dados</div>");
}

// Busca as casas de apostas ativas
$query = "SELECT id, nome, logo, descricao_curta FROM bets WHERE ativo = 1 ORDER BY nome";
$result = $conn->query($query);

if (!$result) {
    die("<div class='alert alert-danger'>Erro ao buscar casas de apostas: " . $conn->error . "</div>");
}
?>

<div class="modal-header">
    <h5 class="modal-title">Selecione a Casa de Aposta</h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <?php if ($result->num_rows > 0): ?>
        <div class="row">
            <?php while ($bet = $result->fetch_assoc()): ?>
                <div class="col-md-6 mb-3">
                    <div class="card bet-card h-100" 
                         data-bet-id="<?= $bet['id'] ?>"
                         data-bet-nome="<?= htmlspecialchars($bet['nome']) ?>">
                        <div class="row g-0">
                            <div class="col-md-4 d-flex align-items-center justify-content-center p-2">
                                <?php if (!empty($bet['logo'])): ?>
                                    <img src="uploads/logos/<?= $bet['logo'] ?>" class="img-fluid rounded-start" alt="<?= htmlspecialchars($bet['nome']) ?>">
                                <?php else: ?>
                                    <div class="text-center py-3">
                                        <i class="fas fa-landmark fa-3x text-muted"></i>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title"><?= htmlspecialchars($bet['nome']) ?></h5>
                                    <?php if (!empty($bet['descricao_curta'])): ?>
                                        <p class="card-text"><small class="text-muted"><?= htmlspecialchars($bet['descricao_curta']) ?></small></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-warning text-center">
            <i class="fas fa-exclamation-circle me-2"></i>
            Nenhuma casa de apostas disponível no momento.
        </div>
    <?php endif; ?>
</div>

<script>
// Esta parte agora está no index.php (função configurarEventosBets)
</script>