<?php
session_start();
$email = $_POST['email'] ?? '';
$senha = $_POST['senha'] ?? '';

// Simulação de login — substitua por sua lógica de banco de dados
if ($email === 'teste@teste.com' && $senha === '1234') {
    $_SESSION['usuario_id'] = 1;
    $_SESSION['usuario_nome'] = 'Usuário Teste';

    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Usuário ou senha incorretos.']);
}
