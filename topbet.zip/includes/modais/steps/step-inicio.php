<?php
include '../../conexao.php';
?>
<div class="modal-header">
    <h5 class="modal-title">Avaliar Casa de Aposta</h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body text-center">
    <h4>Selecione o tipo de aposta</h4>
    <div class="row mt-4">
        <?php
        $categorias = $conn->query("SELECT * FROM categorias_avaliacao");
        while ($cat = $categorias->fetch_assoc()):
        ?>
        <div class="col-md-4 mb-4">
            <div class="categoria-card card h-100 p-3" 
                 data-categoria-id="<?= $cat['id'] ?>" 
                 data-categoria-nome="<?= htmlspecialchars($cat['nome']) ?>">
                <div class="card-body text-center">
                    <i class="<?= $cat['icone'] ?> fa-3x mb-3"></i>
                    <h5><?= htmlspecialchars($cat['nome']) ?></h5>
                    <p class="text-muted small"><?= htmlspecialchars($cat['descricao']) ?></p>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>