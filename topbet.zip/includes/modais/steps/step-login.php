<?php
session_start();
include __DIR__ . '/../../conexao.php';

$bet_id = $_POST['bet_id'] ?? '';
$bet_nome = $_POST['bet_nome'] ?? '';
$erros = $_SESSION['login_errors'] ?? [];
unset($_SESSION['login_errors']);
?>

<div class="modal-step active">
    <div class="modal-header bg-primary text-white">
        <h5 class="modal-title">
            <i class="fas fa-sign-in-alt me-2"></i> Login para Avaliar <?= htmlspecialchars($bet_nome) ?>
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    
    <div class="modal-body">
        <form id="formLoginAvaliacao">
            <input type="hidden" name="bet_id" value="<?= $bet_id ?>">
            <input type="hidden" name="bet_nome" value="<?= htmlspecialchars($bet_nome) ?>">
            
            <!-- E-mail -->
            <div class="mb-3">
                <label class="form-label">E-mail</label>
                <input type="email" class="form-control <?= !empty($erros['email']) ? 'is-invalid' : '' ?>" 
                       name="email" value="<?= htmlspecialchars($erros['email_value'] ?? '') ?>" required>
                <?php if(!empty($erros['email'])): ?>
                    <div class="invalid-feedback"><?= $erros['email'] ?></div>
                <?php endif; ?>
            </div>
            
            <!-- Senha -->
            <div class="mb-3">
                <label class="form-label">Senha</label>
                <input type="password" class="form-control <?= !empty($erros['senha']) ? 'is-invalid' : '' ?>" 
                       name="senha" required>
                <?php if(!empty($erros['senha'])): ?>
                    <div class="invalid-feedback"><?= $erros['senha'] ?></div>
                <?php endif; ?>
            </div>
            
            <!-- Lembrar Senha -->
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="lembrarSenha" name="lembrar">
                <label class="form-check-label" for="lembrarSenha">Lembrar de mim</label>
            </div>
            
            <!-- Links -->
            <div class="mb-3 d-flex justify-content-between">
                <a href="#" class="text-decoration-none" 
                   onclick="carregarStep('recuperar-senha', { bet_id: '<?= $bet_id ?>', bet_nome: '<?= htmlspecialchars($bet_nome) ?>' })">
                    Esqueceu a senha?
                </a>
                
                <a href="#" class="text-decoration-none" 
                   onclick="carregarStep('cadastro', { bet_id: '<?= $bet_id ?>', bet_nome: '<?= htmlspecialchars($bet_nome) ?>' })">
                    Criar conta
                </a>
            </div>
            
            <!-- Botões -->
            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary py-2">
                    <i class="fas fa-sign-in-alt me-2"></i> Entrar
                </button>
                
                <button type="button" class="btn btn-outline-secondary" 
                        onclick="carregarStep('escolha-login', { bet_id: '<?= $bet_id ?>', bet_nome: '<?= htmlspecialchars($bet_nome) ?>' })">
                    <i class="fas fa-arrow-left me-2"></i> Voltar
                </button>
            </div>
        </form>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#formLoginAvaliacao').submit(function(e) {
        e.preventDefault();
        var form = $(this);
        var submitBtn = form.find('button[type="submit"]');
        var originalText = submitBtn.html();
        
        submitBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i> Entrando...');
        
        $.ajax({
            url: 'includes/login-avaliacao.php',
            type: 'POST',
            data: form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Atualiza a interface e volta para escolha de avaliação
                    carregarStep('escolha-login', {
                        bet_id: response.bet_id,
                        bet_nome: response.bet_nome
                    });
                } else {
                    // Mostra erros no formulário
                    submitBtn.prop('disabled', false).html(originalText);
                    
                    // Limpa erros anteriores
                    $('.is-invalid').removeClass('is-invalid');
                    $('.invalid-feedback').remove();
                    
                    // Adiciona novos erros
                    if (response.errors.email) {
                        $('input[name="email"]').addClass('is-invalid')
                            .after('<div class="invalid-feedback">' + response.errors.email + '</div>');
                    }
                    if (response.errors.senha) {
                        $('input[name="senha"]').addClass('is-invalid')
                            .after('<div class="invalid-feedback">' + response.errors.senha + '</div>');
                    }
                }
            },
            error: function() {
                submitBtn.prop('disabled', false).html(originalText);
                alert('Erro ao comunicar com o servidor.');
            }
        });
    });
});
</script>