<?php
include '../../conexao.php';

$categoria_id = intval($_POST['categoria_id']);
$categoria_nome = $_POST['categoria_nome'];
?>
<div class="modal-header">
    <h5 class="modal-title">Avaliar Casa de Aposta - <?= htmlspecialchars($categoria_nome) ?></h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <h4 class="text-center mb-4">Selecione a casa de apostas</h4>
    <div class="row">
        <?php
        $bets = $conn->query("SELECT * FROM bets WHERE ativo = 1 ORDER BY nome");
        while ($bet = $bets->fetch_assoc()):
        ?>
        <div class="col-md-6 mb-4">
            <div class="bet-card card h-100 p-3" 
                 data-bet-id="<?= $bet['id'] ?>" 
                 data-bet-nome="<?= htmlspecialchars($bet['nome']) ?>">
                <div class="row g-0">
                    <div class="col-md-4 d-flex align-items-center">
                        <img src="uploads/logos/<?= $bet['logo'] ?>" class="img-fluid rounded-start" alt="<?= htmlspecialchars($bet['nome']) ?>">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($bet['nome']) ?></h5>
                            <p class="card-text"><small class="text-muted"><?= htmlspecialchars($bet['descricao_curta']) ?></small></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>