<?php
session_start();
$bet_id = $_POST['bet_id'] ?? '';
$bet_nome = $_POST['bet_nome'] ?? '';
$anonimo = !isset($_POST['logado']); // Se veio do botão logado, não é anônimo
$usuarioLogado = isset($_SESSION['usuario_id']);
?>

<div class="modal-step active">
    <div class="modal-header">
        <h5 class="modal-title">Avaliar <?= htmlspecialchars($bet_nome) ?></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
        <?php if ($anonimo): ?>
            <div class="alert alert-info mb-4">
                <i class="fas fa-user-secret me-2"></i> Você está avaliando como anônimo
            </div>
        <?php else: ?>
            <div class="alert alert-success mb-4">
                <i class="fas fa-user-check me-2"></i> Avaliando como: <strong><?= htmlspecialchars($_SESSION['usuario_nome']) ?></strong>
            </div>
        <?php endif; ?>
        
        <form id="formAvaliacao">
            <input type="hidden" name="bet_id" value="<?= $bet_id ?>">
            <input type="hidden" name="anonimo" value="<?= $anonimo ? 1 : 0 ?>">
            <?php if (!$anonimo): ?>
                <input type="hidden" name="usuario_id" value="<?= $_SESSION['usuario_id'] ?>">
            <?php endif; ?>
            
            <div class="mb-3">
                <label class="form-label">Nota (1-5)</label>
                <div class="rating-stars">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <i class="fas fa-star star-rating" data-value="<?= $i ?>"></i>
                    <?php endfor; ?>
                    <input type="hidden" name="nota" id="rating-value">
                </div>
            </div>
            
            <div class="mb-3">
                <label for="comentario" class="form-label">Comentário</label>
                <textarea class="form-control" id="comentario" name="comentario" rows="3"></textarea>
            </div>
            
            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary">Enviar Avaliação</button>
                <button type="button" class="btn btn-outline-secondary" data-prev-step="escolha-login">
                    Voltar
                </button>
            </div>
        </form>
    </div>
</div>