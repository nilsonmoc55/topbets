<?php
include '../../conexao.php';

$bet_id = intval($_POST['bet_id']);
$bet_nome = $_POST['bet_nome'];
?>
<div class="modal-header">
    <h5 class="modal-title">Avaliar <?= htmlspecialchars($bet_nome) ?></h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body text-center">
    <h4>Qual tipo de experiência você deseja avaliar?</h4>
    <div class="row mt-4">
        <?php
        $categorias = $conn->query("SELECT * FROM categorias_avaliacao");
        while ($cat = $categorias->fetch_assoc()):
        ?>
        <div class="col-md-4 mb-4">
            <div class="categoria-card card h-100 p-3" 
                 data-categoria-id="<?= $cat['id'] ?>" 
                 data-categoria-nome="<?= htmlspecialchars($cat['nome']) ?>"
                 onclick="selecionarCategoria(<?= $cat['id'] ?>, '<?= htmlspecialchars($cat['nome']) ?>')">
                <div class="card-body text-center">
                    <i class="<?= $cat['icone'] ?> fa-3x mb-3"></i>
                    <h5><?= htmlspecialchars($cat['nome']) ?></h5>
                    <p class="text-muted small"><?= htmlspecialchars($cat['descricao']) ?></p>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

<script>
function selecionarCategoria(categoriaId, categoriaNome) {
    // Redireciona para a página de formulário de avaliação
    window.location.href = `formulario-avaliacao.php?bet_id=<?= $bet_id ?>&bet_nome=<?= urlencode($bet_nome) ?>&categoria_id=${categoriaId}&categoria_nome=${encodeURIComponent(categoriaNome)}`;
}
</script>