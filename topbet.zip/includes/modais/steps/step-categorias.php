<?php
include '../../conexao.php';

// Verifica se há categorias
$categorias = $conn->query("SELECT * FROM categorias WHERE ativo = 1 ORDER BY nome");

if ($categorias->num_rows === 0) {
    // Se não houver categorias, insere as padrão
    $conn->query("INSERT INTO categorias (nome, icone, ativo) VALUES
        ('Cassino', 'fas fa-dice', 1),
        ('Esportes', 'fas fa-football-ball', 1),
        ('Slots', 'fas fa-sliders-h', 1),
        ('Cassino ao vivo', 'fas fa-video', 1),
        ('Poker', 'fas fa-spade', 1)");
    
    // Busca novamente
    $categorias = $conn->query("SELECT * FROM categorias WHERE ativo = 1 ORDER BY nome");
}
?>

<div class="modal-header bg-primary text-white">
    <h5 class="modal-title">Selecione a Categoria</h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
    <?php if ($categorias->num_rows > 0): ?>
        <div class="row row-cols-2 row-cols-md-3 g-4">
            <?php while($cat = $categorias->fetch_assoc()): ?>
            <div class="col">
                <div class="card h-100 border-0 shadow-sm categoria-card"
                     data-categoria-id="<?= $cat['id'] ?>"
                     data-categoria-nome="<?= htmlspecialchars($cat['nome']) ?>">
                    <div class="card-body text-center py-4">
                        <?php if(!empty($cat['icone'])): ?>
                        <i class="<?= htmlspecialchars($cat['icone']) ?> fa-3x mb-3 text-primary"></i>
                        <?php endif; ?>
                        <h5><?= htmlspecialchars($cat['nome']) ?></h5>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-warning text-center">
            Nenhuma categoria disponível no momento.
        </div>
    <?php endif; ?>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-outline-secondary" data-prev-step="inicio">
        <i class="fas fa-arrow-left me-2"></i> Voltar
    </button>
</div>