<?php
include 'conexao.php';

header('Content-Type: application/json');

if (!isset($_GET['bet_id'])) {
    echo json_encode(['success' => false, 'message' => 'ID da casa de apostas não especificado']);
    exit;
}

$bet_id = intval($_GET['bet_id']);

// Busca informações da bet
$sql_bet = "SELECT nome FROM bets WHERE id = $bet_id";
$result = $conn->query($sql_bet);

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Casa de apostas não encontrada']);
    exit;
}

$bet = $result->fetch_assoc();

// Gera o formulário de avaliação
ob_start();
?>
<form id="formAvaliacaoCompleta" action="includes/salvar_avaliacao.php" method="post">
    <input type="hidden" name="bet_id" value="<?= $bet_id ?>">
    
    <div class="row mb-3">
        <div class="col-md-6">
            <label for="avaliador_nome" class="form-label">Seu Nome</label>
            <input type="text" class="form-control" id="avaliador_nome" name="nome" required>
        </div>
        <div class="col-md-6">
            <label for="avaliador_email" class="form-label">Seu E-mail</label>
            <input type="email" class="form-control" id="avaliador_email" name="email" required>
        </div>
    </div>
    
    <div class="mb-3">
        <label class="form-label">Nota Geral</label>
        <div class="rating-stars mb-3">
            <?php for ($i = 10; $i >= 1; $i--): ?>
                <input type="radio" id="avaliacao_star<?= $i ?>" name="nota" value="<?= $i ?>" <?= $i === 8 ? 'checked' : '' ?>>
                <label for="avaliacao_star<?= $i ?>"><?= $i ?></label>
            <?php endfor; ?>
        </div>
    </div>
    
    <div class="mb-3">
        <label for="avaliacao_bonus" class="form-label">Bônus Recebido (opcional)</label>
        <input type="number" class="form-control" id="avaliacao_bonus" name="bonus" placeholder="R$ 0,00" step="0.01" min="0">
    </div>
    
    <div class="mb-3">
        <label for="avaliacao_comentario" class="form-label">Sua Experiência</label>
        <textarea class="form-control" id="avaliacao_comentario" name="comentario" rows="4" required placeholder="Conte detalhes sobre sua experiência..."></textarea>
    </div>
    
    <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" id="avaliacao_termos" name="termos" required>
        <label class="form-check-label" for="avaliacao_termos">Declaro que esta avaliação é baseada em minha experiência real</label>
    </div>
    
    <div class="d-grid">
        <button type="submit" class="btn btn-primary btn-lg">Enviar Avaliação</button>
    </div>
</form>

<script>
// Validação e envio do formulário
$('#formAvaliacaoCompleta').submit(function(e) {
    e.preventDefault();
    
    // Mostrar loading
    $('#conteudo-avaliacao').html(`
        <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Enviando...</span>
        </div>
        <p>Enviando sua avaliação...</p>
    `);
    
    $.ajax({
        url: $(this).attr('action'),
        type: 'POST',
        data: $(this).serialize(),
        success: function(response) {
            if (response.success) {
                $('#conteudo-avaliacao').html(`
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i>
                        ${response.message || 'Avaliação enviada com sucesso!'}
                    </div>
                    <button class="btn btn-primary" onclick="location.reload()">
                        Fechar
                    </button>
                `);
            } else {
                $('#conteudo-avaliacao').html(`
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        ${response.message || 'Erro ao enviar avaliação'}
                    </div>
                    <button class="btn btn-secondary" onclick="$('#modalAvaliacaoCompleta').modal('hide'); $('#modalSelecionarBet').modal('show');">
                        Voltar
                    </button>
                `);
            }
        },
        error: function() {
            $('#conteudo-avaliacao').html(`
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle me-2"></i>
                    Erro na comunicação com o servidor
                </div>
                <button class="btn btn-secondary" onclick="$('#modalAvaliacaoCompleta').modal('hide'); $('#modalSelecionarBet').modal('show');">
                    Voltar
                </button>
            `);
        }
    });
});
</script>
<?php
$form = ob_get_clean();

echo json_encode([
    'success' => true,
    'bet_nome' => $bet['nome'],
    'form' => $form
]);

$conn->close();
?>