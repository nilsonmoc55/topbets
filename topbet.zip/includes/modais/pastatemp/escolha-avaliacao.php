<!-- Modal de Escolha de Avaliação -->
<div class="modal fade" id="modalEscolhaAvaliacao" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Como deseja avaliar?</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <?php if($usuarioLogado): ?>
                    <button type="button" class="btn btn-outline-primary w-100 mb-2 btn-continuar-avaliacao" data-tipo="logado">
                        <i class="fas fa-user me-2"></i> Como <?= htmlspecialchars($_SESSION['usuario_nome']) ?>
                    </button>
                <?php endif; ?>
                
                <button type="button" class="btn btn-outline-secondary w-100 mb-2 btn-continuar-avaliacao" data-tipo="anonimo">
                    <i class="fas fa-user-secret me-2"></i> Anonimamente
                </button>
                
                <?php if(!$usuarioLogado): ?>
                    <div class="divider">
                        <span class="divider-text">OU</span>
                    </div>
                    <button type="button" class="btn btn-primary w-100 btn-continuar-avaliacao" data-tipo="login">
                        <i class="fas fa-sign-in-alt me-2"></i> Fazer Login
                    </button>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>