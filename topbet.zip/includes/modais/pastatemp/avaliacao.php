<div class="modal fade" id="modalAvaliacao" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Avaliar Casa de Aposta</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Passo 1: Seleção de Categoria -->
                <div id="passo-categorias">
                    <h6 class="mb-3">Selecione o tipo de aposta:</h6>
                    <div class="row g-2">
                        <div class="col-6 col-md-3">
                            <button class="btn btn-outline-primary w-100 py-3 categoria-btn" data-categoria="esportiva">
                                <i class="fas fa-running fa-2x mb-2"></i><br>
                                Esportes
                            </button>
                        </div>
                        <div class="col-6 col-md-3">
                            <button class="btn btn-outline-danger w-100 py-3 categoria-btn" data-categoria="cassino">
                                <i class="fas fa-dice fa-2x mb-2"></i><br>
                                Cassino
                            </button>
                        </div>
                        <div class="col-6 col-md-3">
                            <button class="btn btn-outline-warning w-100 py-3 categoria-btn" data-categoria="slots">
                                <i class="fas fa-sliders-h fa-2x mb-2"></i><br>
                                Slots
                            </button>
                        </div>
                        <div class="col-6 col-md-3">
                            <button class="btn btn-outline-success w-100 py-3 categoria-btn" data-categoria="poker">
                                <i class="fas fa-spade fa-2x mb-2"></i><br>
                                Poker
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Passo 2: Lista de Bets -->
                <div id="passo-bets" class="mt-4 d-none">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <button class="btn btn-sm btn-outline-secondary voltar-categorias">
                            <i class="fas fa-arrow-left me-1"></i> Voltar
                        </button>
                        <h6 class="mb-0" id="categoria-selecionada-titulo"></h6>
                    </div>
                    
                    <div class="input-group mb-3">
                        <input type="text" id="busca-bets-input" class="form-control" placeholder="Buscar casa...">
                        <button class="btn btn-primary" type="button" id="buscar-bets-btn">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                    
                    <div id="lista-bets" class="list-group" style="max-height: 300px; overflow-y: auto;">
                        <!-- Bets serão carregadas aqui via AJAX -->
                    </div>
                </div>

                <!-- Passo 3: Formulário de Avaliação -->
                <div id="passo-formulario" class="d-none">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <button class="btn btn-sm btn-outline-secondary voltar-bets">
                            <i class="fas fa-arrow-left me-1"></i> Voltar
                        </button>
                        <h6 class="mb-0" id="bet-selecionada-titulo"></h6>
                    </div>
                    
                    <div id="conteudo-formulario">
                        <!-- Formulário será carregado aqui via AJAX -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>