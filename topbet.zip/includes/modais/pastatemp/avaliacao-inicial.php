<div class="modal fade" id="modalAvaliarInicial" tabindex="-1" aria-labelledby="modalAvaliarInicialLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="modalAvaliarInicialLabel">Avaliar Casa de Aposta</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="formSelecionarCategoria">
                    <div class="mb-4 text-center">
                        <h4>O que você deseja avaliar?</h4>
                        <p class="text-muted">Selecione a categoria da casa de apostas</p>
                    </div>
                    
                    <div class="row g-3">
                        <div class="col-6">
                            <input type="radio" class="btn-check" name="categoria" id="cassino" value="cassino" autocomplete="off">
                            <label class="btn btn-outline-primary w-100 py-3" for="cassino">
                                <i class="fas fa-dice fa-2x mb-2"></i><br>
                                Cassino Físico
                            </label>
                        </div>
                        
                        <div class="col-6">
                            <input type="radio" class="btn-check" name="categoria" id="esportiva" value="esportiva" autocomplete="off">
                            <label class="btn btn-outline-primary w-100 py-3" for="esportiva">
                                <i class="fas fa-trophy fa-2x mb-2"></i><br>
                                Aposta Esportiva
                            </label>
                        </div>
                        
                        <div class="col-6">
                            <input type="radio" class="btn-check" name="categoria" id="cassino_online" value="cassino_online" autocomplete="off">
                            <label class="btn btn-outline-primary w-100 py-3" for="cassino_online">
                                <i class="fas fa-laptop fa-2x mb-2"></i><br>
                                Cassino Online
                            </label>
                        </div>
                        
                        <div class="col-6">
                            <input type="radio" class="btn-check" name="categoria" id="poker" value="poker" autocomplete="off">
                            <label class="btn btn-outline-primary w-100 py-3" for="poker">
                                <i class="fas fa-spade fa-2x mb-2"></i><br>
                                Poker
                            </label>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" id="btnProximoCategoria" class="btn btn-primary" disabled>Próximo</button>
            </div>
        </div>
    </div>
</div>