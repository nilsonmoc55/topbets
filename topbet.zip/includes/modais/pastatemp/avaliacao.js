// Função para navegar entre modais
function abrirProximoModal(modalAtual, proximoModal) {
    const currentModal = bootstrap.Modal.getInstance(document.querySelector(modalAtual));
    currentModal.hide();
    
    const nextModal = new bootstrap.Modal(document.querySelector(proximoModal));
    nextModal.show();
}

// Inicializa o modal inicial quando clica no botão
document.addEventListener('DOMContentLoaded', function() {
    const btnAvaliar = document.querySelector('[data-bs-target="#modalAvaliacaoInicial"]');
    if(btnAvaliar) {
        btnAvaliar.addEventListener('click', function() {
            new bootstrap.Modal(document.getElementById('modalAvaliacaoInicial')).show();
        });
    }
});

// Placeholder para função de enviar avaliação (implementada no modal-form-avaliacao.php)
function enviarAvaliacao() {
    // Implementação está no próprio modal
}