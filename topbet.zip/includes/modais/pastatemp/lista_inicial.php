<div class="modal fade" id="listaInicialModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Selecione uma Casa de Aposta</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Buscador -->
                <div class="row mb-4">
                    <div class="col-md-6 mx-auto">
                        <div class="input-group">
                            <input type="text" id="searchBetsModal" class="form-control" placeholder="Buscar casa de apostas...">
                            <button class="btn btn-primary" id="btnSearchModal">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Lista em 2 colunas -->
                <div class="row" id="betsContainerModal">
                    <?php 
                    $sql_bets = "SELECT id, nome, logo FROM bets WHERE ativo = 1 ORDER BY nome ASC";
                    $result = $conn->query($sql_bets);
                    
                    while ($bet = $result->fetch_assoc()): 
                        $logo = !empty($bet['logo']) ? "img/logos/{$bet['logo']}" : "img/logos/padrao.png";
                    ?>
                    <div class="col-md-6 mb-4 bet-item-modal">
                        <div class="card h-100 cursor-pointer" onclick="selecionarBet(<?= $bet['id'] ?>, '<?= htmlspecialchars($bet['nome']) ?>')">
                            <div class="row g-0">
                                <div class="col-md-4 d-flex align-items-center p-3">
                                    <img src="<?= $logo ?>" class="img-fluid rounded-start" alt="<?= $bet['nome'] ?>">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title"><?= $bet['nome'] ?></h5>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="badge bg-primary">Clique para selecionar</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function selecionarBet(betId, betName) {
    $('#listaInicialModal').modal('hide');
    $('#betNameTitle').text(betName);
    $('#modalVerificaLogin').modal('show');
    
    // Armazena o ID da bet selecionada em um elemento oculto
    $('#hiddenBetId').val(betId);
}
</script>