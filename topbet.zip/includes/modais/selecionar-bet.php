<?php
include 'conexao.php';

header('Content-Type: application/json');

if (!isset($_GET['categoria'])) {
    echo json_encode(['success' => false, 'message' => 'Categoria não especificada']);
    exit;
}

$categoria = $conn->real_escape_string($_GET['categoria']);

// Mapeia categorias para tipos no banco de dados (ajuste conforme sua estrutura)
$tipos = [
    'cassino' => 'Cassino Físico',
    'esportiva' => 'Aposta Esportiva',
    'cassino_online' => 'Cassino Online',
    'poker' => 'Poker',
    'slots' => 'Slots',
    'outros' => 'Outros'
];

$tipo = $tipos[$categoria] ?? '';

$sql = "SELECT id, nome FROM bets WHERE ativo = 1 AND tipo LIKE '%$tipo%' ORDER BY nome";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $bets = [];
    while ($row = $result->fetch_assoc()) {
        $bets[] = $row;
    }
    echo json_encode(['success' => true, 'data' => $bets]);
} else {
    echo json_encode(['success' => false, 'message' => 'Nenhuma casa encontrada nesta categoria']);
}

$conn->close();
?>