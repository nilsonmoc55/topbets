<?php
$bet_id = intval($_GET['bet_id']);
$categoria_id = intval($_GET['categoria_id']);

// Busca dados
$bet = $conn->query("SELECT * FROM bets WHERE id = $bet_id")->fetch_assoc();
$categoria = $conn->query("SELECT * FROM categorias WHERE id = $categoria_id")->fetch_assoc();

// Campos dinâmicos por categoria
$campos = [
    1 => [ // Esportes
        ['tipo' => 'range', 'pergunta' => 'Odds Competitivas', 'nome' => 'odds', 'min' => 1, 'max' => 5],
        ['tipo' => 'range', 'pergunta' => 'Variedade de Esportes', 'nome' => 'variedade_esportes', 'min' => 1, 'max' => 5],
        ['tipo' => 'range', 'pergunta' => 'Live Betting', 'nome' => 'live_betting', 'min' => 1, 'max' => 5],
        ['tipo' => 'textarea', 'pergunta' => 'Comentários sobre Esportes', 'nome' => 'comentarios_esportes']
    ],
    2 => [ // Cassino
        ['tipo' => 'range', 'pergunta' => 'Variedade de Jogos', 'nome' => 'variedade_jogos', 'min' => 1, 'max' => 5],
        ['tipo' => 'range', 'pergunta' => 'Bônus de Cassino', 'nome' => 'bonus_cassino', 'min' => 1, 'max' => 5],
        ['tipo' => 'range', 'pergunta' => 'Jogos ao Vivo', 'nome' => 'jogos_vivo', 'min' => 1, 'max' => 5],
        ['tipo' => 'textarea', 'pergunta' => 'Comentários sobre Cassino', 'nome' => 'comentarios_cassino']
    ]
];

$campos_categoria = $campos[$categoria_id] ?? [];
?>
<div class="modal fade" id="modalFormAvaliacao" tabindex="-1" aria-labelledby="formAvaliacaoLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="formAvaliacaoLabel">Avaliar <?= htmlspecialchars($bet['nome']) ?></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="d-flex align-items-center mb-4">
                    <?php if(!empty($bet['logo'])): ?>
                    <img src="uploads/logos/<?= htmlspecialchars($bet['logo']) ?>" class="rounded me-3" style="width: 50px; height: 50px; object-fit: contain;" alt="<?= htmlspecialchars($bet['nome']) ?>">
                    <?php endif; ?>
                    <div>
                        <h6 class="mb-0"><?= htmlspecialchars($bet['nome']) ?></h6>
                        <small class="text-muted"><?= htmlspecialchars($categoria['nome']) ?></small>
                    </div>
                </div>

                <form id="formAvaliacao">
                    <input type="hidden" name="bet_id" value="<?= $bet_id ?>">
                    <input type="hidden" name="categoria_id" value="<?= $categoria_id ?>">
                    
                    <?php foreach($campos_categoria as $campo): ?>
                    <div class="mb-4 campo-avaliacao">
                        <label class="form-label"><?= $campo['pergunta'] ?></label>
                        
                        <?php if($campo['tipo'] === 'range'): ?>
                        <div class="d-flex align-items-center">
                            <span class="me-2 text-muted"><?= $campo['min'] ?></span>
                            <input type="range" class="form-range" name="<?= $campo['nome'] ?>" 
                                   min="<?= $campo['min'] ?>" max="<?= $campo['max'] ?>" 
                                   oninput="document.getElementById('valor-<?= $campo['nome'] ?>').innerText = this.value">
                            <span class="ms-2 text-muted"><?= $campo['max'] ?></span>
                            <span class="ms-2 fw-bold" id="valor-<?= $campo['nome'] ?>">3</span>
                        </div>
                        
                        <?php elseif($campo['tipo'] === 'textarea'): ?>
                        <textarea class="form-control" name="<?= $campo['nome'] ?>" rows="2"></textarea>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                    
                    <div class="mb-3">
                        <label class="form-label">Nota Geral (1-5)</label>
                        <div class="rating-stars">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                            <i class="fas fa-star star-rating" data-value="<?= $i ?>"></i>
                            <?php endfor; ?>
                            <input type="hidden" name="nota_geral" id="notaGeral" value="3">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" onclick="abrirProximoModal('#modalFormAvaliacao', '#modalSelecionarCasa')">
                    <i class="fas fa-arrow-left me-2"></i> Voltar
                </button>
                <button type="button" class="btn btn-primary" onclick="enviarAvaliacao()">
                    Enviar Avaliação <i class="fas fa-check ms-2"></i>
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// Estrelas de avaliação
document.querySelectorAll('.star-rating').forEach(star => {
    star.addEventListener('click', function() {
        const value = parseInt(this.getAttribute('data-value'));
        document.getElementById('notaGeral').value = value;
        
        document.querySelectorAll('.star-rating').forEach(s => {
            s.classList.toggle('text-warning', parseInt(s.getAttribute('data-value')) <= value);
        });
    });
});

function enviarAvaliacao() {
    const formData = new FormData(document.getElementById('formAvaliacao'));
    
    $.ajax({
        url: 'processa-avaliacao.php',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(response) {
            abrirProximoModal('#modalFormAvaliacao', '#modalConfirmacaoAvaliacao');
        }
    });
}
</script>

<style>
.rating-stars {
    font-size: 24px;
    cursor: pointer;
}
.star-rating {
    color: #ddd;
    transition: color 0.2s;
}
.star-rating.text-warning {
    color: #ffc107;
}
</style>