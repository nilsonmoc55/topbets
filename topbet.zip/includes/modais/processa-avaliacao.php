<?php
include 'conexao.php';
session_start();

if(!isset($_SESSION['usuario_id'])) {
    die(json_encode(['status' => 'error', 'message' => 'Usuário não logado']));
}

$bet_id = intval($_POST['bet_id']);
$categoria_id = intval($_POST['categoria_id']);
$nota_geral = intval($_POST['nota_geral']);

// Insere a avaliação principal
$sql = "INSERT INTO avaliacoes 
        (bet_id, usuario_id, nota, bonus, categoria_id, data_avaliacao) 
        VALUES (?, ?, ?, 0, ?, NOW())";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iiii", $bet_id, $_SESSION['usuario_id'], $nota_geral, $categoria_id);
$stmt->execute();
$avaliacao_id = $stmt->insert_id;

// Insere os detalhes específicos da categoria
$detalhes = [];
foreach($_POST as $key => $value) {
    if($key !== 'bet_id' && $key !== 'categoria_id' && $key !== 'nota_geral') {
        $detalhes[$key] = $conn->real_escape_string($value);
    }
}

if(!empty($detalhes)) {
    $sql_detalhes = "INSERT INTO avaliacao_detalhes 
                    (avaliacao_id, campo, valor) 
                    VALUES " . implode(',', array_map(function($k, $v) use ($avaliacao_id) {
                        return "($avaliacao_id, '$k', '$v')";
                    }, array_keys($detalhes), $detalhes));
    
    $conn->query($sql_detalhes);
}

// Atualiza média da casa de apostas
$conn->query("
    UPDATE bets b
    SET media_nota = (
        SELECT COALESCE(AVG(nota), 0) 
        FROM avaliacoes 
        WHERE bet_id = b.id
    )
    WHERE id = $bet_id
");

echo json_encode(['status' => 'success']);
?>