<div class="modal fade" id="modalFormAvaliacao" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Avaliar <span id="nomeBetAvaliacao"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="formAvaliacao">
                    <input type="hidden" id="betId" name="bet_id">
                    <input type="hidden" id="avaliacaoAnonima" name="anonimo" value="0">
                    
                    <div class="mb-4">
                        <label class="form-label">Nota (0-5)</label>
                        <div class="rating-stars">
                            <?php for($i=1; $i<=5; $i++): ?>
                                <i class="fas fa-star star-rating" data-value="<?= $i ?>"></i>
                            <?php endfor; ?>
                        </div>
                        <input type="hidden" id="notaAvaliacao" name="nota" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="comentario" class="form-label">Comentário</label>
                        <textarea class="form-control" id="comentario" name="comentario" rows="4"></textarea>
                    </div>
                    
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="receberBonus" name="receber_bonus">
                        <label class="form-check-label" for="receberBonus">Receber bônus desta casa</label>
                    </div>
                    
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-paper-plane me-2"></i>Enviar Avaliação
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>