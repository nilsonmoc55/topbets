<?php
// Arquivo principal que inclui todos os modais
require_once 'conexao.php';
session_start();
$usuarioLogado = isset($_SESSION['usuario_id']);
?>

<!-- Modal Inicial de Sele��o de Categoria -->
<?php include 'modais/avaliacao-inicial.php'; ?>

<!-- Modal de Sele��o de Bet (ser� chamado via JS) -->
<?php include 'modais/selecionar-bet.php'; ?>

<!-- Modal de Formul�rio Completo (ser� chamado via JS) -->
<?php include 'modais/formulario-avaliacao.php'; ?>

<!-- Outros modais existentes -->
<?php include 'modais/login.php'; ?>
<?php include 'modais/cadastro.php'; ?>
<?php include 'modais/recuperar-senha.php'; ?>

<script src="js/modais-avaliacao.js"></script>