<div class="modal fade" id="modalAvaliarBet" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Selecione a Casa para Avaliar</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <?php
                    // Busca TODAS as bets ativas
                    $sql_bets = "SELECT id, nome, logo FROM bets WHERE ativo = 1 ORDER BY nome ASC";
                    $result = $conn->query($sql_bets);
                    
                    while ($bet = $result->fetch_assoc()):
                        $logo = !empty($bet['logo']) ? "img/logos/{$bet['logo']}" : "img/logos/padrao.png";
                    ?>
                    <div class="col-md-3 col-6 mb-3 text-center">
                        <a href="avaliar.php?bet_id=<?= $bet['id'] ?>" class="text-decoration-none">
                            <img src="<?= $logo ?>" alt="<?= $bet['nome'] ?>" class="img-fluid mb-2" style="max-height: 60px;">
                            <div class="small"><?= $bet['nome'] ?></div>
                        </a>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>