<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

function enviarEmailRecuperacao($emailDestino, $nomeDestino, $token) {
    $mail = new PHPMailer(true);
    
    try {
        // Configurações do servidor
        $mail->isSMTP();
        $mail->Host = 'mail.infinityfree.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'seu_email@seusite.com'; // Seu e-mail no InfinityFree
        $mail->Password = 'sua_senha'; // Sua senha
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;
        
        // Remetente e destinatário
        $mail->setFrom('no-reply@seusite.com', 'TopBets');
        $mail->addAddress($emailDestino, $nomeDestino);
        
        // Conteúdo do e-mail
        $mail->isHTML(true);
        $mail->Subject = 'Recuperação de Senha - TopBets';
        
        $link = "https://seusite.com/redefinir_senha.php?token=$token";
        $mail->Body = "..."; // Mesmo conteúdo HTML do exemplo anterior
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Erro ao enviar e-mail: {$mail->ErrorInfo}");
        return false;
    }
}