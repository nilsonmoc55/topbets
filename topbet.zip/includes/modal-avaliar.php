<div class="modal fade" id="avaliarBetModal" tabindex="-1" aria-labelledby="avaliarBetModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="avaliarBetModalLabel">Avaliar Casa de Aposta</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-4">
                    <input type="text" id="buscaBet" class="form-control form-control-lg" placeholder="Buscar casa de aposta...">
                </div>
                
                <div class="row" id="listaBets">
                    <?php
                    // Busca todas as bets ativas ordenadas por nome
                    $sql = "SELECT id, nome, logo FROM bets WHERE ativo = 1 ORDER BY nome";
                    $result = $conn->query($sql);
                    
                    while($bet = $result->fetch_assoc()):
                        $logo = !empty($bet['logo']) ? $bet['logo'] : 'img/logos/default.png';
                    ?>
                    <div class="col-md-6 mb-3 bet-item">
                        <button class="btn btn-outline-primary w-100 text-start bet-select" 
                                data-bet-id="<?= $bet['id'] ?>"
                                data-bet-name="<?= htmlspecialchars($bet['nome']) ?>">
                            <div class="d-flex align-items-center">
                                <img src="<?= $logo ?>" alt="<?= htmlspecialchars($bet['nome']) ?>" 
                                     class="img-thumbnail me-3" style="width: 50px; height: 50px; object-fit: contain;">
                                <span><?= htmlspecialchars($bet['nome']) ?></span>
                            </div>
                        </button>
                    </div>
                    <?php endwhile; ?>
                </div>
                
                <div id="semResultados" class="text-center py-4 d-none">
                    <i class="fas fa-search fa-3x text-muted mb-3"></i>
                    <p class="text-muted">Nenhuma casa de aposta encontrada</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>