<?php
// Inicia a sessão e inclui a conexão
require 'includes/conexao.php';

// Verifica se o ID da bet foi passado
$bet_id = isset($_GET['bet_id']) ? intval($_GET['bet_id']) : 0;

if ($bet_id <= 0) {
    header("Location: index.php");
    exit();
}

// Busca dados da bet
$sql_bet = "SELECT id, nome, logo, url FROM bets WHERE id = ? AND ativo = 1";
$stmt_bet = $conn->prepare($sql_bet);
$stmt_bet->bind_param("i", $bet_id);
$stmt_bet->execute();
$result_bet = $stmt_bet->get_result();
$bet = $result_bet->fetch_assoc();

if (!$bet) {
    header("Location: index.php");
    exit();
}

// Busca avaliações (apenas moderadas)
$sql_avaliacoes = "SELECT a.*, u.nome as usuario_nome 
                   FROM avaliacoes a
                   LEFT JOIN usuarios u ON a.usuario_id = u.id
                   WHERE a.bet_id = ? AND a.moderado = 1
                   ORDER BY a.data_avaliacao DESC";
$stmt_avaliacoes = $conn->prepare($sql_avaliacoes);
$stmt_avaliacoes->bind_param("i", $bet_id);
$stmt_avaliacoes->execute();
$avaliacoes = $stmt_avaliacoes->get_result();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Avaliações - <?= htmlspecialchars($bet['nome']) ?> | TopBets</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- CSS Personalizado -->
    <link rel="stylesheet" href="/css/estilo.css">
</head>
<body>
    <?php include 'includes/header.php'; // Corrigido para header.php ?>

    <main class="container py-4">
        <div class="row">
            <div class="col-md-8">
                <div class="d-flex align-items-center mb-4">
                    <img src="<?= htmlspecialchars($bet['logo'] ?? 'img/logos/default.png') ?>" 
                         alt="<?= htmlspecialchars($bet['nome']) ?>" 
                         class="img-fluid rounded me-3" style="max-height: 80px;">
                    <div>
                        <h1><?= htmlspecialchars($bet['nome']) ?></h1>
                        <a href="<?= htmlspecialchars($bet['url']) ?>" target="_blank" class="text-decoration-none">
                            <i class="fas fa-external-link-alt"></i> Visitar site oficial
                        </a>
                    </div>
                </div>

                <h3 class="mb-3"><i class="fas fa-comments me-2"></i>Avaliações</h3>

                <?php if ($avaliacoes->num_rows > 0): ?>
                    <?php while ($avaliacao = $avaliacoes->fetch_assoc()): ?>
                        <div class="card mb-3">
                            <div class="card-body">
                                <div class="d-flex justify-content-between mb-2">
                                    <h5 class="mb-0">
                                        <?= htmlspecialchars($avaliacao['usuario_nome'] ?? 'Anônimo') ?>
                                    </h5>
                                    <small class="text-muted">
                                        <?= date('d/m/Y H:i', strtotime($avaliacao['data_avaliacao'])) ?>
                                    </small>
                                </div>
                                
                                <div class="mb-2 text-warning">
                                    <?= str_repeat('<i class="fas fa-star"></i>', round($avaliacao['nota'])) ?>
                                    <?= str_repeat('<i class="far fa-star"></i>', 5 - round($avaliacao['nota'])) ?>
                                    <span class="text-dark ms-2"><?= number_format($avaliacao['nota'], 1) ?>/5.0</span>
                                </div>
                                
                                <?php if (!empty($avaliacao['comentario_geral'])): ?>
                                    <p class="card-text"><?= nl2br(htmlspecialchars($avaliacao['comentario_geral'])) ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="alert alert-info">
                        Nenhuma avaliação aprovada ainda para esta casa de apostas.
                    </div>
                <?php endif; ?>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>Informações</h5>
                    </div>
                    <div class="card-body">
                        <a href="<?= htmlspecialchars($bet['url']) ?>" target="_blank" class="btn btn-outline-primary w-100 mb-3">
                            <i class="fas fa-external-link-alt me-1"></i> Visitar Site
                        </a>
                        
                        <?php if (isset($_SESSION['usuario_id'])): ?>
                            <button class="btn btn-success w-100 mb-3" data-bs-toggle="modal" data-bs-target="#modalAvaliar">
                                <i class="fas fa-edit me-1"></i> Avaliar
                            </button>
                        <?php else: ?>
                            <button class="btn btn-success w-100 mb-3" data-bs-toggle="modal" data-bs-target="#loginModal">
                                <i class="fas fa-sign-in-alt me-1"></i> Login para Avaliar
                            </button>
                        <?php endif; ?>
                        
                        <a href="index.php" class="btn btn-outline-secondary w-100">
                            <i class="fas fa-arrow-left me-1"></i> Voltar
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>