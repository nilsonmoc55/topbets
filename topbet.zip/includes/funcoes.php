<?php
// includes/funcoes.php

function sanitizar($dados) {
    if (is_array($dados)) {
        return array_map('sanitizar', $dados);
    }
    return htmlspecialchars(trim($dados), ENT_QUOTES, 'UTF-8');
}

function estaLogado() {
    return isset($_SESSION['usuario_id']);
}

function redirecionar($url) {
    header("Location: $url");
    exit();
}

function gerarToken() {
    return bin2hex(random_bytes(32));
}