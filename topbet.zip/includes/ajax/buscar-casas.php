<?php
require_once __DIR__ . '/../../includes/conexao.php';

header('Content-Type: text/html; charset=utf-8');

$termo = $_GET['termo'] ?? '';
$categoriaFront = $_GET['categoria'] ?? 'esportiva';

// Mapeamento completo e seguro das categorias
$mapeamentoCategorias = [
    'esportiva' => 'esportes',
    'cassino' => 'casino',
    'slots' => 'slots',
    'poker' => 'poker'
];

if (!array_key_exists($categoriaFront, $mapeamentoCategorias)) {
    die(json_encode(['error' => 'Categoria inválida']));
}

$categoriaBanco = $mapeamentoCategorias[$categoriaFront];

try {
    // Verifica se a coluna categoria existe
    $colunaExiste = $conn->query("SHOW COLUMNS FROM bets LIKE 'categoria'")->num_rows > 0;

    $sql = "SELECT id, nome, logo FROM bets WHERE ativo = 1 ";
    $params = [];
    $types = '';
    
    if ($colunaExiste) {
        $sql .= "AND categoria = ? ";
        $params[] = $categoriaBanco;
        $types .= 's';
    }
    
    $sql .= "AND (nome LIKE CONCAT('%', ?, '%') OR ? = '') ORDER BY nome ASC";
    $params[] = $termo;
    $params[] = $termo;
    $types .= 'ss';

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo '<div class="list-group">';
        while ($casa = $result->fetch_assoc()) {
            $logo = !empty($casa['logo']) ? $casa['logo'] : 'img/logos/default.png';
            echo '<button type="button" class="list-group-item list-group-item-action d-flex align-items-center casa-item"
                    data-id="'.$casa['id'].'" 
                    data-nome="'.htmlspecialchars($casa['nome']).'"
                    data-categoria="'.$categoriaFront.'">
                    <img src="'.htmlspecialchars($logo).'" class="me-3 rounded" style="width:50px;height:50px;object-fit:cover;">
                    <div>
                        <h6 class="mb-0">'.htmlspecialchars($casa['nome']).'</h6>
                        <small class="text-muted">Clique para avaliar</small>
                    </div>
                  </button>';
        }
        echo '</div>';
    } else {
        echo '<div class="alert alert-info py-3">';
        echo $colunaExiste ? 'Nenhuma casa encontrada para '.htmlspecialchars($categoriaFront) 
                          : 'Nenhuma casa encontrada';
        echo '</div>';
    }
} catch (Exception $e) {
    error_log('Erro em buscar-casas.php: ' . $e->getMessage());
    echo '<div class="alert alert-danger py-3">Erro ao buscar casas. Tente novamente.</div>';
}
?>