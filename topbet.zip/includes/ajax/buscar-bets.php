<?php
require_once __DIR__ . '/../../includes/conexao.php';

header('Content-Type: text/html; charset=utf-8');

$categoria = $_GET['categoria'] ?? 'esportiva';
$termo = $_GET['termo'] ?? '';

// Mapeamento de categorias
$mapeamento = [
    'esportiva' => 'esportes',
    'cassino' => 'casino',
    'slots' => 'slots',
    'poker' => 'poker'
];

if (!array_key_exists($categoria, $mapeamento)) {
    die('<div class="alert alert-danger">Categoria inválida</div>');
}

try {
    $categoriaBanco = $mapeamento[$categoria];
    
    $sql = "SELECT id, nome, logo FROM bets 
            WHERE ativo = 1 
            AND categoria = ?
            AND (nome LIKE CONCAT('%', ?, '%') OR ? = '')
            ORDER BY nome ASC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $categoriaBanco, $termo, $termo);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($bet = $result->fetch_assoc()) {
            $logo = !empty($bet['logo']) ? $bet['logo'] : 'img/logos/default.png';
            echo '
            <button type="button" class="list-group-item list-group-item-action bet-item d-flex align-items-center"
                data-id="'.$bet['id'].'" 
                data-nome="'.htmlspecialchars($bet['nome']).'">
                <img src="'.htmlspecialchars($logo).'" class="rounded me-3" style="width:40px;height:40px;object-fit:cover;">
                <span>'.htmlspecialchars($bet['nome']).'</span>
            </button>';
        }
    } else {
        echo '<div class="alert alert-info">Nenhuma casa encontrada</div>';
    }
} catch (Exception $e) {
    echo '<div class="alert alert-danger">Erro ao buscar casas</div>';
}
?>