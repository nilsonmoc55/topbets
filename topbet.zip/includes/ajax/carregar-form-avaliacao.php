<?php
require_once __DIR__ . '/../../includes/conexao.php';

$bet_id = intval($_GET['bet_id']);
$categoria = $_GET['categoria'] ?? 'esportiva'; // Recebido do modal inicial

// Busca dados da bet
$stmt = $conn->prepare("SELECT id, nome FROM bets WHERE id = ?");
$stmt->bind_param("i", $bet_id);
$stmt->execute();
$bet = $stmt->get_result()->fetch_assoc();

// Busca perguntas para a categoria
$stmt = $conn->prepare("SELECT * FROM perguntas_avaliacao WHERE categoria = ? AND ativa = TRUE ORDER BY id");
$stmt->bind_param("s", $categoria);
$stmt->execute();
$perguntas = $stmt->get_result();
?>

<form id="form-avaliacao" data-bet-id="<?= $bet['id'] ?>">
    <input type="hidden" name="categoria" value="<?= htmlspecialchars($categoria) ?>">
    
    <div class="mb-4">
        <h4>Avaliando: <?= htmlspecialchars($bet['nome']) ?></h4>
        <p class="text-muted">Categoria: <?= ucfirst($categoria) ?></p>
    </div>

    <?php while ($pergunta = $perguntas->fetch_assoc()): ?>
        <div class="mb-4">
            <label class="form-label">
                <?= htmlspecialchars($pergunta['pergunta']) ?>
                <?php if ($pergunta['peso'] > 1): ?>
                    <span class="badge bg-info">Importância: <?= $pergunta['peso'] ?></span>
                <?php endif; ?>
            </label>
            
            <?php switch ($pergunta['tipo']):
                case 'estrelas': ?>
                    <div class="rating-stars">
                        <?php for ($i = 5; $i >= 1; $i--): ?>
                            <input type="radio" id="star<?= $pergunta['id'] ?>-<?= $i ?>" 
                                   name="pergunta[<?= $pergunta['id'] ?>]" value="<?= $i ?>">
                            <label for="star<?= $pergunta['id'] ?>-<?= $i ?>">★</label>
                        <?php endfor; ?>
                    </div>
                    <?php break; ?>
                
                <?php case 'sim_nao': ?>
                    <div class="btn-group" role="group">
                        <input type="radio" class="btn-check" name="pergunta[<?= $pergunta['id'] ?>]" 
                               id="sim<?= $pergunta['id'] ?>" value="1" autocomplete="off">
                        <label class="btn btn-outline-success" for="sim<?= $pergunta['id'] ?>">Sim</label>
                        
                        <input type="radio" class="btn-check" name="pergunta[<?= $pergunta['id'] ?>]" 
                               id="nao<?= $pergunta['id'] ?>" value="0" autocomplete="off">
                        <label class="btn btn-outline-danger" for="nao<?= $pergunta['id'] ?>">Não</label>
                    </div>
                    <?php break; ?>
                
                <?php case 'texto': ?>
                    <textarea class="form-control" name="pergunta[<?= $pergunta['id'] ?>]" 
                              rows="2" placeholder="Sua opinião..."></textarea>
                    <?php break; ?>
                
                <?php case 'numero': ?>
                    <input type="number" class="form-control" name="pergunta[<?= $pergunta['id'] ?>]" 
                           min="1" max="10" placeholder="1 a 10">
                    <?php break; ?>
            <?php endswitch; ?>
        </div>
    <?php endwhile; ?>

    <div class="mb-3">
        <label class="form-label">Nota Geral (1-5)</label>
        <select class="form-select" name="nota" required>
            <option value="">Selecione...</option>
            <?php for ($i = 1; $i <= 5; $i++): ?>
                <option value="<?= $i ?>"><?= $i ?> ★</option>
            <?php endfor; ?>
        </select>
    </div>

    <div class="mb-3">
        <label class="form-label">Bônus (Opcional)</label>
        <input type="text" class="form-control" name="bonus" placeholder="Ex: 100% até R$500">
    </div>

    <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" name="concorda" required>
        <label class="form-check-label">Confirmo que minha avaliação é baseada em experiência real</label>
    </div>

    <button type="submit" class="btn btn-primary w-100 py-2">
        <i class="fas fa-paper-plane me-2"></i> Enviar Avaliação
    </button>
</form>

<style>
.rating-stars {
    display: flex;
    flex-direction: row-reverse;
    justify-content: flex-end;
}
.rating-stars input {
    display: none;
}
.rating-stars label {
    font-size: 2rem;
    color: #ddd;
    cursor: pointer;
    transition: color 0.2s;
}
.rating-stars input:checked ~ label,
.rating-stars label:hover,
.rating-stars label:hover ~ label {
    color: #ffc107;
}
</style>

<script>
document.getElementById('form-avaliacao').addEventListener('submit', function(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    const button = form.querySelector('button[type="submit"]');
    
    button.disabled = true;
    button.innerHTML = `<span class="spinner-border spinner-border-sm" role="status"></span> Enviando...`;

    fetch('includes/ajax/salvar-avaliacao.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Avaliação enviada com sucesso!');
            bootstrap.Modal.getInstance(form.closest('.modal')).hide();
            // Atualiza a página ou a lista de avaliações
            location.reload();
        } else {
            alert('Erro: ' + data.message);
            button.disabled = false;
            button.innerHTML = `<i class="fas fa-paper-plane me-2"></i> Enviar Avaliação`;
        }
    })
    .catch(error => {
        alert('Erro na comunicação com o servidor');
        console.error(error);
        button.disabled = false;
        button.innerHTML = `<i class="fas fa-paper-plane me-2"></i> Enviar Avaliação`;
    });
});
</script>