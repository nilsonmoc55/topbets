<?php
require_once __DIR__ . '/../../includes/conexao.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id'])) {
    die(json_encode(['success' => false, 'message' => 'Acesso não autorizado']));
}

$bet_id = intval($_POST['bet_id']);
$categoria = $_POST['categoria'] ?? 'esportiva';
$nota = intval($_POST['nota']);
$bonus = $_POST['bonus'] ?? '';
$respostas = json_encode($_POST['pergunta'] ?? []);

try {
    $conn->begin_transaction();

    // Insere a avaliação principal
    $stmt = $conn->prepare("INSERT INTO avaliacoes 
                          (bet_id, usuario_id, nota, bonus, categoria, respostas, data_avaliacao) 
                          VALUES (?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("iiisss", $bet_id, $_SESSION['usuario_id'], $nota, $bonus, $categoria, $respostas);
    $stmt->execute();

    // Atualiza a média da bet
    $conn->query("UPDATE bets SET 
                 media_nota = (SELECT AVG(nota) FROM avaliacoes WHERE bet_id = $bet_id),
                 total_avaliacoes = (SELECT COUNT(*) FROM avaliacoes WHERE bet_id = $bet_id)
                 WHERE id = $bet_id");

    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Avaliação registrada com sucesso!']);
} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Erro: ' . $e->getMessage()]);
}