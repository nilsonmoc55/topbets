<?php
include 'includes/conexao.php';
session_start();

// Verifica se o parâmetro bet_id foi passado
if (!isset($_GET['bet_id']) || !is_numeric($_GET['bet_id'])) {
    header("Location: index.php");
    exit();
}

$bet_id = intval($_GET['bet_id']);
$usuarioLogado = isset($_SESSION['usuario_id']);

// Busca informações da bet
$sql_bet = "SELECT * FROM bets WHERE id = ?";
$stmt_bet = $conn->prepare($sql_bet);
$stmt_bet->bind_param("i", $bet_id);
$stmt_bet->execute();
$result_bet = $stmt_bet->get_result();

if ($result_bet->num_rows === 0) {
    header("Location: index.php");
    exit();
}

$bet = $result_bet->fetch_assoc();

// Ordenação das avaliações
$ordenacao = isset($_GET['ordenar']) ? $_GET['ordenar'] : 'recentes';
switch ($ordenacao) {
    case 'melhores':
        $order_sql = "ORDER BY nota DESC";
        break;
    case 'piores':
        $order_sql = "ORDER BY nota ASC";
        break;
    case 'antigas':
        $order_sql = "ORDER BY data_avaliacao ASC";
        break;
    default:
        $order_sql = "ORDER BY data_avaliacao DESC";
}

// Busca avaliações da bet
$sql_avaliacoes = "
    SELECT 
        a.*,
        u.nome as nome_usuario,
        u.email as email_usuario,
        COUNT(r.id) as total_curtidas,
        SUM(CASE WHEN r.tipo = 'like' THEN 1 ELSE 0 END) as likes,
        SUM(CASE WHEN r.tipo = 'dislike' THEN 1 ELSE 0 END) as dislikes
    FROM avaliacoes a
    LEFT JOIN usuarios u ON a.usuario_id = u.id
    LEFT JOIN reacoes r ON a.id = r.avaliacao_id
    WHERE a.bet_id = ? AND a.status = 'aprovado'
    GROUP BY a.id
    $order_sql
";
$stmt_avaliacoes = $conn->prepare($sql_avaliacoes);
$stmt_avaliacoes->bind_param("i", $bet_id);
$stmt_avaliacoes->execute();
$avaliacoes = $stmt_avaliacoes->get_result();

// Configura o título da página
$pageTitle = "Avaliações - " . htmlspecialchars($bet['nome']) . " | TopBets";

// CSS adicional para a página
$additionalCSS = '
    <style>
        .avaliacao-card {
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            overflow: hidden;
        }
        .avaliacao-header {
            background-color: #f8f9fa;
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        .avaliacao-body {
            padding: 20px;
        }
        .avaliacao-footer {
            background-color: #f8f9fa;
            padding: 10px 15px;
            border-top: 1px solid #eee;
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 15px;
        }
        .star-rating {
            color: #ffc107;
            font-size: 1.2rem;
        }
        .btn-reacao {
            border: none;
            background: none;
            padding: 5px 10px;
            margin-right: 5px;
        }
        .btn-reacao.active-like {
            color: #0d6efd;
        }
        .btn-reacao.active-dislike {
            color: #dc3545;
        }
        .comentario-item {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .comentario-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 10px;
        }
        .badge-bonus {
            background-color: #ffc107;
            color: #000;
        }
        .badge-feature {
            background-color: #6c757d;
            color: #fff;
            margin-right: 5px;
            margin-bottom: 5px;
        }
    </style>
';

include 'includes/header.php';
include 'includes/nav.php';
?>

<!-- Breadcrumb -->
<nav aria-label="breadcrumb" class="bg-light py-3">
    <div class="container">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Avaliações - <?= htmlspecialchars($bet['nome']) ?></li>
        </ol>
    </div>
</nav>

<!-- Cabeçalho da Bet -->
<section class="py-4 bg-white">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-2 text-center">
                <img src="<?= $bet['logo'] ?>" alt="<?= htmlspecialchars($bet['nome']) ?>" class="img-fluid rounded" style="max-height: 100px;">
            </div>
            <div class="col-md-6">
                <h1 class="mb-1"><?= htmlspecialchars($bet['nome']) ?></h1>
                <div class="star-rating mb-2">
                    <?php
                    $media_nota = 0;
                    if ($avaliacoes->num_rows > 0) {
                        $total_notas = 0;
                        $avaliacoes->data_seek(0);
                        while ($av = $avaliacoes->fetch_assoc()) {
                            $total_notas += $av['nota'];
                        }
                        $media_nota = $total_notas / $avaliacoes->num_rows;
                        $avaliacoes->data_seek(0);
                    }
                    echo str_repeat('<i class="fas fa-star"></i>', floor($media_nota));
                    if (fmod($media_nota, 1) >= 0.5) {
                        echo '<i class="fas fa-star-half-alt"></i>';
                    }
                    echo str_repeat('<i class="far fa-star"></i>', 5 - ceil($media_nota));
                    ?>
                    <span class="text-muted ms-2"><?= number_format($media_nota, 1) ?> (<?= $avaliacoes->num_rows ?> avaliações)</span>
                </div>
                <a href="<?= $bet['url'] ?>" target="_blank" class="btn btn-primary btn-sm">
                    <i class="fas fa-external-link-alt me-1"></i> Visitar Site
                </a>
                <button class="btn btn-outline-secondary btn-sm ms-2" data-bs-toggle="modal" data-bs-target="#modalAvaliar">
                    <i class="fas fa-edit me-1"></i> Avaliar
                </button>
            </div>
            <div class="col-md-4">
                <div class="d-flex justify-content-end">
                    <div class="dropdown">
                        <button class="btn btn-outline-secondary dropdown-toggle" type="button" id="dropdownOrdenar" data-bs-toggle="dropdown">
                            <i class="fas fa-sort me-1"></i> Ordenar: 
                            <?= $ordenacao == 'recentes' ? 'Mais Recentes' : 
                               ($ordenacao == 'antigas' ? 'Mais Antigas' : 
                               ($ordenacao == 'melhores' ? 'Melhores' : 'Piores')) ?>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item <?= $ordenacao == 'recentes' ? 'active' : '' ?>" href="?bet_id=<?= $bet_id ?>&ordenar=recentes">Mais Recentes</a></li>
                            <li><a class="dropdown-item <?= $ordenacao == 'antigas' ? 'active' : '' ?>" href="?bet_id=<?= $bet_id ?>&ordenar=antigas">Mais Antigas</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item <?= $ordenacao == 'melhores' ? 'active' : '' ?>" href="?bet_id=<?= $bet_id ?>&ordenar=melhores">Melhores Avaliações</a></li>
                            <li><a class="dropdown-item <?= $ordenacao == 'piores' ? 'active' : '' ?>" href="?bet_id=<?= $bet_id ?>&ordenar=piores">Piores Avaliações</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Lista de Avaliações -->
<section class="py-4 bg-light">
    <div class="container">
        <?php if ($avaliacoes->num_rows > 0): ?>
            <div class="row">
                <div class="col-lg-8">
                    <?php while ($avaliacao = $avaliacoes->fetch_assoc()): ?>
                        <?php 
                        $reacaoUsuario = $usuarioLogado ? getReacaoUsuario($conn, $avaliacao['id'], $_SESSION['usuario_id']) : null;
                        $comentarios = getComentarios($conn, $avaliacao['id']);
                        ?>
                        <div class="avaliacao-card bg-white">
                            <div class="avaliacao-header">
                                <div class="d-flex align-items-center">
                                    <img src="img/avatars/<?= $avaliacao['usuario_id'] ? 'user-'.$avaliacao['usuario_id'].'.jpg' : 'anonymous.png' ?>" 
                                         alt="<?= htmlspecialchars($avaliacao['nome_usuario'] ?? 'Anônimo') ?>" 
                                         class="user-avatar">
                                    <div>
                                        <h5 class="mb-0"><?= htmlspecialchars($avaliacao['nome_usuario'] ?? 'Anônimo') ?></h5>
                                        <small class="text-muted">
                                            <?= date('d/m/Y H:i', strtotime($avaliacao['data_avaliacao'])) ?>
                                            <?php if ($avaliacao['tem_bonus']): ?>
                                                <span class="badge badge-bonus ms-2"><i class="fas fa-gift me-1"></i> Usou Bônus</span>
                                            <?php endif; ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                            <div class="avaliacao-body">
                                <div class="star-rating mb-2">
                                    <?= str_repeat('<i class="fas fa-star"></i>', floor($avaliacao['nota'])) ?>
                                    <?= str_repeat('<i class="far fa-star"></i>', 5 - floor($avaliacao['nota'])) ?>
                                    <span class="text-muted ms-2"><?= number_format($avaliacao['nota'], 1) ?>/5.0</span>
                                </div>
                                
                                <h6 class="mb-2"><?= htmlspecialchars($avaliacao['comentario_geral'] ?? 'Sem comentário') ?></h6>
                                
                                <?php if ($avaliacao['tem_bonus'] || $avaliacao['tem_promocoes'] || $avaliacao['suporte_rapido'] || $avaliacao['jogos_faceis'] || $avaliacao['saque_rapido']): ?>
                                    <div class="mb-3">
                                        <?php if ($avaliacao['tem_bonus']): ?>
                                            <span class="badge badge-feature"><i class="fas fa-gift me-1"></i> Bônus</span>
                                        <?php endif; ?>
                                        <?php if ($avaliacao['tem_promocoes']): ?>
                                            <span class="badge badge-feature"><i class="fas fa-tag me-1"></i> Promoções</span>
                                        <?php endif; ?>
                                        <?php if ($avaliacao['suporte_rapido']): ?>
                                            <span class="badge badge-feature"><i class="fas fa-headset me-1"></i> Suporte Rápido</span>
                                        <?php endif; ?>
                                        <?php if ($avaliacao['jogos_faceis']): ?>
                                            <span class="badge badge-feature"><i class="fas fa-gamepad me-1"></i> Jogos Fáceis</span>
                                        <?php endif; ?>
                                        <?php if ($avaliacao['saque_rapido']): ?>
                                            <span class="badge badge-feature"><i class="fas fa-wallet me-1"></i> Saque Rápido</span>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div>
                                        <button class="btn-reacao <?= $reacaoUsuario === 'like' ? 'active-like' : '' ?>" 
                                                data-avaliacao-id="<?= $avaliacao['id'] ?>" 
                                                data-tipo="like">
                                            <i class="fas fa-thumbs-up me-1"></i> <span class="like-count"><?= $avaliacao['likes'] ?? 0 ?></span>
                                        </button>
                                        <button class="btn-reacao <?= $reacaoUsuario === 'dislike' ? 'active-dislike' : '' ?>" 
                                                data-avaliacao-id="<?= $avaliacao['id'] ?>" 
                                                data-tipo="dislike">
                                            <i class="fas fa-thumbs-down me-1"></i> <span class="dislike-count"><?= $avaliacao['dislikes'] ?? 0 ?></span>
                                        </button>
                                    </div>
                                    <div>
                                        <button class="btn btn-sm btn-outline-secondary me-2 btn-compartilhar" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#modalCompartilhar"
                                                data-bet-nome="<?= htmlspecialchars($bet['nome']) ?>"
                                                data-avaliacao-nota="<?= $avaliacao['nota'] ?>"
                                                data-avaliacao-resumo="<?= htmlspecialchars($avaliacao['comentario_geral'] ?? '') ?>">
                                            <i class="fas fa-share-alt me-1"></i> Compartilhar
                                        </button>
                                        <button class="btn btn-sm btn-outline-primary btn-ver-mais" 
                                                data-bs-toggle="collapse" 
                                                data-bs-target="#detalhesAvaliacao<?= $avaliacao['id'] ?>">
                                            <i class="fas fa-chevron-down me-1"></i> Ver Mais
                                        </button>
                                    </div>
                                </div>
                                
                                <!-- Detalhes da avaliação (expandíveis) -->
                                <div class="collapse" id="detalhesAvaliacao<?= $avaliacao['id'] ?>">
                                    <div class="card card-body mb-3">
                                        <?php if ($avaliacao['comentario_adicional']): ?>
                                            <h6>Comentário Adicional:</h6>
                                            <p><?= nl2br(htmlspecialchars($avaliacao['comentario_adicional'])) ?></p>
                                        <?php endif; ?>
                                        
                                        <?php if ($avaliacao['suporte_nota']): ?>
                                            <h6>Suporte ao Cliente:</h6>
                                            <div class="mb-2">
                                                <?= str_repeat('<i class="fas fa-star"></i>', $avaliacao['suporte_nota']) ?>
                                                <?= str_repeat('<i class="far fa-star"></i>', 5 - $avaliacao['suporte_nota']) ?>
                                            </div>
                                            <?php if ($avaliacao['suporte_detalhes']): ?>
                                                <p><?= nl2br(htmlspecialchars($avaliacao['suporte_detalhes'])) ?></p>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        
                                        <?php if ($avaliacao['bonus_nota']): ?>
                                            <h6>Bônus e Promoções:</h6>
                                            <div class="mb-2">
                                                <?= str_repeat('<i class="fas fa-star"></i>', $avaliacao['bonus_nota']) ?>
                                                <?= str_repeat('<i class="far fa-star"></i>', 5 - $avaliacao['bonus_nota']) ?>
                                                <?php if ($avaliacao['bonus'] > 0): ?>
                                                    <span class="badge bg-warning text-dark ms-2">R$ <?= number_format($avaliacao['bonus'], 2, ',', '.') ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <?php if ($avaliacao['bonus_detalhes']): ?>
                                                <p><?= nl2br(htmlspecialchars($avaliacao['bonus_detalhes'])) ?></p>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        
                                        <?php if ($avaliacao['saque_nota']): ?>
                                            <h6>Processo de Saque:</h6>
                                            <div class="mb-2">
                                                <?= str_repeat('<i class="fas fa-star"></i>', $avaliacao['saque_nota']) ?>
                                                <?= str_repeat('<i class="far fa-star"></i>', 5 - $avaliacao['saque_nota']) ?>
                                            </div>
                                            <?php if ($avaliacao['saque_detalhes']): ?>
                                                <p><?= nl2br(htmlspecialchars($avaliacao['saque_detalhes'])) ?></p>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Seção de Comentários -->
                                    <div class="mb-3">
                                        <h6>Comentários:</h6>
                                        <?php if ($comentarios->num_rows > 0): ?>
                                            <?php while ($comentario = $comentarios->fetch_assoc()): ?>
                                                <div class="comentario-item">
                                                    <div class="d-flex">
                                                        <img src="img/avatars/user-<?= $comentario['usuario_id'] ?>.jpg" 
                                                             alt="<?= htmlspecialchars($comentario['nome_usuario']) ?>" 
                                                             class="comentario-avatar">
                                                        <div class="flex-grow-1">
                                                            <div class="d-flex justify-content-between">
                                                                <strong><?= htmlspecialchars($comentario['nome_usuario']) ?></strong>
                                                                <small class="text-muted"><?= date('d/m/Y H:i', strtotime($comentario['data_criacao'])) ?></small>
                                                            </div>
                                                            <p class="mb-1"><?= nl2br(htmlspecialchars($comentario['comentario'])) ?></p>
                                                            <div class="d-flex align-items-center">
                                                                <button class="btn-reacao btn-sm" data-comentario-id="<?= $comentario['id'] ?>">
                                                                    <i class="far fa-thumbs-up me-1"></i> <span><?= $comentario['total_curtidas'] ?? 0 ?></span>
                                                                </button>
                                                                <button class="btn-resposta btn-sm text-muted ms-3">
                                                                    <i class="far fa-comment me-1"></i> Responder
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <p class="text-muted">Nenhum comentário ainda.</p>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Formulário para novo comentário -->
                                    <?php if ($usuarioLogado): ?>
                                        <form class="form-comentario" data-avaliacao-id="<?= $avaliacao['id'] ?>">
                                            <div class="mb-3">
                                                <textarea class="form-control" name="comentario" placeholder="Adicione um comentário..." rows="2" required></textarea>
                                            </div>
                                            <button type="submit" class="btn btn-primary btn-sm">Comentar</button>
                                        </form>
                                    <?php else: ?>
                                        <div class="alert alert-info">
                                            <a href="#" data-bs-toggle="modal" data-bs-target="#modalLogin">Faça login</a> para comentar.
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
                
                <!-- Sidebar -->
                <div class="col-lg-4">
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">Avalie <?= htmlspecialchars($bet['nome']) ?></h5>
                        </div>
                        <div class="card-body">
                            <p>Compartilhe sua experiência com outros usuários. Sua avaliação ajuda a comunidade a escolher as melhores casas de apostas.</p>
                            <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#modalAvaliar">
                                <i class="fas fa-edit me-1"></i> Avaliar Agora
                            </button>
                        </div>
                    </div>
                    
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">Estatísticas</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <h6>Média de Notas:</h6>
                                <div class="star-rating">
                                    <?= str_repeat('<i class="fas fa-star"></i>', floor($media_nota)) ?>
                                    <?= (fmod($media_nota, 1) >= 0.5) ? '<i class="fas fa-star-half-alt"></i>' : '' ?>
                                    <?= str_repeat('<i class="far fa-star"></i>', 5 - ceil($media_nota)) ?>
                                    <span class="text-muted ms-2"><?= number_format($media_nota, 1) ?>/5.0</span>
                                </div>
                            </div>
                            <div class="mb-3">
                                <h6>Total de Avaliações:</h6>
                                <p><?= $avaliacoes->num_rows ?></p>
                            </div>
                            <div class="mb-3">
                                <h6>Última Avaliação:</h6>
                                <p><?= date('d/m/Y', strtotime($avaliacao['data_avaliacao'])) ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">Visite o Site</h5>
                        </div>
                        <div class="card-body text-center">
                            <img src="<?= $bet['logo'] ?>" alt="<?= htmlspecialchars($bet['nome']) ?>" class="img-fluid mb-3" style="max-height: 80px;">
                            <a href="<?= $bet['url'] ?>" target="_blank" class="btn btn-success w-100">
                                <i class="fas fa-external-link-alt me-1"></i> Acessar <?= htmlspecialchars($bet['nome']) ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-star fa-3x text-muted mb-3"></i>
                <h4>Nenhuma avaliação ainda</h4>
                <p>Seja o primeiro a avaliar esta casa de apostas!</p>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAvaliar">
                    <i class="fas fa-edit me-1"></i> Avaliar Agora
                </button>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php
include 'includes/modais.php';
include 'includes/footer.php';
include 'includes/scripts.php';
?>

<!-- Scripts específicos para esta página -->
<script>
// Sistema de reações (like/dislike)
document.querySelectorAll('.btn-reacao[data-avaliacao-id]').forEach(btn => {
    btn.addEventListener('click', function() {
        if (!<?= $usuarioLogado ? 'true' : 'false' ?>) {
            const modalLogin = new bootstrap.Modal(document.getElementById('modalLogin'));
            modalLogin.show();
            return;
        }
        
        const avaliacaoId = this.getAttribute('data-avaliacao-id');
        const tipo = this.getAttribute('data-tipo');
        const isActive = this.classList.contains(`active-${tipo}`);
        
        fetch('processa-reacao.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `avaliacao_id=${avaliacaoId}&tipo=${tipo}&acao=${isActive ? 'remover' : 'adicionar'}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Atualiza contadores
                const likeCount = this.querySelector('.like-count') || this.parentElement.querySelector('.like-count');
                const dislikeCount = this.querySelector('.dislike-count') || this.parentElement.querySelector('.dislike-count');
                
                if (tipo === 'like') {
                    likeCount.textContent = data.likes;
                    if (isActive) {
                        this.classList.remove('active-like');
                    } else {
                        this.classList.add('active-like');
                        // Remove dislike se existir
                        const dislikeBtn = this.parentElement.querySelector('[data-tipo="dislike"]');
                        if (dislikeBtn.classList.contains('active-dislike')) {
                            dislikeBtn.classList.remove('active-dislike');
                            dislikeCount.textContent = parseInt(dislikeCount.textContent) - 1;
                        }
                    }
                } else {
                    dislikeCount.textContent = data.dislikes;
                    if (isActive) {
                        this.classList.remove('active-dislike');
                    } else {
                        this.classList.add('active-dislike');
                        // Remove like se existir
                        const likeBtn = this.parentElement.querySelector('[data-tipo="like"]');
                        if (likeBtn.classList.contains('active-like')) {
                            likeBtn.classList.remove('active-like');
                            likeCount.textContent = parseInt(likeCount.textContent) - 1;
                        }
                    }
                }
            } else {
                alert(data.message || 'Erro ao processar reação');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Erro ao conectar com o servidor');
        });
    });
});

// Sistema de comentários
document.querySelectorAll('.form-comentario').forEach(form => {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const avaliacaoId = this.getAttribute('data-avaliacao-id');
        const comentario = this.querySelector('textarea').value;
        
        fetch('processa-comentario.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `avaliacao_id=${avaliacaoId}&comentario=${encodeURIComponent(comentario)}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Recarrega a página para mostrar o novo comentário
                window.location.reload();
            } else {
                alert(data.message || 'Erro ao adicionar comentário');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Erro ao conectar com o servidor');
        });
    });
});

// Botão "Ver Mais" dinâmico
document.querySelectorAll('.btn-ver-mais').forEach(btn => {
    btn.addEventListener('click', function() {
        const icon = this.querySelector('i');
        if (icon.classList.contains('fa-chevron-down')) {
            icon.classList.remove('fa-chevron-down');
            icon.classList.add('fa-chevron-up');
            this.innerHTML = this.innerHTML.replace('Ver Mais', 'Ver Menos');
        } else {
            icon.classList.remove('fa-chevron-up');
            icon.classList.add('fa-chevron-down');
            this.innerHTML = this.innerHTML.replace('Ver Menos', 'Ver Mais');
        }
    });
});

// Configurar modal de compartilhamento
document.querySelectorAll('.btn-compartilhar').forEach(btn => {
    btn.addEventListener('click', function() {
        const betNome = this.getAttribute('data-bet-nome');
        const nota = parseFloat(this.getAttribute('data-avaliacao-nota'));
        const resumo = this.getAttribute('data-avaliacao-resumo');
        
        document.getElementById('shareBetName').textContent = `Avaliação de ${betNome}`;
        
        const starsContainer = document.getElementById('shareRatingStars');
        starsContainer.innerHTML = '';
        for (let i = 1; i <= 5; i++) {
            const star = document.createElement('i');
            star.className = i <= nota ? 'fas fa-star' : 'far fa-star';
            starsContainer.appendChild(star);
        }
        starsContainer.innerHTML += ` <span>${nota.toFixed(1)}/5.0</span>`;
        
        document.getElementById('shareReviewText').textContent = resumo || 'Ótima experiência com esta casa de apostas!';
    });
});

// Configurar botões de compartilhamento
document.querySelectorAll('.share-btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        const social = this.getAttribute('data-social');
        const betNome = document.getElementById('shareBetName').textContent;
        const stars = document.getElementById('shareRatingStars').textContent;
        const text = document.getElementById('shareReviewText').textContent;
        const url = window.location.href;
        
        let shareUrl = '';
        const shareText = `${betNome} - ${stars}\n\n${text}\n\nAvalie você também: ${url}`;
        
        switch(social) {
            case 'facebook':
                shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(shareText)}`;
                window.open(shareUrl, '_blank', 'width=600,height=400');
                break;
            case 'twitter':
                shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}`;
                window.open(shareUrl, '_blank', 'width=600,height=400');
                break;
            case 'whatsapp':
                shareUrl = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
                window.open(shareUrl, '_blank', 'width=600,height=400');
                break;
            case 'copy':
                navigator.clipboard.writeText(shareText)
                    .then(() => alert('Link copiado para a área de transferência!'))
                    .catch(() => prompt('Copie o texto abaixo:', shareText));
                break;
        }
    });
});
</script>