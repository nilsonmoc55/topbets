<?php
session_start();
require_once 'conexao.php';

header('Content-Type: application/json');

$response = ['success' => false, 'message' => ''];

try {
    // Verifica se é POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método não permitido');
    }

    // Obtém e valida os dados
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $senha = $_POST['senha'] ?? '';
    $bet_id = filter_input(INPUT_POST, 'bet_id', FILTER_VALIDATE_INT);
    $bet_nome = filter_input(INPUT_POST, 'bet_nome', FILTER_SANITIZE_STRING);

    // Validações
    if ($email === false) {  // Alterado para verificar explicitamente false
        throw new Exception('Por favor, insira um e-mail válido', 'email');
    }
    
    if (empty($senha)) {
        throw new Exception('Por favor, insira sua senha', 'senha');
    }

    // Restante do código de verificação no banco...
    $stmt = $conn->prepare("SELECT id, nome, senha FROM usuarios WHERE email = ? AND ativo = 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        throw new Exception('E-mail ou senha incorretos', 'credenciais');
    }

    $usuario = $result->fetch_assoc();
    
    if (!password_verify($senha, $usuario['senha'])) {
        throw new Exception('E-mail ou senha incorretos', 'credenciais');
    }

    // Login bem-sucedido
    $_SESSION['usuario_id'] = $usuario['id'];
    $_SESSION['usuario_nome'] = $usuario['nome'];
    
    $response['success'] = true;
    $response['message'] = 'Login realizado com sucesso';

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    $response['campo'] = $e->getCode(); // Usamos getCode para identificar o campo com erro
}

echo json_encode($response);
?>