<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
        </main> <!-- Fecha a tag <main> aberta no header -->

        <footer class="bg-dark text-white py-4 mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 mb-4 mb-md-0">
                        <h5>Sobre o TopBets</h5>
                        <p class="text-muted">Plataforma de avalia��es de casas de apostas criada para ajudar apostadores.</p>
                    </div>
                    <div class="col-md-4 mb-4 mb-md-0">
                        <h5>Links R�pidos</h5>
                        <ul class="list-unstyled">
                            <li><a href="index.php" class="text-decoration-none text-muted">Home</a></li>
                            <li><a href="melhores-bets.php" class="text-decoration-none text-muted">Melhores Bets</a></li>
                            <li><a href="termos.php" class="text-decoration-none text-muted">Termos de Uso</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <h5>Contato</h5>
                        <ul class="list-unstyled text-muted">
                            <li><i class="fas fa-envelope me-2"></i> contato@topbets.com</li>
                            <li><i class="fas fa-phone me-2"></i> (00) 1234-5678</li>
                        </ul>
                    </div>
                </div>
                <hr class="my-4 bg-secondary">
                <div class="text-center text-muted">
                    <small>&copy; <?= date('Y') ?> TopBets. Todos os direitos reservados.</small>
                </div>
            </div>
        </footer>

        <!-- Bootstrap JS Bundle com Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        
        <!-- Scripts personalizados -->
        <script src="/js/scripts.js"></script>
        
        <!-- Controlador do Modal de Login -->
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            <?php if(isset($_SESSION['erro_login'])): ?>
                var loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
                loginModal.show();
                <?php unset($_SESSION['erro_login']); ?>
            <?php endif; ?>
        });
        </script>
    </body>
</html>
</html>
