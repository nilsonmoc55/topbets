<script>
$(document).ready(function() {
    // Variáveis globais
    let currentBetId = null;
    
    // 1. Busca em tempo real na página principal
    $('#searchBets').on('input', function() {
        const searchTerm = $(this).val().toLowerCase();
        $('.bet-item').each(function() {
            const betName = $(this).find('.card-title').text().toLowerCase();
            $(this).toggle(betName.includes(searchTerm));
        });
    });

    // 2. Controle do modal de verificação para avaliação
    $('.btn-avaliar').click(function(e) {
        e.preventDefault();
        currentBetId = $(this).data('bet-id');
        $('#betNameTitle').text($(this).data('bet-name'));
        $('#modalVerificaLogin').modal('show');
    });

    // 3. Redirecionamentos para avaliação
    $('#btnAvaliarLogado, #btnAvaliarAnonimo').click(function(e) {
        e.preventDefault();
        const isAnonimo = $(this).attr('id') === 'btnAvaliarAnonimo';
        window.location.href = `avaliar.php?bet_id=${currentBetId}${isAnonimo ? '&anonimo=1' : ''}`;
    });
    
    // 4. Busca dinâmica no modal de lista completa
    $('#btnBuscarListaCompleta').on('click', buscarBetsModal);
    $('#buscarBetListaCompleta').on('keyup', function(e) {
        if (e.key === 'Enter') buscarBetsModal();
    });

    function buscarBetsModal() {
        const busca = $('#buscarBetListaCompleta').val();
        const tabelaBets = $('#tabelaBets tbody');
        
        // Mostra loading
        tabelaBets.html('<tr><td colspan="5" class="text-center"><div class="spinner-border text-primary" role="status"></div></td></tr>');
        
        $.ajax({
            url: '../pages/carregar_bets.php',
            method: 'GET',
            data: { busca: busca, lista_completa: true },
            success: function(data) {
                tabelaBets.html(data);
                // Reativa os eventos de clique nos novos botões
                $('.btn-avaliar-modal').off('click').on('click', function(e) {
                    e.preventDefault();
                    const betId = $(this).data('bet-id');
                    abrirModalAvaliar(betId);
                });
            },
            error: function() {
                tabelaBets.html('<tr><td colspan="5" class="text-center text-danger">Erro ao carregar dados</td></tr>');
            }
        });
    }
    
    // 5. Função para abrir modal de avaliação a partir da lista completa
    window.abrirModalAvaliar = function(betId) {
        // Fecha o modal atual
        $('#modalListaCompleta').modal('hide');
        
        // Define o ID da bet e abre o modal de avaliação
        currentBetId = betId;
        $('#modalVerificaLogin').modal('show');
        
        // Opcional: Busca o nome da bet via AJAX se não estiver disponível
        if (!$('#betNameTitle').text()) {
            $.get('../pages/get_bet_name.php', { id: betId }, function(data) {
                $('#betNameTitle').text(data.name);
            });
        }
    }
    
    // 6. Inicialização de tooltips (se estiver usando Bootstrap)
    $('[data-bs-toggle="tooltip"]').tooltip();
    
    // 7. Evento para quando o modal de lista completa é aberto
    $('#modalListaCompleta').on('shown.bs.modal', function() {
        // Foca no campo de busca
        $('#buscarBetListaCompleta').focus();
    });
});
</script>