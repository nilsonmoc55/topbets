<?php
require_once 'includes/conexao.php';
require_once 'includes/funcoes.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email_login', FILTER_SANITIZE_EMAIL);
    $senha = $_POST['senha_login'];
    $lembrar = isset($_POST['lembrar']);

    // Verifica credenciais
    $stmt = $conn->prepare("SELECT id, nome, senha, nivel_acesso FROM usuarios WHERE email = ? AND ativo = 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $usuario = $result->fetch_assoc();
        
        if (password_verify($senha, $usuario['senha'])) {
            // Login bem-sucedido
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario_nome'] = $usuario['nome'];
            $_SESSION['usuario_nivel'] = $usuario['nivel_acesso'];
            
            // Se marcou "Lembrar de mim", cria cookie
            if ($lembrar) {
                $token = bin2hex(random_bytes(32));
                $expiracao = time() + (30 * 24 * 60 * 60); // 30 dias
                
                setcookie('lembrar_token', $token, $expiracao, '/');
                
                // Salva token no banco
                $stmt = $conn->prepare("UPDATE usuarios SET token_recuperacao = ?, token_validade = ? WHERE id = ?");
                $dataExpiracao = date('Y-m-d H:i:s', $expiracao);
                $stmt->bind_param("ssi", $token, $dataExpiracao, $usuario['id']);
                $stmt->execute();
            }
            
            // Redireciona para index.php
            header('Location: index.php');
            exit();
        }
    }
    
    // Se chegou aqui, login falhou
    $_SESSION['erros_login'] = [
        'email' => 'E-mail ou senha incorretos',
        'senha' => 'E-mail ou senha incorretos'
    ];
    header('Location: ' . $_SERVER['HTTP_REFERER']);
    exit();
}