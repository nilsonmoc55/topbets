<?php
session_start();
include __DIR__ . '/../conexao.php';

$response = ['success' => false, 'errors' => []];
$bet_id = $_POST['bet_id'] ?? '';
$bet_nome = $_POST['bet_nome'] ?? '';

// Validação
$email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
$senha = $_POST['senha'] ?? '';

if (!$email) {
    $response['errors']['email'] = 'E-mail inválido';
    $_SESSION['login_errors']['email_value'] = $_POST['email'];
}

if (empty($senha)) {
    $response['errors']['senha'] = 'Senha obrigatória';
}

if (!empty($response['errors'])) {
    $_SESSION['login_errors'] = array_merge($_SESSION['login_errors'] ?? [], $response['errors']);
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Verifica no banco
$stmt = $conn->prepare("SELECT id, nome, senha FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $response['errors']['email'] = 'E-mail não cadastrado';
    $_SESSION['login_errors'] = $response['errors'];
    $_SESSION['login_errors']['email_value'] = $email;
} else {
    $usuario = $result->fetch_assoc();
    if (!password_verify($senha, $usuario['senha'])) {
        $response['errors']['senha'] = 'Senha incorreta';
        $_SESSION['login_errors'] = $response['errors'];
    } else {
        // Login válido
        $_SESSION['usuario_id'] = $usuario['id'];
        $_SESSION['usuario_nome'] = $usuario['nome'];
        
        if (!empty($_POST['lembrar'])) {
            setcookie('lembrar_usuario', $usuario['id'], time() + (86400 * 30), "/");
        }
        
        $response['success'] = true;
        $response['bet_id'] = $bet_id;
        $response['bet_nome'] = $bet_nome;
    }
}

header('Content-Type: application/json');
echo json_encode($response);