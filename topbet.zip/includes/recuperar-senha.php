<?php
include 'conexao.php';
header('Content-Type: application/json');

$email = $_POST['email'];

// Verifica se o e-mail existe
$stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'E-mail não cadastrado']);
    exit;
}

// Gera token de recuperação (exemplo simplificado)
$token = bin2hex(random_bytes(32));
$expira = date('Y-m-d H:i:s', strtotime('+1 hour'));

// Salva no banco
$stmt = $conn->prepare("UPDATE usuarios SET token_recuperacao = ?, token_expira = ? WHERE email = ?");
$stmt->bind_param("sss", $token, $expira, $email);
$stmt->execute();

// Aqui você implementaria o envio de e-mail na vida real
// $link = "https://seusite.com/recuperar-senha.php?token=$token";
// mail($email, "Recuperação de Senha", "Clique no link: $link");

echo json_encode(['success' => true]);