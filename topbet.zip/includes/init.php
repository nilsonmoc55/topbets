<?php
// includes/init.php
require 'conexao.php';

if ($usuarioLogado) {
    // Atualiza dados da sessão a cada carregamento
    $stmt = $conn->prepare("SELECT nome, nivel_acesso, avatar FROM usuarios WHERE id = ? AND ativo = 1");
    $stmt->bind_param("i", $_SESSION['usuario_id']);
    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        $result = $stmt->get_result();
        $usuario = $result->fetch_assoc();
        $_SESSION = array_merge($_SESSION, $usuario);
    } else {
        // Usuário não encontrado ou inativo - faz logout
        session_unset();
        session_destroy();
        header("Location: login.php");
        exit;
    }
}
[mail function]
SMTP = mail.infinityfree.com
smtp_port = 465
sendmail_from = no-reply@seusite.com
mail.add_x_header = Off
?>