<?php
// Inicia a sessão se não estiver iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Define variáveis padrão
$usuarioLogado = isset($_SESSION['usuario_id']);
$usuarioNome = htmlspecialchars($_SESSION['usuario_nome'] ?? '');
$usuarioAvatar = htmlspecialchars($_SESSION['usuario_avatar'] ?? '');
$usuarioNivel = $_SESSION['usuario_nivel'] ?? 1;
$paginaAtual = basename($_SERVER['PHP_SELF']);

// Verifica se há erros de cadastro/login na sessão
$errosCadastro = $_SESSION['erros_cadastro'] ?? [];
$errosLogin = $_SESSION['erros_login'] ?? [];
unset($_SESSION['erros_cadastro']);
unset($_SESSION['erros_login']);

// Recupera valores submetidos em caso de erro
$nomeCadastro = $_POST['nome'] ?? '';
$emailCadastro = $_POST['email'] ?? '';
$emailLogin = $_POST['email_login'] ?? '';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TopBets - Melhores Sites de Apostas</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- CSS Personalizado -->
    <link rel="stylesheet" href="/css/estilo.css">
    
    <style>
        .navbar-brand img {
            transition: transform 0.3s;
            height: 40px;
        }
        .navbar-brand:hover img {
            transform: scale(1.1);
        }
        .user-avatar {
            width: 32px;
            height: 32px;
            object-fit: cover;
            border-radius: 50%;
        }
        .dropdown-menu {
            min-width: 220px;
        }
        .nav-link.active {
            font-weight: 500;
            color: #0d6efd !important;
        }
        .modal-header {
            background-color: #0d6efd;
            color: white;
        }
        .is-invalid {
            border-color: #dc3545 !important;
        }
        .invalid-feedback {
            display: block;
            color: #dc3545;
            font-size: 0.875em;
        }
        .email-checking {
            color: #6c757d;
            font-size: 0.875em;
        }
        .email-exists {
            color: #dc3545;
            font-size: 0.875em;
        }
        .email-available {
            color: #198754;
            font-size: 0.875em;
        }
        #recuperarModal .modal-header {
            background-color: #ffc107;
            color: #212529;
        }
        .toast-container {
            z-index: 1100;
        }
    </style>
</head>
<body>
    <header class="bg-dark text-white sticky-top shadow-sm">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-dark">
                <div class="container-fluid">
                    <!-- Logo -->
                    <a class="navbar-brand" href="index.php">
                        <img src="/img/logo.png" alt="TopBets" class="d-inline-block align-top">
                        <span class="ms-2 d-none d-lg-inline">TopBets</span>
                    </a>

                    <!-- Botão Mobile -->
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <!-- Menu Principal -->
                    <div class="collapse navbar-collapse" id="navbarMain">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link <?= $paginaAtual == 'index.php' ? 'active' : '' ?>" href="index.php">
                                    <i class="fas fa-home fa-fw me-1"></i> Home
                                </a>
                            </li>
                            
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle <?= in_array($paginaAtual, ['melhores-bets.php', 'novas-bets.php']) ? 'active' : '' ?>" href="#" id="betsDropdown">
                                    <i class="fas fa-chess-queen fa-fw me-1"></i> Bets
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="betsDropdown">
                                    <li><a class="dropdown-item" href="melhores-bets.php"><i class="fas fa-trophy me-2"></i> Melhores</a></li>
                                    <li><a class="dropdown-item" href="novas-bets.php"><i class="fas fa-plus-circle me-2"></i> Novas</a></li>
                                </ul>
                            </li>
                            
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle <?= in_array($paginaAtual, ['ultimas-avaliacoes.php', 'melhores-avaliadas.php']) ? 'active' : '' ?>" href="#" id="avaliacoesDropdown">
                                    <i class="fas fa-star fa-fw me-1"></i> Avaliações
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="avaliacoesDropdown">
                                    <li><a class="dropdown-item" href="ultimas-avaliacoes.php"><i class="fas fa-list me-2"></i> Últimas</a></li>
                                    <li><a class="dropdown-item" href="melhores-avaliadas.php"><i class="fas fa-medal me-2"></i> Melhores</a></li>
                                </ul>
                            </li>
                        </ul>

                        <!-- Área do Usuário -->
                        <ul class="navbar-nav ms-auto">
                            <?php if($usuarioLogado): ?>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="userDropdown" data-bs-toggle="dropdown">
                                        <?php if(!empty($usuarioAvatar)): ?>
                                            <img src="<?= $usuarioAvatar ?>" class="user-avatar me-2">
                                        <?php else: ?>
                                            <i class="fas fa-user-circle me-1"></i>
                                        <?php endif; ?>
                                        <span class="d-none d-lg-inline"><?= $usuarioNome ?></span>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                        <li><h6 class="dropdown-header">Minha Conta</h6></li>
                                        <li><a class="dropdown-item" href="meus-dados.php"><i class="fas fa-user-cog me-2"></i> Meus Dados</a></li>
                                        <li><a class="dropdown-item" href="minhas-avaliacoes.php"><i class="fas fa-star me-2"></i> Minhas Avaliações</a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <?php if($usuarioNivel >= 2): ?>
                                            <li><a class="dropdown-item text-warning" href="admin/"><i class="fas fa-shield-alt me-2"></i> Painel Admin</a></li>
                                        <?php endif; ?>
                                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a></li>
                                    </ul>
                                </li>
                            <?php else: ?>
                                <li class="nav-item">
                                    <button class="btn btn-outline-light me-2" data-bs-toggle="modal" data-bs-target="#loginModal">
                                        <i class="fas fa-sign-in-alt me-1"></i> Login
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#cadastroModal">
                                        <i class="fas fa-user-plus me-1"></i> Cadastrar
                                    </button>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </header>

    <!-- Modal de Login -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-sign-in-alt me-2"></i>Login</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="formLogin" action="processa_login.php" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">E-mail</label>
                            <input type="email" class="form-control <?= isset($errosLogin['email']) ? 'is-invalid' : '' ?>" 
                                   name="email_login" value="<?= htmlspecialchars($emailLogin) ?>" required>
                            <?php if(isset($errosLogin['email'])): ?>
                                <div class="invalid-feedback"><?= $errosLogin['email'] ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Senha</label>
                            <input type="password" class="form-control <?= isset($errosLogin['senha']) ? 'is-invalid' : '' ?>" 
                                   name="senha_login" required>
                            <?php if(isset($errosLogin['senha'])): ?>
                                <div class="invalid-feedback"><?= $errosLogin['senha'] ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="lembrarLogin" name="lembrar">
                            <label class="form-check-label" for="lembrarLogin">Lembrar de mim</label>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#recuperarModal" data-bs-dismiss="modal">
                                Esqueceu a senha?
                            </a>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#cadastroModal" data-bs-dismiss="modal">
                            Não tem conta? Cadastre-se
                        </a>
                        <div>
                            <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary">Entrar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal de Cadastro -->
    <div class="modal fade" id="cadastroModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-user-plus me-2"></i>Criar Conta</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="formCadastro" action="processa_cadastro.php" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Nome Completo</label>
                            <input type="text" class="form-control <?= isset($errosCadastro['nome']) ? 'is-invalid' : '' ?>" 
                                   name="nome" value="<?= htmlspecialchars($nomeCadastro) ?>" required>
                            <?php if(isset($errosCadastro['nome'])): ?>
                                <div class="invalid-feedback"><?= $errosCadastro['nome'] ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">E-mail</label>
                            <input type="email" class="form-control <?= isset($errosCadastro['email']) ? 'is-invalid' : '' ?>" 
                                   name="email" id="emailCadastro" value="<?= htmlspecialchars($emailCadastro) ?>" required>
                            <div id="emailStatus" class="mt-1"></div>
                            <div id="emailRecuperar" class="mt-2 d-none">
                                <a href="#" class="text-decoration-none" id="linkRecuperarSenha" data-bs-toggle="modal" data-bs-target="#recuperarModal">
                                    <i class="fas fa-key me-1"></i> Esqueceu a senha? Clique para recuperar
                                </a>
                            </div>
                            <?php if(isset($errosCadastro['email'])): ?>
                                <div class="invalid-feedback"><?= $errosCadastro['email'] ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Senha (mínimo 6 caracteres)</label>
                            <input type="password" class="form-control <?= isset($errosCadastro['senha']) ? 'is-invalid' : '' ?>" 
                                   name="senha" minlength="6" required>
                            <?php if(isset($errosCadastro['senha'])): ?>
                                <div class="invalid-feedback"><?= $errosCadastro['senha'] ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Confirmar Senha</label>
                            <input type="password" class="form-control <?= isset($errosCadastro['confirmar_senha']) ? 'is-invalid' : '' ?>" 
                                   name="confirmar_senha" minlength="6" required>
                            <?php if(isset($errosCadastro['confirmar_senha'])): ?>
                                <div class="invalid-feedback"><?= $errosCadastro['confirmar_senha'] ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input <?= isset($errosCadastro['termos']) ? 'is-invalid' : '' ?>" 
                                   type="checkbox" id="concordoTermos" name="termos" required>
                            <label class="form-check-label" for="concordoTermos">
                                Concordo com os <a href="#" data-bs-toggle="modal" data-bs-target="#termosModal">Termos de Uso</a>
                            </label>
                            <?php if(isset($errosCadastro['termos'])): ?>
                                <div class="invalid-feedback"><?= $errosCadastro['termos'] ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="modal-footer justify-content-between">
                        <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#loginModal" data-bs-dismiss="modal">Já tem conta? Login</a>
                        <div>
                            <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-primary" id="btnCadastrar" disabled>Cadastrar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal de Recuperação de Senha -->
    <div class="modal fade" id="recuperarModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning">
                    <h5 class="modal-title"><i class="fas fa-key me-2"></i>Recuperar Senha</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="formRecuperar" action="processa_recuperacao.php" method="POST">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">E-mail cadastrado</label>
                            <input type="email" class="form-control" name="email_recuperacao" id="emailRecuperacaoInput" required>
                        </div>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i> Enviaremos um link para redefinir sua senha no e-mail informado.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-warning">Enviar Link</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal de Termos de Uso -->
    <div class="modal fade" id="termosModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-file-contract me-2"></i>Termos de Uso</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h5>1. Termos</h5>
                    <p>Ao acessar ao site TopBets, concorda em cumprir estes termos de serviço...</p>
                    <!-- Conteúdo completo dos termos -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Entendi</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast para mensagens -->
    <div class="toast-container position-fixed bottom-0 end-0 p-3">
        <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header">
                <strong class="me-auto" id="toastTitle">Notificação</strong>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body" id="toastMessage">
                Mensagem de exemplo
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
<script>
$(document).ready(function() {
    // Verificação de e-mail em tempo real no cadastro
    $('#emailCadastro').on('input', function() {
        var email = $(this).val();
        var emailStatus = $('#emailStatus');
        var emailRecuperar = $('#emailRecuperar');
        var btnCadastrar = $('#btnCadastrar');
        
        if (email.length > 3 && email.includes('@')) {
            emailStatus.html('<span class="email-checking"><i class="fas fa-spinner fa-spin me-1"></i> Verificando...</span>');
            emailRecuperar.addClass('d-none');
            
            $.ajax({
                url: 'verifica_email.php',
                type: 'POST',
                data: { email: email },
                success: function(response) {
                    if (response.exists) {
                        emailStatus.html('<span class="email-exists"><i class="fas fa-times-circle me-1"></i> Este e-mail já está cadastrado</span>');
                        emailRecuperar.removeClass('d-none');
                        $('#linkRecuperarSenha').attr('data-email', email);
                        btnCadastrar.prop('disabled', true);
                    } else {
                        emailStatus.html('<span class="email-available"><i class="fas fa-check-circle me-1"></i> E-mail disponível</span>');
                        emailRecuperar.addClass('d-none');
                        btnCadastrar.prop('disabled', false);
                    }
                },
                error: function() {
                    emailStatus.html('<span class="text-danger">Erro ao verificar e-mail</span>');
                }
            });
        } else {
            emailStatus.empty();
            emailRecuperar.addClass('d-none');
            btnCadastrar.prop('disabled', true);
        }
    });

    // Função para fechar corretamente o modal de recuperação
    function fecharModalRecuperacao() {
        var modal = bootstrap.Modal.getInstance(document.getElementById('recuperarModal'));
        modal.hide();
        
        setTimeout(function() {
            $('.modal-backdrop').not(':first').remove();
            $('body').removeClass('modal-open').css('padding-right', '');
        }, 100);
    }

    // Configuração do modal de recuperação
    var recuperarModal = new bootstrap.Modal(document.getElementById('recuperarModal'), {
        backdrop: 'static'
    });

    // Preenche e abre o modal de recuperação
    $('#linkRecuperarSenha').on('click', function(e) {
        e.preventDefault();
        var email = $(this).attr('data-email');
        
        var cadastroModal = bootstrap.Modal.getInstance(document.getElementById('cadastroModal'));
        cadastroModal.hide();
        
        setTimeout(function() {
            $('#emailRecuperacaoInput').val(email);
            recuperarModal.show();
        }, 300);
    });

    // Envio do formulário de login (atualizado para não fechar o modal)
    $('#formLogin').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var submitBtn = form.find('button[type="submit"]');
        var originalText = submitBtn.html();
        
        submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Entrando...');
        
        $.ajax({
            url: 'processa_login.php',
            type: 'POST',
            data: form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    // Login bem-sucedido - redireciona
                    window.location.href = 'index.php';
                } else {
                    // Mostra erros no formulário sem fechar o modal
                    submitBtn.prop('disabled', false).html(originalText);
                    
                    // Limpa erros anteriores
                    $('.is-invalid').removeClass('is-invalid');
                    $('.invalid-feedback').remove();
                    
                    // Adiciona novos erros
                    if (response.errors.email) {
                        $('input[name="email_login"]').addClass('is-invalid')
                            .after('<div class="invalid-feedback">' + response.errors.email + '</div>');
                    }
                    if (response.errors.senha) {
                        $('input[name="senha_login"]').addClass('is-invalid')
                            .after('<div class="invalid-feedback">' + response.errors.senha + '</div>');
                    }
                    
                    // Mostra toast se houver mensagem geral
                    if (response.message) {
                        var toast = new bootstrap.Toast(document.getElementById('liveToast'));
                        $('#toastTitle').text("Erro");
                        $('#toastMessage').text(response.message);
                        $('.toast').removeClass('bg-success').addClass('bg-danger text-white');
                        toast.show();
                    }
                }
            },
            error: function() {
                submitBtn.prop('disabled', false).html(originalText);
                var toast = new bootstrap.Toast(document.getElementById('liveToast'));
                $('#toastTitle').text("Erro");
                $('#toastMessage').text("Erro na comunicação com o servidor");
                $('.toast').removeClass('bg-success').addClass('bg-danger text-white');
                toast.show();
            }
        });
    });

    // Envio do formulário de recuperação de senha
    $('#formRecuperar').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var submitBtn = form.find('button[type="submit"]');
        var originalText = submitBtn.html();
        
        submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Enviando...');
        
        $.ajax({
            url: 'processa_recuperacao.php',
            type: 'POST',
            data: form.serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    var toast = new bootstrap.Toast(document.getElementById('liveToast'));
                    $('#toastTitle').text("Sucesso");
                    $('#toastMessage').text(response.message);
                    $('.toast').removeClass('bg-danger').addClass('bg-success text-white');
                    toast.show();
                    
                    setTimeout(fecharModalRecuperacao, 2000);
                } else {
                    var toast = new bootstrap.Toast(document.getElementById('liveToast'));
                    $('#toastTitle').text("Erro");
                    $('#toastMessage').text(response.message);
                    $('.toast').removeClass('bg-success').addClass('bg-danger text-white');
                    toast.show();
                }
            },
            error: function() {
                var toast = new bootstrap.Toast(document.getElementById('liveToast'));
                $('#toastTitle').text("Erro");
                $('#toastMessage').text("Ocorreu um erro ao processar sua solicitação.");
                $('.toast').removeClass('bg-success').addClass('bg-danger text-white');
                toast.show();
            },
            complete: function() {
                submitBtn.prop('disabled', false).html(originalText);
            }
        });
    });

    // Garante que o backdrop seja removido quando o modal é fechado
    $('#recuperarModal').on('hidden.bs.modal', function () {
        $('.modal-backdrop').not(':first').remove();
        $('body').removeClass('modal-open').css('padding-right', '');
    });

    // Validação de confirmação de senha
    $('input[name="confirmar_senha"]').on('keyup', function() {
        var senha = $('input[name="senha"]').val();
        var confirmar = $(this).val();
        
        if (senha !== confirmar) {
            $(this).addClass('is-invalid');
            $('input[name="senha"]').addClass('is-invalid');
        } else {
            $(this).removeClass('is-invalid');
            $('input[name="senha"]').removeClass('is-invalid');
        }
    });

    // Mostra mensagens da sessão
    <?php if(isset($_SESSION['mensagem'])): ?>
        var toast = new bootstrap.Toast(document.getElementById('liveToast'));
        $('#toastTitle').text("<?= addslashes($_SESSION['tipo_mensagem'] == 'success' ? 'Sucesso' : 'Erro') ?>");
        $('#toastMessage').text("<?= addslashes($_SESSION['mensagem']) ?>");
        $('.toast').addClass('bg-<?= $_SESSION['tipo_mensagem'] ?> text-white');
        toast.show();
        <?php unset($_SESSION['mensagem']); unset($_SESSION['tipo_mensagem']); ?>
    <?php endif; ?>
});
</script>

    <!-- Container principal (será fechado no footer) -->
    <main class="container my-4">