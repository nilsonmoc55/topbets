<?php
session_start();
require_once 'conexao.php';

// Verifica se os dados foram enviados
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $senha = $_POST['senha'];
    $lembrar = isset($_POST['lembrar']);
    $redirect = $_POST['redirect'] ?? 'index.php';

    // Busca usuário no banco
    $stmt = $conn->prepare("SELECT id, nome, email, senha, nivel_acesso FROM usuarios WHERE email = ? AND ativo = 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $usuario = $result->fetch_assoc();
        
        // Verifica a senha
        if (password_verify($senha, $usuario['senha'])) {
            // Autenticação bem-sucedida
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario_nome'] = $usuario['nome'];
            $_SESSION['usuario_email'] = $usuario['email'];
            $_SESSION['usuario_nivel'] = $usuario['nivel_acesso'];
            
            // Atualiza último login
            $conn->query("UPDATE usuarios SET ultimo_login = NOW() WHERE id = {$usuario['id']}");
            
            // Redireciona
            header("Location: $redirect");
            exit();
        }
    }

    // Se chegou aqui, a autenticação falhou
    $_SESSION['login_erro'] = "Email ou senha incorretos";
    header("Location: login.php?redirect=" . urlencode($redirect));
    exit();
}

header("Location: index.php");