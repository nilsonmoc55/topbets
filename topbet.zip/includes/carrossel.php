<?php
// Verifica se h� an�ncios para o carrossel
if ($destaques->num_rows > 0):
    // Configura��es do carrossel
    $id_carrossel = 'carrosselAnuncios';
    $intervalo = 5000; // 5 segundos entre os slides (ajuste conforme necess�rio)
?>
<div id="<?= $id_carrossel ?>" class="carousel slide mb-4" data-bs-ride="carousel" data-bs-interval="<?= $intervalo ?>">
    <!-- Indicadores -->
    <div class="carousel-indicators">
        <?php for ($i = 0; $i < $destaques->num_rows; $i++): ?>
            <button type="button" data-bs-target="#<?= $id_carrossel ?>" data-bs-slide-to="<?= $i ?>" <?= $i === 0 ? 'class="active" aria-current="true"' : '' ?> aria-label="Slide <?= $i + 1 ?>"></button>
        <?php endfor; ?>
    </div>
    
    <!-- Slides -->
    <div class="carousel-inner rounded-3">
        <?php 
        $contador = 0;
        while ($anuncio = $destaques->fetch_assoc()):
            $contador++;
            // Atualiza contador de impress�es
            $conn->query("UPDATE anuncios SET impressoes = impressoes + 1 WHERE id = {$anuncio['id']}");
        ?>
        <div class="carousel-item <?= $contador === 1 ? 'active' : '' ?>">
            <?php if ($anuncio['tipo'] === 'propio' && !empty($anuncio['imagem'])): ?>
                <!-- An�ncio pr�prio com imagem -->
                <a href="<?= $anuncio['url'] ?>?ref=topbets" target="_blank" onclick="registrarClique(<?= $anuncio['id'] ?>)">
                    <img src="uploads/anuncios/<?= $anuncio['imagem'] ?>" class="d-block w-100" alt="<?= htmlspecialchars($anuncio['titulo']) ?>">
                </a>
                <div class="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded">
                    <h5><?= htmlspecialchars($anuncio['titulo']) ?></h5>
                </div>
            <?php elseif ($anuncio['tipo'] === 'adsense' && !empty($anuncio['codigo'])): ?>
                <!-- An�ncio AdSense -->
                <div class="p-2 bg-light">
                    <?= htmlspecialchars_decode($anuncio['codigo']) ?>
                </div>
            <?php elseif (!empty($anuncio['codigo'])): ?>
                <!-- Outros tipos de an�ncio (HTML/JavaScript) -->
                <div class="p-2">
                    <?= htmlspecialchars_decode($anuncio['codigo']) ?>
                </div>
            <?php endif; ?>
        </div>
        <?php endwhile; ?>
    </div>
    
    <!-- Controles -->
    <button class="carousel-control-prev" type="button" data-bs-target="#<?= $id_carrossel ?>" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Anterior</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#<?= $id_carrossel ?>" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Pr�ximo</span>
    </button>
    
    <!-- Controles de play/pause -->
    <div class="carousel-controls">
        <button id="pauseCarousel" class="btn btn-sm btn-outline-light" title="Pausar">
            <i class="fas fa-pause"></i>
        </button>
        <button id="playCarousel" class="btn btn-sm btn-outline-light d-none" title="Reproduzir">
            <i class="fas fa-play"></i>
        </button>
    </div>
</div>

<script>
// Fun��o para registrar cliques nos an�ncios
function registrarClique(anuncioId) {
    fetch('includes/registrar_clique.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'anuncio_id=' + anuncioId
    }).catch(error => console.error('Erro ao registrar clique:', error));
}

// Controles de play/pause
document.addEventListener('DOMContentLoaded', function() {
    const carousel = new bootstrap.Carousel(document.getElementById('<?= $id_carrossel ?>'));
    const pauseBtn = document.getElementById('pauseCarousel');
    const playBtn = document.getElementById('playCarousel');
    
    // Pausar o carrossel
    pauseBtn.addEventListener('click', function() {
        carousel.pause();
        pauseBtn.classList.add('d-none');
        playBtn.classList.remove('d-none');
    });
    
    // Retomar o carrossel
    playBtn.addEventListener('click', function() {
        carousel.cycle();
        playBtn.classList.add('d-none');
        pauseBtn.classList.remove('d-none');
    });
    
    // Pausar quando o mouse estiver sobre o carrossel
    const carouselElement = document.getElementById('<?= $id_carrossel ?>');
    carouselElement.addEventListener('mouseenter', function() {
        carousel.pause();
    });
    
    // Retomar quando o mouse sair do carrossel
    carouselElement.addEventListener('mouseleave', function() {
        carousel.cycle();
    });
});
</script>

<style>
.carousel {
    max-height: 400px;
    overflow: hidden;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    position: relative;
}

.carousel-inner img {
    object-fit: cover;
    width: 100%;
    max-height: 400px;
}

.carousel-caption {
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    width: auto;
    padding: 10px 20px;
}

.carousel-controls {
    position: absolute;
    bottom: 10px;
    right: 10px;
    z-index: 10;
}

@media (max-width: 768px) {
    .carousel, .carousel-inner img {
        max-height: 250px;
    }
    
    .carousel-controls {
        bottom: 5px;
        right: 5px;
    }
    
    .carousel-controls .btn {
        padding: 0.25rem 0.5rem;
        font-size: 0.8rem;
    }
}
</style>
<?php endif; ?>