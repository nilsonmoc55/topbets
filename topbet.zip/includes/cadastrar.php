<?php
session_start();
require_once 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $senha = $_POST['senha'];
    
    // Verifica se email já existe
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    
    if ($stmt->get_result()->num_rows > 0) {
        $_SESSION['cadastro_erro'] = "Email já cadastrado";
        header("Location: cadastro.php");
        exit();
    }
    
    // Cria hash da senha
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
    
    // Insere novo usuário
    $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, data_cadastro) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("sss", $nome, $email, $senhaHash);
    
    if ($stmt->execute()) {
        $_SESSION['cadastro_sucesso'] = "Cadastro realizado com sucesso! Faça login para continuar.";
        header("Location: login.php");
    } else {
        $_SESSION['cadastro_erro'] = "Erro ao cadastrar. Tente novamente mais tarde.";
        header("Location: cadastro.php");
    }
    exit();
}

header("Location: index.php");