<?php
require_once __DIR__ . '/../includes/conexao.php';

// Verifica se deve exibir apenas bets específicas (filtro opcional)
$filtro_categoria = isset($_GET['categoria']) ? $_GET['categoria'] : null;

// Consulta principal das bets
$sql_bets = "SELECT * FROM bets WHERE ativo = 1";

// Aplica filtro se existir
if ($filtro_categoria && in_array($filtro_categoria, ['esportes', 'casino', 'poker'])) {
    $sql_bets .= " AND categoria = '" . $conn->real_escape_string($filtro_categoria) . "'";
}

// Verifica se a coluna media_nota existe para ordenação
$result = $conn->query("SHOW COLUMNS FROM bets LIKE 'media_nota'");
if ($result->num_rows > 0) {
    $sql_bets .= " ORDER BY media_nota DESC";
} else {
    $sql_bets .= " ORDER BY nome ASC"; // Ordem padrão se não houver media_nota
}

$bets = $conn->query($sql_bets);

// Função para exibir anúncios
function exibirAnuncio($conn, $posicao) {
    $sql_anuncio = "SELECT * FROM anuncios 
                   WHERE posicao = ? 
                   AND ativo = 1 
                   AND (data_inicio IS NULL OR data_inicio <= NOW()) 
                   AND (data_fim IS NULL OR data_fim >= NOW())
                   ORDER BY RAND() LIMIT 1";
    
    $stmt = $conn->prepare($sql_anuncio);
    $stmt->bind_param("s", $posicao);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return null;
}
?>

<section class="lista-bets py-5">
    <div class="container">
        <!-- Filtros de Categoria -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="btn-group" role="group">
                    <a href="?categoria=all" class="btn btn-outline-primary <?= !$filtro_categoria || $filtro_categoria === 'all' ? 'active' : '' ?>">
                        Todas
                    </a>
                    <a href="?categoria=esportes" class="btn btn-outline-primary <?= $filtro_categoria === 'esportes' ? 'active' : '' ?>">
                        Esportes
                    </a>
                    <a href="?categoria=casino" class="btn btn-outline-primary <?= $filtro_categoria === 'casino' ? 'active' : '' ?>">
                        Casino
                    </a>
                    <a href="?categoria=poker" class="btn btn-outline-primary <?= $filtro_categoria === 'poker' ? 'active' : '' ?>">
                        Poker
                    </a>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <?php 
            $contador = 0;
            if ($bets && $bets->num_rows > 0):
                while ($bet = $bets->fetch_assoc()): 
                    $contador++;
            ?>
                    <!-- Card de Bet -->
                    <div class="col-md-6 col-lg-4">
                        <div class="card bet-card h-100 shadow-sm">
                            <div class="card-header bg-primary text-white">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0"><?= htmlspecialchars($bet['nome'] ?? 'Nome não disponível') ?></h5>
                                    <span class="badge bg-warning text-dark">
                                        <i class="fas fa-coins"></i> Bônus: <?= htmlspecialchars($bet['bonus'] ?? 'N/A') ?>
                                    </span>
                                </div>
                            </div>
                            <div class="card-body d-flex flex-column">
                                <div class="text-center mb-3 flex-grow-0">
                                    <?php if (!empty($bet['logo'])): ?>
                                        <img src="<?= htmlspecialchars($bet['logo']) ?>" 
                                             alt="<?= htmlspecialchars($bet['nome'] ?? 'Logo') ?>" 
                                             class="img-fluid bet-logo" 
                                             style="max-height: 60px; max-width: 200px;">
                                    <?php else: ?>
                                        <div class="no-logo-placeholder bg-secondary text-white p-2 rounded">
                                            <i class="fas fa-image fa-2x"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if (isset($bet['media_nota'])): ?>
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div class="rating">
                                        <?= str_repeat('⭐', min(5, round($bet['media_nota'] ?? 0))) ?>
                                        <span class="text-muted">(<?= number_format($bet['media_nota'] ?? 0, 1) ?>/5)</span>
                                    </div>
                                    <small class="text-muted"><?= (int)($bet['total_avaliacoes'] ?? 0) ?> avaliações</small>
                                </div>
                                <?php endif; ?>

                                <div class="mt-auto">
                                    <div class="btn-group w-100 mb-2">
                                        <a href="ver-avaliacoes.php?bet_id=<?= (int)$bet['id'] ?>" 
                                           class="btn btn-outline-primary">
                                            <i class="fas fa-list me-1"></i> Avaliações
                                        </a>
                                        <button type="button" 
                                                class="btn btn-success" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#modalAvaliar"
                                                data-bet-id="<?= (int)$bet['id'] ?>">
                                            <i class="fas fa-edit me-1"></i> Avaliar
                                        </button>
                                    </div>

                                    <?php if (isset($bet['url'])): ?>
                                    <a href="<?= htmlspecialchars($bet['url'] ?? '#') ?>" 
                                       target="_blank" 
                                       rel="noopener noreferrer" 
                                       class="btn btn-outline-secondary w-100">
                                        <i class="fas fa-external-link-alt me-1"></i> Visitar Site
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Exibe anúncio a cada 3 bets -->
                    <?php if ($contador % 3 == 0): ?>
                        <div class="col-12 my-3">
                            <?php $anuncio = exibirAnuncio($conn, 'entre_posts'); ?>
                            <?php if ($anuncio): ?>
                                <div class="anuncio-entre-posts text-center p-3 border rounded bg-light">
                                    <?php if ($anuncio['tipo'] == 'propio' && !empty($anuncio['imagem'])): ?>
                                        <a href="<?= htmlspecialchars($anuncio['url'] ?? '#') ?>" 
                                           target="_blank" 
                                           rel="nofollow noopener noreferrer">
                                            <img src="<?= htmlspecialchars($anuncio['imagem']) ?>" 
                                                 alt="Anúncio" 
                                                 class="img-fluid" 
                                                 style="max-height: 90px;">
                                        </a>
                                        <?php if (!empty($anuncio['url'])): ?>
                                            <div class="mt-2">
                                                <a href="<?= htmlspecialchars($anuncio['url']) ?>" 
                                                   target="_blank" 
                                                   rel="nofollow noopener noreferrer" 
                                                   class="btn btn-sm btn-primary">
                                                    Saiba mais
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    <?php elseif (!empty($anuncio['codigo'])): ?>
                                        <?= htmlspecialchars_decode($anuncio['codigo']) ?>
                                    <?php else: ?>
                                        <div class="p-2 bg-light text-muted">
                                            <small>Espaço reservado para anúncio</small>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-info text-center">
                        Nenhuma bet encontrada. <?= $filtro_categoria ? "Tente remover os filtros." : "" ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Modal de Avaliação -->
<div class="modal fade" id="modalAvaliar" tabindex="-1" aria-labelledby="modalAvaliarLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="modalAvaliarLabel">Avaliar Bet</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="modalAvaliarBody">
                <div class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Carregando...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Carrega o formulário de avaliação via AJAX
document.getElementById('modalAvaliar').addEventListener('show.bs.modal', function (event) {
    const button = event.relatedTarget;
    const betId = button.getAttribute('data-bet-id');
    const modalBody = document.getElementById('modalAvaliarBody');
    
    fetch(carregar-form-avaliacao.php?bet_id=${betId})
        .then(response => response.text())
        .then(html => {
            modalBody.innerHTML = html;
            initFormValidation();
        })
        .catch(error => {
            modalBody.innerHTML = 
                <div class="alert alert-danger">
                    Erro ao carregar formulário. Por favor, tente novamente.
                </div>
                <button class="btn btn-secondary" data-bs-dismiss="modal">
                    Fechar
                </button>
            ;
        });
});

// Função para validar o formulário
function initFormValidation() {
    const form = document.getElementById('form-avaliacao');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const submitBtn = form.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.innerHTML = 
                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                Enviando...
            ;
            
            fetch('salvar-avaliacao.php', {
                method: 'POST',
                body: new FormData(form)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    modalBody.innerHTML = 
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i> ${data.message}
                        </div>
                        <div class="text-center">
                            <button class="btn btn-primary" data-bs-dismiss="modal">
                                Fechar
                            </button>
                        </div>
                    ;
                } else {
                    modalBody.innerHTML = 
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle"></i> ${data.message}
                        </div>
                        <button class="btn btn-secondary" onclick="window.location.reload()">
                            Recarregar
                        </button>
                    ;
                }
            })
            .catch(error => {
                modalBody.innerHTML = 
                    <div class="alert alert-danger">
                        Erro na comunicação com o servidor
                    </div>
                    <button class="btn btn-secondary" data-bs-dismiss="modal">
                        Fechar
                    </button>
                ;
            });
        });
    }
}
</script>