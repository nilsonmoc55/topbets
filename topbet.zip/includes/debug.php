<?php
// debug.php - Coloque este arquivo na raiz do seu projeto
define('DEBUG_MODE', true);

if (DEBUG_MODE) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    
    // Log personalizado
    function log_debug($message, $data = null) {
        $log = "[" . date('Y-m-d H:i:s') . "] " . $message . PHP_EOL;
        if ($data) {
            $log .= "Dados: " . print_r($data, true) . PHP_EOL;
        }
        file_put_contents(__DIR__ . '/debug.log', $log, FILE_APPEND);
    }
    
    // Inicia o log
    file_put_contents(__DIR__ . '/debug.log', "----- INÍCIO DA SESSÃO DE DEBUG -----" . PHP_EOL, FILE_APPEND);
    register_shutdown_function(function() {
        file_put_contents(__DIR__ . '/debug.log', "----- FIM DA SESSÃO DE DEBUG -----" . PHP_EOL . PHP_EOL, FILE_APPEND);
    });
}

// Inclua este arquivo no início de todos os seus scripts PHP
require_once __DIR__ . '/debug.php';