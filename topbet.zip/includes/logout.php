<?php
// logout.php
require 'includes/conexao.php';

session_start();

// Registra o logout
if (isset($_SESSION['usuario_id'])) {
    $sql = "INSERT INTO logs_acesso (usuario_id, acao) VALUES (?, 'logout')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $_SESSION['usuario_id']);
    $stmt->execute();
}

// Limpa a sessão
session_unset();
session_destroy();

// Redireciona com mensagem
$_SESSION['mensagem'] = "Você foi desconectado com sucesso";
header("Location: index.php");
exit();
?>