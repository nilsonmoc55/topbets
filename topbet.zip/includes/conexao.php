<?php
// includes/conexao.php

if (!function_exists('init_session')) {
    function init_session() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start([
                'cookie_lifetime' => 86400,
                'cookie_secure'   => isset($_SERVER['HTTPS']),
                'cookie_httponly' => true,
                'use_strict_mode' => true
            ]);

            if (empty($_SESSION['csrf_token'])) {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            }
        }
    }
}

// ==============================================
// CLASSE DE CONEX�O COM PROTE��O - VERS�O ATUALIZADA
// ==============================================

if (!class_exists('Database')) {
    class Database {
        private static $instance = null;
        private $connection;
        
        // Vari�vel global $conn para compatibilidade
        public static $conn = null;

        private function __construct() {
            $config = [
                'host'    => 'sql108.infinityfree.com',
                'user'    => 'if0_37772770',
                'pass'    => '1ZE9JByJ9ULbv',
                'name'    => 'if0_37772770_bt',
                'charset' => 'utf8mb4',
                'port'    => 3306
            ];

            try {
                $this->connection = new mysqli(
                    $config['host'],
                    $config['user'],
                    $config['pass'],
                    $config['name'],
                    $config['port']
                );

                if ($this->connection->connect_error) {
                    throw new Exception("Erro de conex�o: " . $this->connection->connect_error);
                }

                $this->connection->set_charset($config['charset']);
                $this->connection->options(MYSQLI_OPT_INT_AND_FLOAT_NATIVE, true);
                
                // Atribui � vari�vel global para compatibilidade
                self::$conn = $this->connection;

            } catch (Exception $e) {
                error_log("[DB Error] " . date('Y-m-d H:i:s') . " - " . $e->getMessage());
                die("Sistema temporariamente indispon�vel. Por favor, tente novamente mais tarde.");
            }
        }

        public static function getInstance() {
            if (!self::$instance) {
                self::$instance = new Database();
            }
            return self::$instance->connection;
        }
        
        // M�todo para obter a conex�o global
        public static function getGlobalConnection() {
            if (!self::$conn) {
                self::getInstance(); // For�a a cria��o da conex�o
            }
            return self::$conn;
        }
    }
}

// ==============================================
// INICIALIZA��O E COMPATIBILIDADE
// ==============================================

// Inicializa a conex�o automaticamente
Database::getInstance();

// Cria a vari�vel global $conn para compatibilidade com c�digo legado
$conn = Database::getGlobalConnection();

// Verifica��o final da conex�o
if (!$conn || $conn->connect_error) {
    error_log("Falha cr�tica: N�o foi poss�vel estabelecer conex�o com o banco de dados");
    die("Servi�o temporariamente indispon�vel. Estamos trabalhando para resolver o problema.");
}
?>