document.addEventListener('DOMContentLoaded', function() {
    // Quando clica em qualquer botão "Avaliar"
    document.querySelectorAll('.btn-avaliar').forEach(btn => {
        btn.addEventListener('click', function() {
            const betData = {
                id: this.dataset.betId,
                nome: this.dataset.betNome
            };
            
            // Armazena temporariamente a bet selecionada
            sessionStorage.setItem('betAvaliacao', JSON.stringify(betData));
            
            // Mostra o modal de verificação
            const modal = new bootstrap.Modal(document.getElementById('verificaLoginModal'));
            modal.show();
        });
    });

    // Recupera dados ao carregar a página
    if (sessionStorage.getItem('betAvaliacao')) {
        const betData = JSON.parse(sessionStorage.getItem('betAvaliacao'));
        document.getElementById('verificaLoginModal').querySelector('.modal-title')
            .textContent = "Avaliar: " + betData.nome;
    }
});