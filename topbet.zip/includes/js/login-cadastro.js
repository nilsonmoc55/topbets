document.addEventListener('DOMContentLoaded', function() {
    // Controle do formulário de login
    const formLogin = document.getElementById('formLogin');
    if (formLogin) {
        formLogin.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Simulação de autenticação (substituir por AJAX real)
            const email = document.getElementById('loginEmail').value;
            const senha = document.getElementById('loginSenha').value;
            
            fetch('includes/autenticar.php', {
                method: 'POST',
                body: new FormData(formLogin)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = data.redirect || 'index.php';
                } else {
                    document.getElementById('loginErro').classList.remove('d-none');
                }
            });
        });
    }

    // Link "Esqueceu a senha"
    const esqueciSenha = document.getElementById('esqueciSenha');
    if (esqueciSenha) {
        esqueciSenha.addEventListener('click', function(e) {
            e.preventDefault();
            bootstrap.Modal.getInstance(document.getElementById('modalLogin')).hide();
            new bootstrap.Modal(document.getElementById('modalRecuperarSenha')).show();
        });
    }

    // Validação do formulário de cadastro
    const formCadastro = document.getElementById('formCadastro');
    if (formCadastro) {
        const senha = document.getElementById('cadSenha');
        const confirmaSenha = document.getElementById('cadConfirmaSenha');
        
        confirmaSenha.addEventListener('input', function() {
            if (confirmaSenha.value !== senha.value) {
                confirmaSenha.classList.add('is-invalid');
            } else {
                confirmaSenha.classList.remove('is-invalid');
            }
        });
        
        formCadastro.addEventListener('submit', function(e) {
            if (confirmaSenha.value !== senha.value) {
                e.preventDefault();
                confirmaSenha.classList.add('is-invalid');
            }
            
            // Verificação de email via AJAX
            const email = document.getElementById('cadEmail').value;
            fetch('includes/verifica-email.php?email=' + encodeURIComponent(email))
                .then(response => response.json())
                .then(data => {
                    if (data.exists) {
                        document.getElementById('cadEmail').classList.add('is-invalid');
                        e.preventDefault();
                    }
                });
        });
    }
});