<section class="filtros mb-4">
    <div class="container">
        <div class="row g-3">
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-sort"></i></span>
                    <select class="form-select" id="ordenar">
                        <option value="melhor" <?= $ordenacao == 'melhor' ? 'selected' : '' ?>>Melhor Pontuação</option>
                        <option value="pior" <?= $ordenacao == 'pior' ? 'selected' : '' ?>>Pior Pontuação</option>
                        <option value="melhor-bonus" <?= $ordenacao == 'melhor-bonus' ? 'selected' : '' ?>>Melhores Bônus</option>
                        <option value="pior-bonus" <?= $ordenacao == 'pior-bonus' ? 'selected' : '' ?>>Piores Bônus</option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text"><i class="fas fa-gift"></i></span>
                    <select class="form-select" id="filtro-bonus">
                        <option value="todos" <?= $filtro_bonus == 'todos' ? 'selected' : '' ?>>Todos</option>
                        <option value="com-bonus" <?= $filtro_bonus == 'com-bonus' ? 'selected' : '' ?>>Com Bônus</option>
                        <option value="sem-bonus" <?= $filtro_bonus == 'sem-bonus' ? 'selected' : '' ?>>Sem Bônus</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
</section>