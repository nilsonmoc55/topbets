<?php
require 'includes/conexao.php';
session_start();

// Mostrar erros visíveis na tela
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Inicializa mensagens
$mensagem = '';
$erros = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $confirmar_senha = $_POST['confirmar_senha'] ?? '';
    $termos = isset($_POST['termos']);

    // Validações
    if (empty($nome)) {
        $erros[] = "Informe seu nome.";
    } elseif (preg_match('/[0-9]/', $nome)) {
        $erros[] = "O nome não pode conter números.";
    }

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erros[] = "Informe um e-mail válido.";
    }

    if (empty($senha) || strlen($senha) < 6) {
        $erros[] = "A senha deve ter no mínimo 6 caracteres.";
    }

    if ($senha !== $confirmar_senha) {
        $erros[] = "As senhas não coincidem.";
    }

    if (!$termos) {
        $erros[] = "Você deve aceitar os termos.";
    }

    // Verifica duplicidade
    if (empty($erros)) {
        $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $erros[] = "Este e-mail já está cadastrado.";
        }
        $stmt->close();
    }

    // Se estiver tudo certo, insere no banco
    if (empty($erros)) {
        $senha_hash = password_hash($senha, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $nome, $email, $senha_hash);
        if ($stmt->execute()) {
            $mensagem = "Cadastro realizado com sucesso!";
        } else {
            $erros[] = "Erro ao cadastrar: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cadastro de Usuário</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f5f5f5; }
        .erro { color: red; }
        .sucesso { color: green; }
        form { background: #fff; padding: 20px; border-radius: 8px; max-width: 400px; margin: auto; }
        label { display: block; margin-top: 10px; }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%; padding: 8px; margin-top: 5px;
        }
        button { margin-top: 15px; padding: 10px 20px; }
    </style>
</head>
<body>

<?php if (!empty($mensagem)): ?>
    <p class="sucesso"><?= $mensagem ?></p>
<?php endif; ?>

<?php if (!empty($erros)): ?>
    <div class="erro">
        <ul>
            <?php foreach ($erros as $erro): ?>
                <li><?= $erro ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="POST" action="">
    <label>Nome:</label>
    <input type="text" name="nome" required>

    <label>Email:</label>
    <input type="email" name="email" required>

    <label>Senha:</label>
    <input type="password" name="senha" required>

    <label>Confirmar Senha:</label>
    <input type="password" name="confirmar_senha" required>

    <label>
        <input type="checkbox" name="termos"> Aceito os termos
    </label>

    <button type="submit">Cadastrar</button>
</form>

</body>
</html>
