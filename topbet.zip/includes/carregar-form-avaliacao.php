<?php
require_once __DIR__ . '/../includes/conexao.php';

header('Content-Type: text/html; charset=utf-8');

// Verifica se o bet_id foi passado
$bet_id = isset($_GET['bet_id']) ? (int)$_GET['bet_id'] : 0;

if ($bet_id <= 0) {
    die('<div class="alert alert-danger">ID da Bet inválido</div>');
}

// Busca informações da bet
$bet = $conn->query("SELECT id, nome FROM bets WHERE id = $bet_id");
if ($bet->num_rows === 0) {
    die('<div class="alert alert-danger">Bet não encontrada</div>');
}
$bet = $bet->fetch_assoc();

// Busca campos ativos do formulário
$campos = $conn->query("SELECT * FROM formulario_campos WHERE ativo = 1 ORDER BY ordem ASC");
?>

<form method="POST" action="salvar-avaliacao.php" id="form-avaliacao">
    <input type="hidden" name="bet_id" value="<?= $bet_id ?>">

    <div class="mb-4">
        <h5 class="border-bottom pb-2">Avaliando: <?= htmlspecialchars($bet['nome']) ?></h5>

        <!-- Identificação do avaliador -->
        <div class="row g-3 mb-3">
            <div class="col-md-6">
                <label class="form-label">Seu Nome*</label>
                <input type="text" name="nome_avaliador" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Seu E-mail*</label>
                <input type="email" name="email_avaliador" class="form-control" required>
            </div>
        </div>

        <!-- Campos fixos personalizados -->
        <div class="mb-3">
            <label class="form-label">Facilidade para depositar</label>
            <select name="deposito_facilidade" class="form-select" required>
                <option value="">Selecione...</option>
                <option value="Muito fácil">Muito fácil</option>
                <option value="Fácil">Fácil</option>
                <option value="Difícil">Difícil</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Tempo de saque</label>
            <select name="tempo_saque" class="form-select" required>
                <option value="">Selecione...</option>
                <option value="Instantâneo">Instantâneo</option>
                <option value="Menos de 24h">Menos de 24h</option>
                <option value="1 a 3 dias">1 a 3 dias</option>
                <option value="Mais de 3 dias">Mais de 3 dias</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Já teve problemas para sacar?</label>
            <select name="problemas_saque" class="form-select" required>
                <option value="">Selecione...</option>
                <option value="Não">Não</option>
                <option value="Sim">Sim</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Variedade de apostas</label>
            <select name="variedade_apostas" class="form-select" required>
                <option value="">Selecione...</option>
                <option value="Excelente">Excelente</option>
                <option value="Boa">Boa</option>
                <option value="Ruim">Ruim</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">O site/aplicativo funciona bem?</label>
            <select name="funciona_bem" class="form-select" required>
                <option value="">Selecione...</option>
                <option value="Sim, sem erros">Sim, sem erros</option>
                <option value="Com alguns travamentos">Com alguns travamentos</option>
                <option value="Com muitos problemas">Com muitos problemas</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">O site/app é fácil de usar?</label>
            <select name="facilidade_uso" class="form-select" required>
                <option value="">Selecione...</option>
                <option value="Muito fácil">Muito fácil</option>
                <option value="Razoável">Razoável</option>
                <option value="Difícil">Difícil</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Já precisou de suporte?</label>
            <select name="precisou_suporte" class="form-select" required>
                <option value="">Selecione...</option>
                <option value="Sim">Sim</option>
                <option value="Não">Não</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Avalie o suporte (1 a 5)</label>
            <input type="number" name="nota_suporte" class="form-control" min="1" max="5">
        </div>

        <div class="mb-3">
            <label class="form-label">Recebeu o bônus de cadastro?</label>
            <select name="bonus_recebido" class="form-select" required>
                <option value="">Selecione...</option>
                <option value="Sim">Sim</option>
                <option value="Não">Não</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">As promoções foram claras e justas?</label>
            <select name="promocoes_claras" class="form-select" required>
                <option value="">Selecione...</option>
                <option value="Sim">Sim</option>
                <option value="Mais ou menos">Mais ou menos</option>
                <option value="Não">Não</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Você se sentiu seguro usando essa plataforma?</label>
            <select name="seguranca_sentida" class="form-select" required>
                <option value="">Selecione...</option>
                <option value="Sim">Sim</option>
                <option value="Mais ou menos">Mais ou menos</option>
                <option value="Não">Não</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Nota geral (0 a 10)</label>
            <input type="number" name="nota_geral" class="form-control" min="0" max="10" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Comentário adicional</label>
            <textarea name="comentario_livre" class="form-control" rows="4" placeholder="Conte mais sobre sua experiência..."></textarea>
        </div>

        <!-- Campos dinâmicos adicionais -->
        <?php if ($campos->num_rows > 0): ?>
            <?php while($campo = $campos->fetch_assoc()): ?>
                <div class="mb-3">
                    <label class="form-label">
                        <?= htmlspecialchars($campo['rotulo']) ?>
                        <?= $campo['obrigatorio'] ? '<span class="text-danger">*</span>' : '' ?>
                    </label>

                    <?php switch($campo['tipo']):
                        case 'text': ?>
                            <input type="text" name="campos[<?= $campo['nome_campo'] ?>]" 
                                   class="form-control" <?= $campo['obrigatorio'] ? 'required' : '' ?>>
                            <?php break; ?>

                        case 'number': ?>
                            <input type="number" name="campos[<?= $campo['nome_campo'] ?>]" 
                                   class="form-control" <?= $campo['obrigatorio'] ? 'required' : '' ?>>
                            <?php break; ?>

                        case 'email': ?>
                            <input type="email" name="campos[<?= $campo['nome_campo'] ?>]" 
                                   class="form-control" <?= $campo['obrigatorio'] ? 'required' : '' ?>>
                            <?php break; ?>

                        case 'textarea': ?>
                            <textarea name="campos[<?= $campo['nome_campo'] ?>]" class="form-control"
                                      <?= $campo['obrigatorio'] ? 'required' : '' ?>></textarea>
                            <?php break; ?>

                        case 'select': 
                            $opcoes = json_decode($campo['opcoes'], true); ?>
                            <select name="campos[<?= $campo['nome_campo'] ?>]" class="form-select"
                                    <?= $campo['obrigatorio'] ? 'required' : '' ?>>
                                <option value="">Selecione...</option>
                                <?php foreach($opcoes as $opcao): ?>
                                    <option value="<?= htmlspecialchars($opcao) ?>"><?= htmlspecialchars($opcao) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <?php break; ?>

                        case 'checkbox': 
                            $opcoes = json_decode($campo['opcoes'], true); ?>
                            <div class="form-group">
                                <?php foreach($opcoes as $opcao): ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" 
                                               name="campos[<?= $campo['nome_campo'] ?>][]" 
                                               value="<?= htmlspecialchars($opcao) ?>"
                                               id="check_<?= $campo['id'] ?>_<?= md5($opcao) ?>">
                                        <label class="form-check-label" for="check_<?= $campo['id'] ?>_<?= md5($opcao) ?>">
                                            <?= htmlspecialchars($opcao) ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <?php break; ?>

                        case 'radio': 
                            $opcoes = json_decode($campo['opcoes'], true); ?>
                            <div class="form-group">
                                <?php foreach($opcoes as $opcao): ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" 
                                               name="campos[<?= $campo['nome_campo'] ?>]" 
                                               value="<?= htmlspecialchars($opcao) ?>"
                                               id="radio_<?= $campo['id'] ?>_<?= md5($opcao) ?>"
                                               <?= $campo['obrigatorio'] ? 'required' : '' ?>>
                                        <label class="form-check-label" for="radio_<?= $campo['id'] ?>_<?= md5($opcao) ?>">
                                            <?= htmlspecialchars($opcao) ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <?php break; ?>
                    <?php endswitch; ?>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="alert alert-info">Nenhum campo adicional configurado</div>
        <?php endif; ?>
    </div>

    <div class="d-grid gap-2">
        <button type="submit" class="btn btn-primary btn-lg">
            <i class="fas fa-paper-plane"></i> Enviar Avaliação
        </button>
    </div>
</form>
