<?php
require_once '../includes/conexao.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../index.php");
    exit;
}

// Validação básica
$requiredFields = ['bet_id', 'nota', 'comentario_geral'];
foreach ($requiredFields as $field) {
    if (empty($_POST[$field])) {
        header("Location: ../index.php?erro=campos_obrigatorios");
        exit;
    }
}

// Preparar dados
$bet_id = intval($_POST['bet_id']);
$usuario_id = isset($_SESSION['usuario_id']) ? intval($_SESSION['usuario_id']) : null;
$nome_avaliador = !empty($_POST['nome_avaliador']) ? $conn->real_escape_string($_POST['nome_avaliador']) : null;
$email_avaliador = !empty($_POST['email_avaliador']) ? $conn->real_escape_string($_POST['email_avaliador']) : null;
$nota = floatval($_POST['nota']);
$comentario_geral = $conn->real_escape_string($_POST['comentario_geral']);

// Campos opcionais
$tem_bonus = isset($_POST['tem_bonus']) ? intval($_POST['tem_bonus']) : 0;
$usou_bonus = isset($_POST['usou_bonus']) ? intval($_POST['usou_bonus']) : null;
$bonus = isset($_POST['bonus']) ? floatval($_POST['bonus']) : 0.00;
$bonus_comentario = isset($_POST['bonus_comentario']) ? $conn->real_escape_string($_POST['bonus_comentario']) : null;
$tem_promocoes = isset($_POST['tem_promocoes']) ? intval($_POST['tem_promocoes']) : 0;
$deposito_nota = isset($_POST['deposito_nota']) ? intval($_POST['deposito_nota']) : null;
$saque_nota = isset($_POST['saque_nota']) ? intval($_POST['saque_nota']) : null;
$saque_comentario = isset($_POST['saque_comentario']) ? $conn->real_escape_string($_POST['saque_comentario']) : null;
$suporte_nota = isset($_POST['suporte_nota']) ? intval($_POST['suporte_nota']) : null;
$jogos_faceis = isset($_POST['jogos_faceis']) ? intval($_POST['jogos_faceis']) : 0;
$comentario_adicional = isset($_POST['comentario_adicional']) ? $conn->real_escape_string($_POST['comentario_adicional']) : null;

// Inserir no banco
$sql = "INSERT INTO avaliacoes (
    bet_id, usuario_id, nome_avaliador, email_avaliador, nota, comentario_geral,
    tem_bonus, usou_bonus, bonus, bonus_comentario, tem_promocoes,
    deposito_nota, saque_nota, saque_comentario, suporte_nota,
    jogos_faceis, comentario_adicional, status
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pendente')";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "iissdsiidssiiisiss",
    $bet_id, $usuario_id, $nome_avaliador, $email_avaliador, $nota, $comentario_geral,
    $tem_bonus, $usou_bonus, $bonus, $bonus_comentario, $tem_promocoes,
    $deposito_nota, $saque_nota, $saque_comentario, $suporte_nota,
    $jogos_faceis, $comentario_adicional
);

if ($stmt->execute()) {
    header("Location: ../bets/ver.php?id=$bet_id&sucesso=avaliacao_enviada");
} else {
    header("Location: ../bets/ver.php?id=$bet_id&erro=erro_avaliacao");
}

$stmt->close();
$conn->close();