$(document).ready(function() {
  $('#formCadastro').on('submit', function(e) {
    e.preventDefault();
    const form = $(this);
    const btnSubmit = $('#btnSubmitCadastro');

    // Reset estados
    form.find('.is-invalid').removeClass('is-invalid');
    $('#cadastroError').addClass('d-none');
    $('#emailCadastradoMsg').addClass('d-none');

    // Validações
    let isValid = true;

    // Validação de e-mail
    const email = $('#cadastroEmail').val();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!email || !emailRegex.test(email)) {
      $('#cadastroEmail').addClass('is-invalid');
      $('#emailFeedback').text('Por favor, insira um e-mail válido');
      isValid = false;
    }

    if ($('#cadastroSenha').val().length < 6) {
      $('#cadastroSenha').addClass('is-invalid');
      isValid = false;
    }

    if ($('#cadastroSenha').val() !== $('#cadastroConfirmarSenha').val()) {
      $('#cadastroConfirmarSenha').addClass('is-invalid');
      isValid = false;
    }

    if (!$('#termosCheck').is(':checked')) {
      $('#termosCheck').addClass('is-invalid');
      isValid = false;
    }

    if (!isValid) {
      $('#cadastroErrorMessage').text('Por favor, corrija os campos destacados');
      $('#cadastroError').removeClass('d-none');
      return;
    }

    // Desabilita o botão durante o envio
    btnSubmit.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-2"></i> Cadastrando...');

    // Envia os dados
    $.ajax({
      url: 'includes/cadastro.php',
      type: 'POST',
      data: form.serialize(),
      dataType: 'json',
      success: function(response) {
        if (response.success) {
          // Fecha o modal de cadastro
          $('#modalAvaliacao').modal('hide');

          // Atualiza a sessão no front-end (se necessário)
          if (response.usuario) {
            // Atualize a interface com os dados do usuário, se quiser
          }

          // Abre o formulário de avaliação depois de 300ms
          setTimeout(() => {
            $('#modalAvaliacaoContent').load('includes/modais/steps/step-formulario-avaliacao.php', {
              id: form.find('input[name="bet_id"]').val(),
              nome: form.find('input[name="bet_nome"]').val(),
              anonimo: 0
            }, function() {
              $('#modalAvaliacao').modal('show');
            });
          }, 300);
        } else {
          $('#cadastroErrorMessage').text(response.message || 'Erro no cadastro');
          $('#cadastroError').removeClass('d-none');

          if (response.message && response.message.includes('já está cadastrado')) {
            $('#emailCadastradoMsg').removeClass('d-none');
          }
        }
      },
      error: function() {
        $('#cadastroErrorMessage').text('Erro ao conectar com o servidor');
        $('#cadastroError').removeClass('d-none');
      },
      complete: function() {
        btnSubmit.prop('disabled', false).html('<i class="fas fa-user-plus me-2"></i> Cadastrar');
      }
    });
  });
});
