// Verificação em tempo real do e-mail
document.getElementById('formCadastro')?.addEventListener('input', async function(e) {
    if (e.target.name === 'email') {
        const email = e.target.value;
        const emailError = document.getElementById('emailError');
        
        if (email.length > 3 && email.includes('@')) {
            const existe = await verificarEmailExistente(email);
            if (existe) {
                emailError.textContent = "Este e-mail já está cadastrado!";
                emailError.style.display = 'block';
                document.getElementById('emailHelp').textContent = "Quer fazer login ou recuperar senha?";
            } else {
                emailError.style.display = 'none';
                document.getElementById('emailHelp').textContent = "";
            }
        } else {
            emailError.style.display = 'none';
        }
    }
});

// Manipulador do formulário de cadastro atualizado
document.getElementById('formCadastro')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const form = e.target;
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    
    // Mostra loading
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Cadastrando...';

    try {
        const response = await fetch(form.action, {
            method: 'POST',
            body: new FormData(form)
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Fecha o modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('cadastroModal'));
            modal.hide();
            
            // Mostra toast de sucesso
            const toast = new bootstrap.Toast(document.getElementById('cadastroSucessoToast'));
            toast.show();
            
            // Atualiza a página após 3 segundos
            setTimeout(() => {
                window.location.reload();
            }, 3000);
        } else {
            // Exibe erros no formulário
            if (data.message.includes('e-mail')) {
                document.getElementById('emailError').textContent = data.message;
                document.getElementById('emailError').style.display = 'block';
            } else {
                alert(data.message);
            }
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao processar cadastro');
    } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
    }
	// Quando o modal de recuperação é aberto, preenche com o e-mail se existir
$('#recuperarModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget); // Botão que acionou o modal
    var email = button.data('email'); // Extrai informação do atributo data-email
    if (email) {
        $('#emailRecuperacaoInput').val(email);
    }
});