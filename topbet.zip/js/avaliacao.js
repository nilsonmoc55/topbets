// Controle do fluxo de avaliação
const AvaliacaoFlow = {
    currentStep: null,
    
    init: function() {
        // Botão principal que abre o modal
        document.querySelector('[data-bs-target="#modalAvaliacao"]')?.addEventListener('click', () => {
            this.loadStep('inicio');
        });
    },
    
    loadStep: function(step, data = {}) {
        const modal = new bootstrap.Modal(document.getElementById('modalAvaliacao'));
        const url = `includes/modais/steps/step-${step}.php`;
        
        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams(data)
        })
        .then(response => response.text())
        .then(html => {
            document.getElementById('modalAvaliacaoContent').innerHTML = html;
            this.currentStep = step;
            modal.show();
            this.initStepEvents();
        });
    },
    
    initStepEvents: function() {
        // Eventos para botões de navegação
        document.getElementById('btnNextStep')?.addEventListener('click', () => {
            const nextStep = document.getElementById('btnNextStep').dataset.next;
            const formData = this.collectFormData();
            this.loadStep(nextStep, formData);
        });
        
        document.getElementById('btnPrevStep')?.addEventListener('click', () => {
            history.back(); // Ou implemente sua própria lógica de voltar
        });
    },
    
    collectFormData: function() {
        const form = document.getElementById('formAvaliacao');
        if (!form) return {};
        
        return Object.fromEntries(new FormData(form));
    }
};

// Inicializa quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => AvaliacaoFlow.init());