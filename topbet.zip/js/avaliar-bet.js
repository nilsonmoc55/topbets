document.addEventListener('DOMContentLoaded', function() {
    // Botão "Avaliar uma casa de aposta" abaixo do carrossel
    const avaliarBtn = document.createElement('div');
    avaliarBtn.className = 'container mt-3 mb-5 text-center';
    avaliarBtn.innerHTML = `
        <button class="btn btn-primary btn-lg shadow" id="btnAvaliarBet" data-bs-toggle="modal" data-bs-target="#avaliarBetModal">
            <i class="fas fa-star me-2"></i> Avaliar uma Casa de Aposta
        </button>
    `;
    
    // Insere o botão após o carrossel
    const carrossel = document.querySelector('.carousel');
    if (carrossel) {
        carrossel.insertAdjacentElement('afterend', avaliarBtn);
    } else {
        document.querySelector('main').prepend(avaliarBtn);
    }
    
    // Busca em tempo real
    const buscaBet = document.getElementById('buscaBet');
    if (buscaBet) {
        buscaBet.addEventListener('input', function() {
            const termo = this.value.toLowerCase();
            const itens = document.querySelectorAll('.bet-item');
            let resultados = 0;
            
            itens.forEach(item => {
                const nome = item.querySelector('.bet-select').textContent.toLowerCase();
                if (nome.includes(termo)) {
                    item.style.display = 'block';
                    resultados++;
                } else {
                    item.style.display = 'none';
                }
            });
            
            document.getElementById('semResultados').classList.toggle('d-none', resultados > 0);
        });
    }
    
    // Ao selecionar uma bet
    document.querySelectorAll('.bet-select').forEach(btn => {
        btn.addEventListener('click', function() {
            const betId = this.getAttribute('data-bet-id');
            const betName = this.getAttribute('data-bet-name');
            
            // Fecha o modal de seleção
            const modal = bootstrap.Modal.getInstance(document.getElementById('avaliarBetModal'));
            modal.hide();
            
            // Aqui você pode redirecionar para a página de avaliação ou abrir outro modal
            // Exemplo: window.location.href = `avaliar.php?bet_id=${betId}`;
            
            // Ou abrir o formulário de avaliação em outro modal
            alert(`Você selecionou: ${betName} (ID: ${betId})`);
            // Implemente a lógica para abrir o formulário de avaliação aqui
        });
    });
});