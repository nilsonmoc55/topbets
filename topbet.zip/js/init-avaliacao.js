/**
 * Inicializa todos os componentes de avaliação
 */
function initAvaliacaoSystem() {
    // Verifica se todos os elementos necessários existem
    if (!document.getElementById('modalAvaliarInicial') || 
        !document.getElementById('modalSelecionarCasa') ||
        !document.getElementById('modalFormAvaliacao')) {
        console.warn('Elementos do sistema de avaliação não encontrados');
        return;
    }

    // Adiciona eventos aos botões de categoria
    document.querySelectorAll('.tipo-bet-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const categoria = this.getAttribute('data-tipo');
            abrirSelecaoCasa(categoria);
        });
    });

    // Configura o modal de seleção de casa
    const modalSelecionar = document.getElementById('modalSelecionarCasa');
    modalSelecionar.addEventListener('show.bs.modal', function() {
        const categoria = this.getAttribute('data-categoria') || 'esportiva';
        buscarCasas('', categoria);
    });
}

// Inicializa quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', initAvaliacaoSystem);