// Variáveis globais
let currentBetId = null;
let currentBetNome = null;

// Sistema de estrelas
function setupStarRating() {
    const starsContainers = document.querySelectorAll('.stars');
    
    starsContainers.forEach(container => {
        const stars = container.querySelectorAll('i');
        const input = container.querySelector('input[type="hidden"]');
        
        stars.forEach(star => {
            star.addEventListener('click', function() {
                const rating = parseInt(this.getAttribute('data-rating'));
                input.value = rating;
                
                stars.forEach((s, index) => {
                    if (index < rating) {
                        s.classList.remove('far');
                        s.classList.add('fas');
                    } else {
                        s.classList.remove('fas');
                        s.classList.add('far');
                    }
                });
            });
            
            // Efeitos hover
            star.addEventListener('mouseover', function() {
                const rating = parseInt(this.getAttribute('data-rating'));
                
                stars.forEach((s, index) => {
                    if (index < rating) {
                        s.classList.add('fa-star-half-alt');
                        s.classList.remove('far');
                    }
                });
            });
            
            star.addEventListener('mouseout', function() {
                const currentRating = parseInt(input.value);
                
                stars.forEach((s, index) => {
                    s.classList.remove('fa-star-half-alt');
                    if (index >= currentRating) {
                        s.classList.add('far');
                        s.classList.remove('fas');
                    }
                });
            });
        });
    });
}

// Inicialização quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    setupStarRating();
    setupAvaliacaoModals();
    // Outras inicializações...
});

function setupAvaliacaoModals() {
    // Configuração dos eventos dos modais
    // ... (código anterior de manipulação de modais)
}