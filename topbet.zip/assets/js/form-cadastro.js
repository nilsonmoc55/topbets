/**
 * Arquivo vazio para resolver erro de pré-carregamento
 * Todas as funções de cadastro estão no index.php
 */
console.log('Script de cadastro carregado');