document.addEventListener('DOMContentLoaded', function() {
    // Sistema de estrelas
    const stars = document.querySelectorAll('#ratingStars i');
    stars.forEach(star => {
        star.addEventListener('click', function() {
            const rating = parseInt(this.getAttribute('data-rating'));
            document.getElementById('inputRating').value = rating;
            
            stars.forEach((s, index) => {
                if (index < rating) {
                    s.classList.remove('far');
                    s.classList.add('fas');
                } else {
                    s.classList.remove('fas');
                    s.classList.add('far');
                }
            });
        });
    });

    // Mostrar/ocultar campos de bônus
    const bonusRadios = document.querySelectorAll('input[name="tem_bonus"]');
    const bonusFields = document.getElementById('bonusFields');
    
    bonusRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            bonusFields.style.display = this.value === '1' ? 'block' : 'none';
        });
    });

    // Quando o modal é aberto
    document.getElementById('modalAvaliar').addEventListener('show.bs.modal', function(event) {
        const button = event.relatedTarget;
        const betId = button.getAttribute('data-bet-id');
        const betNome = button.getAttribute('data-bet-nome');
        
        document.getElementById('betIdModal').value = betId;
        document.getElementById('betNomeModal').textContent = betNome;
        
        // Resetar o formulário
        document.getElementById('formAvaliacao').reset();
        stars.forEach(star => {
            star.classList.remove('fas');
            star.classList.add('far');
        });
        document.getElementById('inputRating').value = '0';
        bonusFields.style.display = 'none';
    });
});