<!DOCTYPE html>
<html lang="pt-BR" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="TopBets - Compare as melhores casas de apostas com avaliações reais de usuários. Encontre os melhores bônus e ofertas.">
    <meta name="robots" content="index, follow">
    <meta property="og:title" content="TopBets - Melhores Sites de Apostas">
    <meta property="og:description" content="Comparação de casas de apostas com avaliações reais">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?= SecurityService::escapeHtml($_SERVER['REQUEST_URI']) ?>">
    
    <title>TopBets - Melhores Sites de Apostas</title>
    
    <!-- Preload de recursos críticos -->
    <link rel="preload" href="assets/css/main.min.css" as="style">
    <link rel="preload" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" as="style" crossorigin>
    
    <!-- CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-..." crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/main.min.css">
    <link rel="stylesheet" href="assets/css/carousel.min.css">
    
    <!-- Favicon e ícones -->
    <link rel="icon" href="/favicon.ico" sizes="any">
    <link rel="icon" href="/icon.svg" type="image/svg+xml">
    <link rel="apple-touch-icon" href="/apple-touch-icon.png">
    
    <!-- Preconnect para fontes externas -->
    <link rel="preconnect" href="https://cdnjs.cloudflare.com">
</head>
<body class="d-flex flex-column min-vh-100">
    <?php include 'partials/header.php'; ?>
    
    <main class="flex-grow-1">
        <?php if (!empty($errorMessage)): ?>
            <div class="alert alert-danger text-center my-4">
                <?= SecurityService::escapeHtml($errorMessage) ?>
            </div>
        <?php endif; ?>
        
        <?php include 'partials/carousel.php'; ?>
        
        <div class="container my-5">
            <div class="row g-4">
                <div class="col-lg-3">
                    <?php include 'partials/filters.php'; ?>
                </div>
                
                <div class="col-lg-9">
                    <?php include 'partials/bookmakers-list.php'; ?>
                </div>
            </div>
        </div>
    </main>
    
    <?php include 'partials/footer.php'; ?>

    <!-- Scripts otimizados -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-..." crossorigin="anonymous" defer></script>
    <script src="assets/js/main.min.js" defer></script>
    
    <?php if ($usuarioLogado): ?>
        <script src="assets/js/user-actions.min.js" defer></script>
    <?php endif; ?>
</body>
</html>