<?php if (empty($bets)): ?>
    <div class="alert alert-info">
        Nenhuma casa de apostas encontrada com os filtros selecionados.
    </div>
<?php else: ?>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <?php foreach ($bets as $bet): ?>
            <div class="col">
                <div class="card h-100 shadow-sm">
                    <div class="position-relative">
                        <a href="/bookmaker/<?= SecurityService::escapeHtml($bet['slug']) ?>" class="stretched-link" aria-label="<?= SecurityService::escapeHtml($bet['nome']) ?>"></a>
                        <img src="<?= SecurityService::escapeHtml($bet['logo']) ?>" 
                             class="card-img-top p-3" 
                             alt="Logo <?= SecurityService::escapeHtml($bet['nome']) ?>" 
                             loading="lazy"
                             width="300" height="150">
                    </div>
                    
                    <div class="card-body">
                        <h3 class="h5 card-title">
                            <?= SecurityService::escapeHtml($bet['nome']) ?>
                        </h3>
                        
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div class="rating">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star<?= $i <= round($bet['media_nota']) ? ' text-warning' : ' text-secondary' ?>"></i>
                                <?php endfor; ?>
                                <span class="ms-1 small">(<?= (int)$bet['total_avaliacoes'] ?>)</span>
                            </div>
                            
                            <?php if ($bet['bonus'] > 0): ?>
                                <span class="badge bg-success">Bônus <?= (int)$bet['bonus'] ?>%</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="d-grid gap-2 mt-3">
                            <a href="<?= SecurityService::escapeHtml($bet['url']) ?>" 
                               class="btn btn-primary btn-sm" 
                               target="_blank" 
                               rel="noopener noreferrer">
                                Visitar Site
                            </a>
                            
                            <?php if ($usuarioLogado): ?>
                                <button class="btn btn-outline-secondary btn-sm" 
                                        data-bs-toggle="modal" 
                                        data-bs-target="#ratingModal" 
                                        data-bookmaker-id="<?= (int)$bet['id'] ?>">
                                    Avaliar
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <nav class="mt-4">
        <ul class="pagination justify-content-center">
            <li class="page-item disabled">
                <a class="page-link" href="#" tabindex="-1">Anterior</a>
            </li>
            <li class="page-item active"><a class="page-link" href="#">1</a></li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item">
                <a class="page-link" href="#">Próxima</a>
            </li>
        </ul>
    </nav>
<?php endif; ?>